# Owner Decisions

This chapter records the language questions that only the project owner decides, OD1 to OD157 of
[the decision record](#owner-decisions), and how each was answered. Every one is answered:
OD1 to OD32 and OD47 on 2026-10-29, the entries OPEN-33 to OPEN-157 on 2026-10-31 and 2026-11-01
(OD94 was withdrawn: MOD-1 already refuses its case, bug 337), and the questions raised while
recording them on 2026-11-02. The entry IDs are retired and never
reused; their anchors stay, so links to them land on the answer.

The answers of 2026-10-31, 2026-11-01 and 2026-11-02 are recorded here before the rules that carry them are written.
The chapters state these decided rules now (owner revision, 2026-11-03), before being rewritten as Lean, the only normative source of the language
([ROADMAP.md](../ROADMAP.md#phases), phases B–D); until then, where a chapter still describes
the earlier behaviour, the answer below governs, and the code follows as its new-compiler slice lands.

The shape of Core was approved provisionally on 2026-11-05 ([stage A2a](#decided-2026-11-05)): it binds the design, and the owner freezes Core at stage A2c, after the four design theorems are proved against the proposed `Spec.lean` and the integration stage A2i (2026-11-06) is accepted. The project and architecture decisions are recorded here too, [below](#decided-project).

<a id="waiting-for-the-owner"></a>
## Waiting for the owner

Links only; each item's text lives where it is linked.

1. The spec read and the Core freeze, A2c ([queue](../ROADMAP.md#the-queue)).
2. The items the reviews leave open until they are fully dispositioned: SPARK review items 4(b) and
   4(c) ([SPARK review](proposals/SPARK.md)). Quantitative step and time bounds were decided on
   2026-11-07 ([row](#decided-2026-11-07-step-bounds)); the reviews' remaining disposition is unchanged.

A decided proposal moves to `docs/archive/<topic>-<date>/`.

<a id="recent-decisions"></a>
## Recent decisions

Each row records a decision and its reason. A language rule itself is its Lean definition in
[ConcreteSpec/](../ConcreteSpec/), which governs once it lands.

- The core statement ([row](#decided-project-core-statement)).
- Proof infrastructure from the first commit ([row](#decided-project-proof-infrastructure)).
- No hidden traps, and termination evidence or a report of the permitted unresolved obligations ([row](#decided-project-no-hidden-traps)).
- The `checked_*`, `#[proof]` and `#[may_not_terminate]` spellings ([row](#decided-project-no-hidden-traps)).
- The per-function facts report and query ([row](#decided-project-facts-report)).
- The predictable policy ([row](#decided-project-predictable-policy)).
- Reproducible builds from slice 0 ([row](#decided-project-reproducible-builds)).
- The spec layout: one library in modules ([row](#decided-project-long-term-2026-11-06)).
- A minimal root ([row](#decided-project-lean-root)).
- The LCB joins slice 0 ([row](#decided-project-proof-infrastructure)).
- Policies and declared assumptions in `Concrete.toml` ([row](#decided-project-concrete-toml)).
- `legacy/` kept until the new compiler implements a full real program such as RocksDB or ethrex ([row](#decided-project-restart)).
- OS-level sandboxing is outside the compiler's scope ([row](#decided-project-os-sandboxing)).
- Diagnostics are checker outputs ([row](#decided-project-diagnostics-2026-11-06)).
- Heap facts and memory policies ([row](#decided-project-memory-2026-11-06)).
- Secrets, noninterference and constant time ([row](#decided-project-infoflow-2026-11-06)).
- The new compiler pipeline ([row](#decided-project-pipeline-2026-11-06)).
- Thin vertical slices and their order ([row](#decided-project-vertical-slices-2026-11-06)).
- What Concrete takes from SPARK ([row](#decided-project-spark-2026-11-06)).
- Trap line, default layout and spec version ([row](#decided-project-runtime-2026-11-06)).
- The slice-0 surface: `concrete build`, `concrete facts`, unsupported-form refusals, leading zeros ([row](#decided-slice0-surface-2026-11-06)).
- The outside readers' model-first ordering ([row](#decided-project-outside-readers)).
- Step bounds: the model at slices 4–5 and proofs at slice 8 ([row](#decided-2026-11-07-step-bounds)).
- All seven showcases and their slices ([row](#decided-2026-11-07-showcases)).
- Concurrency at final slice 28, then ethlambda and the encrypted tunnel ([row](#decided-2026-11-07-final-slices)).
- Struct invariants in source at slice 17 ([revision](#decided-project-spark-2026-11-06)).
- Test runner at slice 8, formatter at 17, LSP later ([row](#decided-2026-11-07-tools)).
- Flagship and compiler speed tracking ([row](#decided-2026-11-07-performance)).
- Stack bounds from slice 0 and randomness from slice 6 ([row](#decided-2026-11-07-stack-randomness)).
- Where the decisions and their work are tracked, with a home and a gate per item ([row](#decided-2026-11-07-tracking)).
- The trusted-base statement, differential fuzzer, sanitizers, binary-size tracking and frozen JSON schema ([row](#decided-2026-11-07-early-evidence)).
- The documentation and tooling cleanup is approved, not performed by that record ([row](#decided-2026-11-07-cleanup)).
- The shared foundation is written and frozen in Lean first, then each slice adds its rules ([row](#decided-2026-11-07-foundation-first)).
- The Lean foundation, contracts C1–C10, and the answers to its sixteen questions ([row](#decided-2026-11-08-foundation)).
- A std-per-slice table in the roadmap; no user-guide chapter per slice for now; the written grammar before the parser; a speed target against C at slice 16 ([row](#decided-2026-11-08-std-table)).
- Capabilities stay as decided, `with(...)` permission sets plus grant values; confirmed, no revision ([row](#decided-2026-11-08-capabilities-kept)).
- Every branch gets an agy review too ([row](#decided-project-review)).
- Eleven plan and process decisions: UBSan dropped, a complete adapter theorem, smaller landing scripts, Claude's quota on the critical path, the front end now, one decisions writer, risk-capped reviews, one clones folder, a later no-libc runtime, a compile-speed budget and the termination wording ([row](#decided-2026-11-08-eleven)).

<a id="rules-a-decision-changed"></a>
## Rules a decision has changed

The chapters were brought into line on 2026-11-03 under the owner's explicit prose-cleanup
revision of the Lean-only source decision. The table records the audit and its disposition; an
undecided dependency remains explicitly linked to the target Core proposal rather than designed here.

| Rules | What the audit found | Governing decision | Disposition |
|---|---|---|---|
| TRUST-9 | `main` receives a root resource, splits it, and resources descend from it. | authority rule 12; revised OD8/38 | Fixed in prose 2026-11-03. |
| TRUST-8/9/10 | Tokens model resources, effects appear as token parameters, and there is no separate effect system. | Authority introduction and rules 1–2, 8, 11 | Fixed in prose 2026-11-03. |
| TRUST-D1/4 | Capabilities include `File`, `Console`, and `Random`. | authority rule 13 | Fixed in prose 2026-11-03. |
| TRUST-4, TYPE-D1 rationale | `Std` expands to all operational capabilities. | authority rule 6 and introduction | Fixed in prose 2026-11-03. |
| Syntax introduction | Capability names are contextual; `ghost` is contextual. | authority rule 13; OD73/81/90; OD50 | Fixed in prose 2026-11-03. |
| MEM-5, OWN-15 tables | `alloc(v)` directly returns an owned heap value. | Allocation decision | Fixed in prose 2026-11-03. Allocator identities, dependency discipline and complete failure contracts remain [undecided: see the target Core proposal](#core-allocator-identities). |
| MEM-5 and resource descriptions | Heap/container types have no allocator identity: `Heap<T>`, `Vec<T>`, `String`. | Allocation decision | Fixed in prose 2026-11-03. Allocator identities, dependency discipline and complete failure contracts remain [undecided: see the target Core proposal](#core-allocator-identities). |
| STMT-2 | OOM is terminal; recovery is a workload-gated backlog item. | Allocation decision | Fixed in prose 2026-11-03. |
| MEM-5/7, TYPE-10, OWN-15 | `free(h)` releases storage and returns its payload; a Copy result can disappear as part of consumption. | OD59; clarified OD140 | Fixed in prose 2026-11-03. Allocator identities, dependency discipline and complete failure contracts remain [undecided: see the target Core proposal](#core-allocator-identities). |
| STMT-7 | `main` takes no parameters until an implementation task lands. | authority rule 12; revised OD38 | Fixed in prose 2026-11-03. |
| STMT-7 | `main` returns `u8` or `Unit`, with `Unit` mapped to zero. | 2026-11-02 main decision | Fixed in prose 2026-11-03. |
| STMT-10 | Tests return `i32`. | Revised OD146 | Fixed in prose 2026-11-03. |
| SCOPE-2 | Types, traits, and modules are categorically “another namespace” and therefore not collisions. | Completed OD43; OD67 | Fixed in prose 2026-11-03. |
| TRAIT-D1 rationale | Impl target lookup includes a sibling submodule’s declarations as an implicit fallback. | Explicit-child decision, completed OD43 | Fixed in prose 2026-11-03. |
| Modules introduction and MOD-7 rationale; accepted examples throughout modules/types/FFI | Inline `mod m { … }` is an available module form. | OD33/61 | Fixed in prose 2026-11-03. |
| MOD-4 | Loads `X.con` or `X/mod.con`. | OD142 | Fixed in prose 2026-11-03. |
| TRUST-6 | Trusted functions, externs, and raw operations require `trusted mod`. | OD61 | Fixed in prose 2026-11-03. |
| PAT-1/6, SYN-4, scope introduction | `if let` and `while let` are supported forms with specified semantics. | OD52 | Fixed in prose 2026-11-03. |
| PAT-5/10/11, OWN-5/15 | Refutable destructuring uses `let … else`; rules explain its fallback and mutability. | OD52/85 | Fixed in prose 2026-11-03. |
| PAT-2/3/4/7/9, TYPE-5, OWN-15 | Guards affect matching, coverage, commitment, and moves. | OD55 | Fixed in prose 2026-11-03. |
| PAT-3/7, OWN-15, REF-9 rationale | Range patterns match integer intervals. | OD56/41 | Fixed in prose 2026-11-03. |
| TYPE-7/11, STMT-4/5, OWN-15;  | Struct update `..base` supplies fields, has evaluation order, and copies fields. | OD53 | Fixed in prose 2026-11-03. |
| TYPE-11/21/24, OWN-D1/15, REF-3/5, MOD-9;  | Newtypes exist, have representation rules, constructors, `.0`, casts, and imports. | OD54/123/155 | Fixed in prose 2026-11-03. |
| REF-D3, SCOPE-D1;  | Borrow blocks bind a region via `in R`. | OD57 | Fixed in prose 2026-11-03. |
| OWN-8 rationale; REF-5/12 rationale | Auto-borrowed receivers are ordinary supported places; elaboration builds implicit receiver borrows. | OD32 | Fixed in prose 2026-11-03. |
| MEM-4 accepted example; OWN-15 heap-field row | `h.f` works directly through `&Heap<S>`/`&mut Heap<S>`. | OD30/36 | Fixed in prose 2026-11-03. Exact heap-array view remains [undecided: see the target Core proposal](#core-heap-array-view). |
| TRUST-13, TRUST-4 exception; accepted example  | Reference-to-pointer conversion is safe and needs neither trust nor `Unsafe`. | OD98 | Fixed in prose 2026-11-03. |
| MEM-9, ARITH-13 | Proven runtime violations are refused only outside trusted/`Unsafe` functions. | OD118 | Fixed in prose 2026-11-03. |
| CON-3 | Contracts read parameters and `result`. | OD143 | Fixed in prose 2026-11-03. |
| STMT-11 and execution prose; OWN-13 rationale | Remaining locals “are destroyed”; storage teardown versus `Destroy` remains open. | OD69 | Fixed in prose 2026-11-03. |
| OWN-17 | Deferred Copy results are implicitly dropped. | OD140; authority rule 9 | Fixed in prose 2026-11-03. |
| OWN-5; catalog | `discard` accepts any Copy value. | OD62 | Fixed in prose 2026-11-03. |
| REF-10 | An exclusive-reference binding may go unused. | OD62 | Fixed in prose 2026-11-03. |
| SYN-1 and introduction | The external EBNF governs acceptance exactly. | OD150/77 | Fixed in prose 2026-11-03. |
| SYN-6 | A char literal is any one character; non-ASCII behavior is left open. | OD137 | Fixed in prose 2026-11-03. |
| TYPE-6 | Comparisons take numbers only; bool/char support is unresolved. | OD42 | Fixed in prose 2026-11-03. |
| TRAIT-6 and introduction; rationale  | Ambiguous bound-method calls are refused and qualification does not exist. | OD6, completed 2026-11-02 by the qualified call `Trait::method(&x, ...)` | Fixed in prose 2026-11-03. |
| PAT-8 and accepted examples; PASS-6; CON-4 | Rules/examples still accept or regulate C-style `for` headers. | OD47/61 | Fixed in prose 2026-11-03. |
| Conformance examples across all 15 rule chapters; e.g. | Unqualified accepted fixtures use removed aliases/forms, wrong `main` results, or unused named bindings. | Alias/main decisions; OD33/52–57/62 and others above | Fixed in prose 2026-11-03. |
| README and overview authority description | Markdown sentences are normative except where semantics later lands; the written directory is the language source. | the Lean-only source decision (ROADMAP) | Fixed in prose 2026-11-03. |


<a id="target-core-proposal"></a>
## Target Core proposal: dependencies (provisionally decided 2026-11-05)

These items were undesigned when the chapters were cleaned up on 2026-11-03. **The owner approved their design provisionally on 2026-11-05** ([the decided rows](#decided-2026-11-05-core): allocator identities Q1, allocation contracts Q1–Q2, the heap-array view Q3, static text Q4, capability inference Q5, unsafe contracts Q3.7–Q3.12, static refusal Q6, grants Q7, semantic objects Q8–Q9). Where a chapter still says **undecided: see the target Core proposal**, read the decided row; the rule is rewritten in Lean at stage A2b and frozen at A2c. The proposal is owned by
[ROADMAP: Questions for the Core session](../ROADMAP.md#questions-for-the-core-session).

- <a id="core-allocator-identities"></a>[Core-session question 1](../ROADMAP.md#questions-for-the-core-session). **Allocator identities and dependencies:** introduction, kind,
  scope, equality, packaging and repeated reset, dependency tracking across calls, containers and
  callbacks, and lifetime-safe release metadata; the allocation decision's conservation and no-live-
  allocation requirements stand, but the discipline expressing them, undecided on 2026-11-03, is provisionally decided by rows Q1.1–Q1.13 ([rows](#decided-2026-11-05-core)).
- <a id="core-allocation-contracts"></a>[Core-session question 1–2](../ROADMAP.md#questions-for-the-core-session). **Allocation contracts:** failure payload shapes and complete
  growth, reserve and multi-allocation transition contracts; applicability of container `Destroy`
  when payload cleanup needs effects beyond `Alloc`, undecided on 2026-11-03, are provisionally decided by rows Q1.8–Q1.12 and Q2.1–Q2.8 ([rows](#decided-2026-11-05-core)).
- <a id="core-heap-array-view"></a>[Core-session question 3](../ROADMAP.md#questions-for-the-core-session). **Heap-array view:** exact bounded view type, operations, lifetime,
  mutability and permitted positions, undecided on 2026-11-03, are provisionally decided by rows Q3.1–Q3.6 and Q4.7 ([rows](#decided-2026-11-05-core)); opening never yields an element reference.
- <a id="core-static-text"></a>[Core-session question 4](../ROADMAP.md#questions-for-the-core-session). **Static text:** literal type, ownership and conversion into
  allocator-branded strings, undecided on 2026-11-03, are provisionally decided by rows Q4.1–Q4.6 ([rows](#decided-2026-11-05-core)); static text requires no allocation.
- <a id="core-grants"></a>[Core-session question 7](../ROADMAP.md#questions-for-the-core-session). **Target grants:** exhaustive schemas, multiplicity, lifecycle and narrowing
  APIs, including the resource backing process services, undecided on 2026-11-03, are provisionally decided by rows Q7.1–Q7.11 ([rows](#decided-2026-11-05-core); process spawning is deferred).
- <a id="core-capability-inference"></a>[Core-session question 5](../ROADMAP.md#questions-for-the-core-session). **Capability inference:** decided 2026-11-05 (row Q5.1/Q5.4): there is
  none; capability arguments are written explicitly at every polymorphic call and checked, so no choice among
  solutions arises. Exact sets and refusal of inconsistent bindings stand.
- <a id="core-unsafe-premises"></a>[Core-session question 3, 9](../ROADMAP.md#questions-for-the-core-session). **Unsafe contracts:** the complete validity, provenance, aliasing
  and foreign-mutation taxonomy and call-only annotation syntax, undecided on 2026-11-03, are provisionally decided by rows Q3.7–Q3.12 and Q9.7 ([rows](#decided-2026-11-05-core)); OD64's confinement
  requirement stands.
- <a id="core-static-refusal"></a>[Core-session question 6](../ROADMAP.md#questions-for-the-core-session). **Static refusal:** the mandatory proof criterion and its relation
  to Core acceptance, undecided on 2026-11-03, are provisionally decided by rows Q6.1–Q6.7 ([rows](#decided-2026-11-05-core)); recorded proven-violation refusals apply in trusted code too.
- <a id="core-semantic-contract"></a>[Core-session question 8–9](../ROADMAP.md#questions-for-the-core-session). **Semantic objects:** exact events, admissible allocation oracles,
  observations, resource relations and theorem endpoint, undecided on 2026-11-03, are provisionally decided by rows Q8.1–Q8.7 and Q9.1–Q9.19 ([rows](#decided-2026-11-05-core)); technical adequacy and
  refinement obligations remain binding.


### Rules awaiting Lean formalization (listed 2026-11-03)

These rules depended on a design that was undecided on 2026-11-03. Their designs were provisionally
decided on 2026-11-05 ([decided rows](#decided-2026-11-05-core)); formalizing them in Lean remains
pending through A2b, and freezing them through A2c. This does not reopen the decisions already
recorded in their sentences.

| rules | reason |
|---|---|
| SYN-5, TYPE-3, OWN-15, REF-5 | [Static-text typing, ownership and borrowing](#core-static-text) |
| TYPE-D1, TYPE-17 | [Ambiguous set-variable inference](#core-capability-inference) |
| TYPE-10, OWN-13 | [Complete conserving failure contracts and container Destroy applicability](#core-allocation-contracts) |
| MEM-5, MEM-7 | [Allocator identity introduction, dependency discipline and release metadata](#core-allocator-identities); MEM-5 also needs [failure payload contracts](#core-allocation-contracts) |
| REF-D3, MEM-4 | [Exact bounded heap-array view](#core-heap-array-view) |
| STMT-7, TRUST-D1, TRUST-9, TRUST-10 | [Target grant schemas, lifecycle and future foreign callback permissions](#core-grants) |
| ARITH-13, MEM-9 | [Mandatory static-proof refusal criterion](#core-static-refusal) |
| TRUST-13, FFI-12 | [Complete unsafe primitive contracts and call-only annotation syntax](#core-unsafe-premises) |


<a id="decided-2026-11-05"></a>
## Owner decisions 2026-11-05: Core design (A2a provisional approval) and project rows

The owner answered every row of the 2026-11-05 decision page, in the terminal. The rows that revise a recorded rule were answered one by one: Q5.1/Q5.4, Q6.4, Q2.8, Q9.15 with P3, Q7.11 and Q4.7. Q3.12, Q9.19, Q7.10, Q1.6, P2, P4, P9, P13, P16 and P17a/b were also answered directly. The remaining Core rows were accepted as recommended, and the remaining project rows were approved on the owner's condition that Claude and Codex agree and that each is the best long-term design (both confirmed; every row carries Codex agreement). The full rows (question, options, reason, recommendation, agreement, revision and notes) are in [core_rows.json](archive/decisions-2026-11-05/core_rows.json) and [other_rows.json](archive/decisions-2026-11-05/other_rows.json); the concrete rules behind them are in [R4_RATIONALE.md](archive/decisions-2026-11-05/R4_RATIONALE.md), and where R4 and a row differ, the row governs.

**The Core rows are a provisional approval (stage A2a).** They bind the design without freezing it. Stage A2b formalizes them in a proposed `ConcreteSpec/Spec.lean` and proves the four design theorems; any row the formalization changes returns to the owner; stage A2i integrates the parts (2026-11-06); the owner freezes Core at A2c (row Q9.19 as revised). Until a rule is written in Lean, the answer below governs over any chapter text that differs.

<a id="decided-2026-11-05-revisions"></a>**Owner-approved revisions of recorded rules** (each also noted at the rule it revises):

- **OD45 and OD87** (rows Q5.1, Q5.4): capability arguments are written explicitly at every polymorphic call and checked against the callee; there is no capability inference and no inference solver. OD46 (type arguments from checked argument types) is unchanged.
- **TYPE-22@1's examples** (row Q6.4): a constant whose initializer provably fails is refused at compile time whether or not it is used (OD118); both examples, `unused-constant-never-runs` and `constant-traps-at-use`, become reject examples. When a constant is evaluated (at each use, never at start) is unchanged.
- **TRAIT-1@1** (row Q2.8): two impls with equal heads may coexist only when Copy/Destroy disjointness (OD28) makes their domains disjoint, as in `impl<T: Copy> Destroy for Vec<T, A>` beside `impl<T: Destroy> Destroy for Vec<T, A>`. No other coherence or orphan rule changes, and no disjunctive bound syntax is added.
- **The generated-chapter requirement** (rows Q9.15, P3): Lean is the specification, in one main normative file with doc comments and examples; no prose is generated from it. This confirms the [2026-11-04 decision](#decided-project-lean-is-the-spec). The "one main normative file" wording is revised 2026-11-06 by the [long-term changes](#decided-project-long-term-2026-11-06): one authoritative specification library in cohesive modules, with `ConcreteSpec/Spec.lean` as its public import.
- **Authority rules 13, 5 and 7** (row Q7.11): `Console` joins the reserved capability set, for operations on the `StdIn`, `StdOut` and `StdErr` grants; rule 5's operational list and rule 7's primitive table include it. `Device` stays for device grants.
- **The text-only slice of R4 F4.3** (row Q4.7) is replaced before it was recorded: one scoped form opens every view, `borrow [mut] source [from a until b] as view { … } [else { … }]`. Without `else` an invalid range traps, like indexing; with `else` it is handled; a proven invalid range without `else` is refused (OD118). Arrays need `a ≤ b ≤ len`; text also needs UTF-8 scalar boundaries at both byte offsets.
- <a id="decided-2026-11-05-q6-2-fields"></a>**Q6.2 and R4 F12, known values through structs** (owner-approved revision, 2026-11-05, made during A2b): known values propagate field by field through immutable struct construction and destructuring. The checker tracks an abstract value for each binding: unknown, a known scalar, or a constructor whose fields carry their own abstract values. Constructing a struct records each field's fact independently; an immutable binding keeps the fact; destructuring hands each field's fact, recursively, to the corresponding immutable binder; an unknown component stays unknown without discarding its known siblings; an ownership transfer keeps the facts for the receiving binding without permitting reuse of the consumed one. Q6.2's exclusions stay (mutable state, branches and paths, user-function calls, calls outside the table, elaborator temporaries). So `let S { a } = S { a: 200u8 }; a + 100` is refused, in trusted and unreachable code too (OD118 as revised by Q6.4). Before this revision a field bound by destructuring was not known and that program was accepted and trapped.
- <a id="decided-2026-11-05-q9-1-reads"></a>**Q9.1, read forms** (owner-confirmed, 2026-11-05): `copy x` is allowed only when `x` has a Copy type and `move x` only when it has a non-Copy (linear) type. Each read has one form; `move` of a Copy value and `copy` of a linear value are both refused.

<a id="decided-2026-11-05-new-rules"></a>**New rules** (P4): duplicate variant names in one enum and duplicate method names in one impl are refused, like duplicate fields (bug 313); the rule gets its ID and diagnostic when it is written in Lean.

<a id="decided-2026-11-05-core"></a>**Core rows** (the answer is the row's recommendation):

- **Q1.1** What is an allocator brand? — Separate erased `Brand` kind.
- **Q1.2** How are fresh brands introduced, including loop resets? — Generative binders; existential loop state.
- **Q1.3** How are packages formed and opened? — Explicit pack; lexical unpack; repackage escapes.
- **Q1.4** How are brands compared and supplied? — Nominal brand equality; explicit brand arguments.
- **Q1.5** How are allocator dependencies tracked across calls? — Structural dependencies; checked interface summaries.
- **Q1.6** Who owns a child allocator’s backing? — Child owns backing; parent brand exposed in type. *Revises or adds: Clarify/extend allocator interface.*
- **Q1.7** Where does release information live? — Stable release state and raw context; no safe references. *Revised 2026-11-08 by the [foundation decision](#foundation-q6): release-context erasure is allowed only with a proof (release statically known, no per-instance information), including owning Text where applicable; no unconditional one-pointer claim.*
- **Q1.8** What if creating allocator state fails? — Fallible allocator construction conserving surviving inputs.
- **Q1.9** What do allocation failures contain? — `AllocFailure<T>` returns rejected `T`; operation-specific recovery.
- **Q1.10** Are capacity and addresses observable? — Observable capacity; explicit raw-address exposure.
- **Q1.11** What does “unchanged” require of allocator state? — Availability predicate plus four laws: progress, unchanged state on failure, release never reduces availability, a concrete success witness.
- **Q1.12** What rolls back around callbacks? — No rollback of callback effects; every element accounted for in a typed result.
- **Q1.13** Can resetting the system allocator return `Allocator<Sys>` again? — Fresh brand after any supported system reset.
- **Q2.1** Are storage release, destruction and resource cleanup separate? — Separate storage release, destruction and resource cleanup.
- **Q2.2** Which containers implement `Destroy`? — Exactly sixteen named Destroy impls: Array (T: Destroy); Heap, HeapArray and Vec (two each: T: Copy; T: Destroy); String (unconditional); Option (T: Destroy); Result (three: T: Destroy/E: Copy, T: Destroy/E: Destroy, T: Copy/E: Destroy); OrderedMap (four: each of K and V Copy or Destroy). HashMap excluded. <a id="q2-2-revision"></a>Revised 2026-11-06 by [information flow](#decided-project-infoflow-2026-11-06): `Secret<T>` is `Copy` only for scalar `T`; secret arrays and heap secrets are linear and their destruction wipes them.
- **Q2.3** In what order are contents destroyed? — Index order 0..len−1, then the backing; OrderedMap in ascending key order, key then value, then the nodes.
- **Q2.4** How does a container of non-`Destroy` resources release its storage? — `drain(v, ctx, f)` with `f: fn(&mut C, T) with(K) -> Step<T, E>`; the only way to empty a container of non-Destroy elements.
- **Q2.5** What happens when drain processing fails? — On Stop, `Drained { at, survivor, rest, err }`; `map_into` returns `Stopped { done, survivor, rest, err }`.
- **Q2.6** Must `destroy` terminate and avoid traps? — Ordinary partial correctness; prove stronger guarantees separately.
- **Q2.7** Does user destruction have special execution semantics? — Ordinary consuming checked `destroy`; at most `Alloc`.
- **Q2.8** How is 'Copy or Destroy' written for container impls? — (a) separate impls for every admitted combination of Copy/Destroy payload bounds, no disjunctive-bound syntax: two each for Heap, HeapArray and Vec, three for Result, four for OrderedMap; coherence may use Copy/Destroy disjointness. *Revises or adds: TRAIT-1@1 (under OD6): equal generic impl heads allowed only when Copy/Destroy disjointness makes their domains disjoint; all other coherence and orphan rules unchanged. Option (b) would also add new bound syntax.*
- **Q3.1** What does opening a heap array produce? — Second-class shared/mutable array views; no element references.
- **Q3.2** How are views passed and lent? — Downward parameters; mutable lending freezes origin.
- **Q3.3** What is a view’s root identity? — Original owner identity plus projection path.
- **Q3.4** Which view accesses conflict? — Existing whole-root conflict rules.
- **Q3.5** What is the index type? — `u64` lengths/indices across profiles; checked target limits.
- **Q3.6** How are nested linear elements traversed without substitutes? — `drain` / `map_into` for consuming traversal; `swap_at(v, i, x) -> T` for in-place replacement.
- **Q3.7** What is the raw-memory model and validity taxonomy? — Blocks with provenance; pointer = (prov: Option<BlockId>, addr: u64); integers carry no provenance; every access needs explicit validity premises. *Generalized 2026-11-08 by the [foundation decision](#foundation-q3): the address is read from a read-only target profile; the existing 64-bit little-endian profile is unchanged, and the provenance rules and the zero-byte exception are preserved.*
- **Q3.8** How do zero-sized elements behave? — Zero-sized slots own their obligations; they occupy no bytes and may share addresses.
- **Q3.9** What do pointer equality and integer round trips mean? — `expose` records the block; `from_exposed` picks in-bounds, then one-past, else no provenance. *Generalized 2026-11-08 by the [foundation decision](#foundation-q3): over the target profile's address spaces; the reconstruction policy is unchanged.*
- **Q3.10** What happens when address space runs out? — A collision means overlapping occupied bytes; address exhaustion is part of Avail. *Generalized 2026-11-08 by the [foundation decision](#foundation-q3): the existing profile keeps the `base + size ≤ 2^64−1` one-past bound; any generalized profile needs an analogous checked bound.*
- **Q3.11** How are typed values related to raw bytes? — Structured values and raw store joined by `Rep`.
- **Q3.12** How are extern pointer parameters marked, and how does C keep memory past the call? — (a) `kept` parameter marker; `Kept<H>` receipt ended only by the paired extern. *Revises or adds: New design + spelling: owner decision.*
- **Q4.1** What is a literal’s type? — Copy `StaticStr`; explicit fallible dynamic conversion.
- **Q4.2** Which encoding and NUL policy apply? — UTF-8 including embedded NUL.
- **Q4.3** What do length and comparison mean? — Byte length; content equality; lexicographic byte order.
- **Q4.4** Are literal addresses observable and literals mergeable? — Content semantics; pooling allowed; no safe address identity.
- **Q4.5** What is the FFI representation? — Explicit pointer/byte-length FFI adapter.
- **Q4.6** What are dynamic string views? — Byte offsets; `byte_at` traps out of range; subviews only through the scoped borrow form of Q4.7 (`borrow t from a until b as s { … } [else { … }]`). *Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): byte_at needs evidence of an in-range offset.*
- **Q4.7** How are scoped views and range subviews introduced? — (a) borrow [mut] source [from a until b] as view { … } [else { … }]; no else = trap (like indexing); proven invalid range without else refused (OD118). *Revises or adds: Replaces R4 F4.3 text-only mandatory-else form; extends Q3.1/Q3.2 with subview formation; preserves OD36/OD118.* *Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): the form without `else` needs evidence of a valid range; a provably out-of-range view index is covered by the same rule.*
- **Q5.1** Should capability arguments ever be inferred? — Explicit capability arguments on every polymorphic call. *Revises or adds: OD45, OD87.*
- **Q5.2** May explicit arguments contain the caller’s capability variables? — Explicit symbolic capability expressions and union.
- **Q5.3** What is capability-set equality and normal form? — Canonical semantic equality; refuse repeated names.
- **Q5.4** Is a capability inference solver still normative? — Explicit substitution checking; no inference solver. *Revises or adds: OD45, OD87.*
- **Q6.1** What determines mandatory static refusal? — Fixed Lean-defined local refusal rules. *Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): static refusal widens from proven violations to unproven safety.*
- **Q6.2** Is local constant propagation mandatory? — Fixed table of statically known values: literals, immutable lets, module constants, checked ops, six named wrapping/saturating ops, lossless `as`. *Revised 2026-11-05: facts propagate field by field through immutable struct construction and destructuring ([revision](#decided-2026-11-05-q6-2-fields)).* *Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): known values remain facts; refusal widens to unproven safety.*
- **Q6.3** Are violations rechecked after generic substitution? — Parametric checking plus substitution-time rechecking.
- **Q6.4** Does unreachable code receive static refusal checks? — Check all written code, including generic bodies. *Revises or adds: REVISES TYPE-22@1 examples.*
- **Q6.5** How do short-circuit operators interact with refusal? — Check both short-circuit operands; execute conditionally.
- **Q6.6** What happens when constant evaluation fails? — Separate invalid and unknown; no evaluator-resource failure.
- **Q6.7** What distinguishes traps, unsafe stuckness and exhaustion? — Separate traps, unsafe stuckness, OOM and fuel exhaustion.
- **Q7.1** How are target grant schemas and multiplicities specified? — One target, linux-x86_64-hosted (Linux ≥ 5.6), with a fixed grant table; main asks for grants as parameters. *Revised 2026-11-08 by the [foundation decision](#foundation-q16): the grant table is a lawful extensible registry rather than a permanently closed one.*
- **Q7.2** How do narrowing, acquisition and splitting relate? — Narrowing consumes and intersects rights; children are acquired from a grant that stays.
- **Q7.3** What are close and close-error contracts? — close always consumes; failure is a Copy error holding no handle; listen failure returns its grant.
- **Q7.4** How does process inheritance work? — Deferred: this target offers no process spawning.
- **Q7.5** Which environment does a program observe? — Scoped immutable launch environment snapshot.
- **Q7.6** What does a clock grant specify? — Explicit clock identity, kind, resolution and guarantees.
- **Q7.7** What are network scopes? — Connect and listen grants with numeric scopes; a separate Resolver grant with explicit server, transport, suffixes and record types.
- **Q7.8** Is grant policy enforced statically or dynamically? — Static authority checks plus atomic dynamic scope checks.
- **Q7.9** How are blocking, terminal actions and delivery observed? — Split request/response events; logical terminal observations.
- **Q7.10** Do you approve the linux-x86_64-hosted grant table? — Approve R4 F6's complete grant table below as part of this row: every launch configuration, operation signature, permission, narrowing rule and ending contract. Standard-stream operations require Console (Q7.11), not Device; where the R4 F6 table says with(Device) for StdIn/StdOut/StdErr, read with(Console). A missing configured grant refuses startup with exit 125; a trap exits 134. *Revises or adds: New target contract: owner decision.* *Extended 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): the stack target contract (adequate stack excludes exhaustion, launch refusal 125 when the reservation is smaller than the bound; then a defined outcome for inadequate stack) is a future target-contract obligation, not a current guarantee.* *Revised 2026-11-08 by the [foundation decision](#foundation-q16): the grant table is a lawful extensible registry; the existing grant contracts are preserved, an unknown operation is refused, and the Entropy grant's shape waits for slice 6 ([question 14](#foundation-q14)).*
- **Q7.11** Which permission do the standard streams use? — Add a Console capability for StdIn/StdOut/StdErr operations; keep Device for device grants. *Revises or adds: Authority rule 13 (adds Console); rules 5 and 7 lists include it.*
- **Q8.1** What is the first proof endpoint? — Proved source→BIR; qualified native; conditional image claim.
- **Q8.2** What exact source subset is admitted? — A1 minimal `u8`/linear-struct component subset. <a id="q8-2-revision"></a>Confirmed 2026-11-06 by [vertical slices](#decided-project-vertical-slices-2026-11-06): this is slice 1; its defined trap is an explicit `abort()`, with the refused `200 + 56` as its known-violation control; integers are complete at slice 2.
- **Q8.3** What establishes frontend correspondence? — Independent byte-to-Core correspondence judgments.
- **Q8.4** Does the first artifact qualify as a complete executable? — Component plus bound launcher first.
- **Q8.5** What launcher ABI and observations are fixed? — Pinned launcher ABI, inputs, startup and trap mapping. *Extended 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): the stack target contract (adequate stack excludes exhaustion, launch refusal 125 when the reservation is smaller than the bound; then a defined outcome for inadequate stack) is a future target-contract obligation, not a current guarantee.*
- **Q8.6** What artifacts does the claim bind? — Bind complete retained dependency and image closure.
- **Q8.7** What prevents vacuous correctness? — Coverage, realizable witnesses and rejection controls; a spec where every allocation fails fails qualification.
- **Q9.1** What is Core’s expression and binding form? — ANF; fresh identities; explicit moves/copies; separate places. *Confirmed 2026-11-05: `copy` only for Copy types, `move` only for non-Copy types ([read forms](#decided-2026-11-05-q9-1-reads)).*
- **Q9.2** What types and declaration identities must Core represent? — Kinded nominal inventory; ordinary owning container definitions.
- **Q9.3** What is the single loop form? — Core `while L { C } do { B }`: C is a condition region re-run every iteration; the counted loop advances its counter before the body.
- **Q9.4** How are data, matching and exits represented? — Flat data/matches; structured exits; checked stores.
- **Q9.5** Are heap opening and borrowing separate user mechanisms? — One surface borrow; distinct typed Core cases.
- **Q9.6** Which operations are primitives rather than ordinary definitions? — Irreducible primitives; checked destructor bodies.
- **Q9.7** How are primitive calls specified? — One exhaustive typed primitive-contract inventory. *Revised 2026-11-08 by the [foundation decision](#foundation-q16): lawful registry instances rather than a permanently closed inventory; exhaustive coverage of the selected registry; an unknown operation is refused.*
- **Q9.8** Does `defer` survive in Core? — Nested deferred scopes; late reads; reverse cleanup.
- **Q9.9** What is evaluator state and execution style? — Total clock-indexed evaluator; explicit instrumented state.
- **Q9.10** How are ownership instrumentation and erasure organized? — Ghost ownership instrumentation with proved erasure.
- **Q9.11** What do contracts mean and when are they checked? — Erased logical contracts; ensures sees result and surviving parameters after cleanup; no snapshot construct. *Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): a claim used for safety admission needs closed evidence.*
- **Q9.12** What evidence crosses declaration/module interfaces? — Checked semantic interfaces with reviewable declarations.
- **Q9.13** Are judgments independent of the checker and elaborator? — Independent judgments; checker/elaborator correspondence.
- **Q9.14** What must pass before Core freezes? — Provisional approval, then four kernel-checked theorems against a proposed Spec.lean, then freeze. Revised 2026-11-06 by the [long-term changes](#decided-project-long-term-2026-11-06): the integration stage A2i (interaction proofs, semantic contract, modular layout, owner view, outside-reader pass) also passes before the freeze.
- **Q9.15** Where do normative definitions and documentation live? — One main normative Lean file with doc comments. *Revises or adds: Generated-chapter requirement (philosophy rule 6 / earlier roadmap commitment): replaced by one normative Lean file with doc comments and examples, a browsable rendering of that Lean, and coverage-gated retirement of prose chapters; your decision of 2026-11-04.*
- **Q9.16** What Lean dependencies may the specification use? — Core Lean; supporting Batteries; owner exceptions for Mathlib.
- **Q9.17** May spec proofs use `native_decide`? — Kernel-only authoritative spec/A2 proofs.
- **Q9.18** How is the old compiler retained? — Frozen isolated `legacy/`; no normative fallback.
- **Q9.19** How do approval, formalization and Core freeze relate? — A2a → A2b → A2c; Spec.lean headed PROPOSED until freeze; R-0560 depends on the freeze. *Revises or adds: Process: owner decision.* Revised 2026-11-06 by the [long-term changes](#decided-project-long-term-2026-11-06): integration (A2i) comes between A2b and the A2c freeze, and the modular layout (R-0560) precedes the freeze.

<a id="decided-2026-11-05-project"></a>**Project rows:**

- **P1** Where agent discretion ends — Claude and Codex reason every question from the philosophy and recommend; they never pick a language answer through code, fixtures, diagnostics or docs. 'Important' = anything that revises a decided rule, changes observable language meaning you have not ruled on, or that you reserved. Every important decision comes to you.
- **P2** Priority order when principles conflict — Soundness and provability > transparency (with auditability, honest trust boundaries and compiler-owned identity) > one authoritative definition (checked derived views allowed) > explicitness at the use site > brevity. The philosophy guides open choices and never silently reopens decided rules.
- **P3** Lean is the spec: confirm the amendment — Lean is the specification: confirmed together with Q9.15 (revision below).
- **P4** Duplicate enum variants or methods (bug 313) — Refuse duplicate variant names in one enum and duplicate method names in one impl, with a new rule and diagnostic, the same as duplicate fields.
- **P5** legacy/ is a byte-frozen snapshot, never patched or run — legacy/ is main's tree at the move commit, byte-frozen. A root check compares its tree hash, allowing only deletions a satisfied RETENTION.tsv entry authorizes. No legacy gate ever runs. The oracle is the tag-built artifact (P13), not the legacy/ copy.
- **P6** Retention manifest gates deleting legacy/ — RETENTION.tsv at the root gives every legacy asset (corpus, regressions, examples, std, bug ledger, site, docs, research) a destination and deletion criterion. Revised 2026-11-06 ([restart row](#decided-project-restart)): nothing is deleted at B3; legacy/, the old pipeline included, is deleted way later (LD: once the new compiler implements a full real program such as RocksDB, ethrex or similar), when RETENTION.tsv has no live entry, a final ideas sweep has dispositioned every idea and the owner explicitly approves.
- **P7** Prove the new landing path before moving — T0: land beside the old tree the new root CI, required-checks.txt (enforced by train watch and land), RETENTION.tsv, the task disposition table, ORACLE.lock with the oracle artifact, and ISSUES.tsv. T1: rehearse the move on a throwaway branch: fresh clone, build, hook, exact-SHA CI, train --dry-run land; a broken build, a failing gate and a missing required check must each be refused. T2: the move in one train.
- **P8** Server services under scripts/ — Keep only landing services: train, review, hook, landing bot. The status page, work queue, fuzz farm, perf tracking and nightly campaign all stop and are recorded as archived in RETENTION.tsv; each returns only with a roadmap task.
- **P9** Website during the transition — The website goes down at the move and is redone from scratch with the new compiler; no frozen playground is served. Unpublishing the live site is an outward action whose moment the owner confirms.
- **P10** What 'closed' means for old-compiler bugs — Old-compiler defects become 'retired with the old implementation', never 'fixed'. Each keeps its reproducer, ruling and structural class; 106 reproducers feed the oracle comparisons. Bugs the frozen browser compiler still shows stay visible while the site serves it.
- **P11** Std bugs and rulings are carried — Add a 'std' class: 12 std bugs move with std as contracts plus regressions. The 112 language rulings (26 still open) keep their ruling and become conformance examples.
- **P12** Issue record from day one — From day one, ISSUES.tsv at the root: id, date, area (spec|proof|compiler|launcher|ci|migration), evidence, owner, severity, closure condition, status, with a small root check. Spec, proof, launcher, CI and migration defects go there. The full bug ledger and tool return with slice 1.
- **P13** concrete-ci-2 as the only CI host — CI runs on concrete-ci-2 (self-hosted) and on GitHub-hosted runners as a regular second pool, not only a fallback. Jobs that need ci-2 caches run there; the oracle is fetched as a release asset verified by digest; a check neither pool can run is incomplete and blocks landing. Self-hosted runners never run pull_request jobs.
- **P14** ci-3 handover: an exception to the archive requirement — Done by the owner on 2026-11-04: concrete-ci-3 was handed to stabileo; its fuzz corpus, perf history and leanprof data were not copied (an exception to the archive requirement).
- **P15** New roadmap: retiring obligations — Accept the new single-file ROADMAP.md (wip/new-roadmap, reconciled: prepare → rehearse → move, assurance wording per Q8.1, Phase E per P18, decides nothing itself): 79 tasks kept as rows, 345 folded into area tasks with their obligations, 109 deferred with triggers, 7 retired, 15 done.
- **P16** Status changes in the refusal list — Accept the new statuses in PHILOSOPHY.md. Now Permanent: operator overloading (OD26), capability hiding (authority rule 5), derived equality, mutable global state (OD8), umbrella capabilities and aliases, old/quantifiers in contracts (OD117), lexical shadowing (OD67), and ghost code that affects execution. Ghost code itself is admitted as decided (OD81). Foreign function values reopen when typed extern fn types are admitted (OD4); concurrency reopens on R-0399's trigger.
- **P17a** Default arguments — Default arguments: a Permanent refusal, reopened only by a new decision from you. They conflict with visible arguments.
- **P17b** Compile-time evaluation and broad #[cfg] — comptime and broad #[cfg]: keep evidence-based reopening, only with a workload, a proof story, phase separation and an audit report, and only by a new decision from you.
- **P18** Phase E: contracts and termination within OD115–OD117 — Phase E: no source old, quantifier, implication or snapshot construct (OD117); entry/exit and frame properties are Lean theorems (a source frame clause would be a new decision for you); spec functions have a body and are total (OD115); ordinary functions have no total category (OD116) and get per-function termination theorems where wanted. R-0524 becomes 'Frame and entry/exit theorems in Lean, no old'; R-0526 stays 'checked totality of spec functions'.
- **P19** Mutation testing for the new compiler — Retire the old mutation-harness defect work (R-0518). The new compiler gets its own mutation harness under R-0498, not a port of the old one.
- **P20** One home for binding decisions — Move the still-binding roadmap decisions (new compiler, retention contract, authority, allocation, Lean as the spec) into docs/decisions.md beside your language answers. The dated log becomes history; ROADMAP.md links to decisions.md and restates nothing.
- **P21** Retention records outlive legacy/ — RETENTION.tsv, ISSUES.tsv, required-checks.txt, scripts/oracle/ and docs/archive/roadmap-2026-11/ (with task_disposition.tsv) are part of the day-one root, outside legacy/, so they survive deleting it. *Revised 2026-11-06 (owner, verbatim: "do the whole movement"): of docs/archive/roadmap-2026-11/, the files that are decision sources or disposition records stay at the root (task_disposition.tsv, the decision log ROADMAP_DECISIONS.md, the task register ROADMAP_TASKS.md, ROADMAP_RECONCILIATION.md, ROADMAP_RESTRUCTURE.md with its table, and the archive README); the old control plane ROADMAP.md, ROADMAP_BACKLOG.md, ROADMAP_DIRECTION.md and WORK_QUEUE.md were duplicates of their frozen legacy/ copies apart from the move's mechanical rewrites, and nothing cites them as a decision source, so their root copies were removed and links point at the legacy/ copies, which stay until the legacy deletion point. The other docs/archive/ records (the site takedown record, the old bug ledger's disposition, the landing audit and the dated decision archives) stay at the root.*
- **P22** The work-queue dispatcher — Stop the dispatcher for the lean start. Agents are started by hand from the roadmap; bring the dispatcher back only when there is enough parallel work to need it.
- **P23** Precedence between decisions, rows and drafts — Recorded decisions govern. An accepted row supersedes a recorded rule only through an explicitly identified, owner-approved revision (Q5.1/Q5.4 for OD45/OD87, Q6.4 for TYPE-22, Q2.8 for TRAIT-1, Q9.15/P3 for generated chapters). R4's replacements govern conflicting draft recommendations. Before your acceptance is recorded, every passage R4 F18 lists is reconciled (capability inference, generated chapters, roadmap authority, assurance wording, restart order and retention, Phase E, freeze dependencies, superseded Core recommendations), and historical conflicting text is marked superseded.

<a id="decided-project"></a>
## Project and architecture decisions

These are the binding project and architecture decisions, moved here from the archived roadmap
decision log (decision row P20, 2026-11-05) so that language and project decisions have one home.
Each entry summarizes the decision and links its verbatim record in the
[2026-11 archive](archive/roadmap-2026-11/ROADMAP_DECISIONS.md), which stays as history; where an
entry and its archived record differ, the entry and its revision notes govern. The roadmap,
the philosophy and AGENTS.md cite these entries and restate none of them.

- <a id="decided-project-recording"></a>**Recording rule** (owner, 2026-11-02; extended 2026-11-05).
  The owner decides every language question and every important project question. Claude and Codex
  reason from the philosophy and recommend; neither chooses an answer through code, fixtures,
  diagnostics or documents (row P1). Where Claude and Codex agree that an answer is the best
  long-term decision, it is recorded as decided when the owner has given that rule for the question
  ("anything where you and codex agree that is the best decision, record the solution", 2026-11-02;
  the remaining rows of 2026-11-05 under the same condition). Every answer is written here with its
  date ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-02--owner-recording-rule)).
- <a id="decided-project-precedence"></a>**Precedence** (row P23, 2026-11-05). Recorded decisions
  govern. A decided row supersedes a recorded rule only through a revision the owner approved and
  that is marked as such ([the 2026-11-05 revisions](#decided-2026-11-05-revisions)). Drafts such as
  the Core proposal and the R4 rationale are background.
- <a id="decided-project-priority"></a>**Priority when principles conflict** (row P2, 2026-11-05).
  Soundness and provability first; then transparency, with artifact-backed auditability, honest
  trust boundaries and compiler-owned identity; then one authoritative definition (checked derived
  views allowed); then explicitness at the use site; brevity last. The order guides open questions
  and never reopens a decided rule. Most code is expected to be written by language models, so the
  language is optimized for checking and reading, never for writing effort.
- <a id="decided-project-spec-first"></a>**Specification first** (owner, 2026-10-30). The spec is
  complete when it is the one normative, simple and checkable statement of the language: owner
  decisions recorded, every normative statement absorbed and audited, removals applied, one shape per
  rule, every language refusal mapped to a rule, a conformance suite, the code matching the spec,
  and the outside-reader test passed. The criteria are read through the Lean-is-the-specification
  entry below ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-10-30--specification-first)).
- <a id="decided-project-docs-follow"></a>**Documentation follows the spec** (owner, 2026-10-30).
  Every other document cites the specification and loses any statement it contradicts; no document
  restates a rule the spec owns or describes a removed feature as current
  ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-10-30--documentation-follows-the-spec)).
- <a id="decided-project-lean-is-the-spec"></a>**Lean is the specification** (owner, 2026-11-01,
  revised 2026-11-04, confirmed 2026-11-05 by rows Q9.15 and P3). The normative language is Lean:
  each rule is a readable definition with its rule ID, a plain-words doc comment and its conformance
  examples, in one main normative file (`ConcreteSpec/Spec.lean`; revised 2026-11-06 by the
  [long-term changes](#decided-project-long-term-2026-11-06) to one authoritative library in cohesive
  modules with `Spec.lean` as its public import); proofs and tooling import it. No
  prose is generated from Lean; the 2026-11-01 requirement to generate `SPEC.md` and the chapters is
  superseded. Derived machine views (rule registry, IDs, manifests) keep a staleness gate. Prose
  chapters retire slice by slice, each only after a browsable rendering of the Lean rules and a
  rule-by-rule coverage report show its rules in Lean. The user guide is non-normative. Core is a
  small Lean language and every surface feature is defined by its lowering into Core
  ([2026-11-01](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-01--lean-as-the-only-source),
  [2026-11-04](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-04--lean-is-the-specification)).
- <a id="decided-project-new-compiler"></a>**A new compiler from the Lean spec** (owner, 2026-11-01;
  architecture approved 2026-11-02). The old compiler is not migrated; it is frozen at the tag
  `legacy-compiler-final` and retired. `ConcreteSpec` imports nothing from any compiler and holds
  the grammar as data with its LL(1) check, Core with identities, the statics as inductive judgments
  (the only normative form) with a checker proved to correspond, the one elaborator, the
  clock-indexed evaluator (the reference interpreter) and the conformance examples. The new compiler
  imports it and builds a proved lowering chain below Core; slice 1 gets a BIR → LLVM printer
  labelled unverified, and the Lean Compiler Backend follows. Revised 2026-11-05 by
  [proof infrastructure](#decided-project-proof-infrastructure): slice 0 gets the first BIR → LLVM
  printer and slice 1 extends the same path. Revised again 2026-11-06 (same row, *Backend order*):
  the Lean Compiler Backend joins slice 0 as a second unverified backend. Std, examples and tests migrate to the
  decided language; the old pipeline is deleted after slice 1
  ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-01-and-2026-11-02--new-compiler-and-retention-contract)).
  The record's "the browser compiler keeps running from the tag" is revised by row P9 below.
- <a id="decided-project-restart"></a>**The restart and the `legacy/` folder** (owner, 2026-11-04;
  details rows P5–P8, P21, P22, 2026-11-05). Everything old moves under `legacy/` on main in one
  train. `legacy/` is a byte-frozen snapshot of main's tree at the move commit, never patched and
  never run; one root check refuses any change under it except a deletion its retention row allows,
  and no legacy gate runs (P5). Every legacy asset has a row in the root `RETENTION.tsv` with a
  destination and deletion condition (P6). Revised 2026-11-06 by the owner ("i would delete legacy way later, we want to check it to see if
  we fogot any idea right?"): `legacy/` is kept much longer, as the reference for ideas the new
  design may have forgotten, and nothing is deleted after slice 1 (B3 keeps only the totality audit
  and the retirement of legacy defects). `legacy/`, the old pipeline included, is deleted way later,
  only after the ideas sweeps of `legacy/` (for the areas of phases C, D and E, each at the latest
  at that phase's start and possibly earlier, R-0591, R-0597, R-0598, and a final sweep that
  dispositions every idea as carried, planned, deferred or dropped on purpose), once every
  `RETENTION.tsv` row is resolved and with the owner's explicit approval at the time (LD, R-0590).
  The deletion point (owner, 2026-11-06: "i would delete legacy when we can implement a full program like rocksdb or ethrex or similar"): once the new compiler implements a full real program of that size, such as RocksDB, ethrex or similar; in the slice plan the earliest is the RocksDB
  acceptance program after slice 25. Until then `legacy/` stays byte-frozen. The new root's
  infrastructure lands first beside the old tree (T0: new CI, `required-checks.txt` enforced by the
  train with an explicit old-to-new transition mapping, `RETENTION.tsv`, the oracle lock, `ISSUES.tsv`),
  the move is rehearsed on the exact candidate root (T1), and only then does it land (T2) (P7). Only
  the landing services keep running; the status page, work-queue dispatcher, fuzz farm, perf tracking
  and nightly campaign are archived and return only with a roadmap task (P8, P22). The retention
  records live outside `legacy/` and survive its deletion (P21). The differential oracle is built from
  the tag in an isolated checkout, published as a release artifact verified by digest, and never
  overrides the Lean semantics.
- <a id="decided-project-oracle-release"></a>**The oracle release** (owner-approved, 2026-11-05). The
  oracle is published as the GitHub release
  [oracle-legacy-compiler-final](https://github.com/unbalancedparentheses/concrete2/releases/tag/oracle-legacy-compiler-final):
  the frozen compiler at tag `legacy-compiler-final` (commit `066c9d9b8836a2b176aa37f6c8313195a4b4ee29`),
  asset `oracle-legacy-compiler-final-x86_64-linux.tar.gz` with SHA-256
  `74d8f1e3b5214d9c64c25736a24c19458736a2dacc7977ff784506839b9f26a2`. It predates the decisions of 2026-10-29 to 2026-11-05 and is
  not the current language.
- <a id="decided-project-site"></a>**The website** (owner, row P9, 2026-11-05). The website goes down
  at the move and is rebuilt from scratch with the new compiler. No frozen playground is served in
  between. Unpublishing the live site is an outward action; the owner confirms its moment. The owner
  confirmed on 2026-11-05 that the site is taken down at the move (T2).
- <a id="decided-project-ci"></a>**CI hosts** (owner, row P13, 2026-11-05). CI runs on concrete-ci-2
  (self-hosted) and on GitHub-hosted runners as a regular second pool. Landing and oracle runs use
  separate pools with per-pool CPU and memory limits and at most two heavy runs per machine. A check
  neither pool can run is incomplete and blocks landing; it is never reported as passed. Self-hosted
  runners never run pull-request jobs.
- <a id="decided-project-bugs"></a>**Bugs across the restart** (rows P10–P12, 2026-11-05). Old-compiler
  defects are retired with the old implementation, never marked fixed; each keeps its reproducer,
  ruling and structural class, and the reproducers feed the oracle comparisons (P10). Std defects
  move with std as contracts and regressions, and the language rulings become conformance examples
  or recorded owner questions (P11). From day one `ISSUES.tsv` at the root records spec, proof,
  launcher, CI and migration defects (id, date, area, evidence, owner, severity, closure condition,
  status) with a root check (P12).
- <a id="decided-project-roadmap"></a>**The roadmap** (row P15, 2026-11-05). `ROADMAP.md` is one file
  that plans and decides nothing; the previous roadmap is archived with a disposition for each of its
  555 tasks. Mutation testing for the new compiler is a new harness, not a port (P19).
- <a id="decided-project-proof-order"></a>**Compiler proof order** (2026-11-01). The semantic contract
  and the final theorem first, with values-to-bytes a named boundary; then executable Core semantics
  (fuel exhaustion distinct from divergence) with type, ownership and effect soundness; one minimal
  end-to-end path; functional models for safe code; open-module correctness and C contracts; ghost
  permissions for trusted code; SMT-checked lowering; proof-producing equality saturation. Parsing,
  linking and native-image assumptions stay explicit; only kernel-checked proofs count; items 4–7
  are proposed to the owner before each is built
  ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-01--compiler-proof-order)).
  Strengthened 2026-11-05 by [proof infrastructure](#decided-project-proof-infrastructure): the
  minimal path is built in cumulative slices, each used lowering proved as it lands.
- <a id="decided-project-proof-infrastructure"></a>**Proof infrastructure from the first commit and
  cumulative compiler slices** (owner, 2026-11-05: "i want to be able to prove from one point to the
  other things from the beginning, everything should be designed to be proven right"; "we could start
  by simple additions and things but the infra should be there"; "yes first unverified printer to llvm
  and to lean backend we created right"; "and then we can do end to end proof"; Claude and Codex agree).
  - *Slice 0.* The first executable compiler slice is slice 0: one source unit, no imports or grants,
    parameterless `main` returning `u8`, explicitly typed immutable `u8` bindings, representable decimal
    literals, local reads, grouping, checked addition and final return; other forms are refused as
    unsupported. It traverses the actual frontend and each used lowering IR to BIR and two explicitly
    unverified native builds, LLVM and the Lean Compiler Backend (revised 2026-11-06; see *Backend
    order*). Its examples include exit 42 from `20 + 22`, exit 255 at the
    representable boundary, static overflow refusal, out-of-range literal refusal, unused-binding
    refusal and malformed-input rejection; checked addition is proved over arbitrary representable
    operands at the IR boundary, overflow included. Slice 0 work may start as a provisional skeleton
    before the Core freeze (A2c), but it makes no authoritative or normative claim before the freeze.
    Slice 0 is an engineering milestone: it does not replace slice 1's ownership, component/launcher,
    accepted-trap or legacy-retirement obligations, and it does not trigger legacy deletion.
  - *Proofs as each piece lands.* Every used IR has total executable Lean semantics and
    well-formedness conditions. Every implemented lowering lands with kernel-checked preservation and
    output-invariant proofs, directly or through a proved validator; unused future passes are not
    required to exist. Frontend correspondence is stated independently; every undischarged frontend
    obligation is explicit. The shipped compiler is these Lean definitions. Before slice 0's authoritative
    claim, its actual Core fragment is connected to the frozen definitions and any instrumentation
    erasure it uses is proved; later features require integration proofs into that same Core.
  - *The composed theorem from the first slice.* Slice 0 includes a kernel-checked composed theorem
    with separately named undischarged semantic premises (the holes), exact artifact binding, minimal
    provenance and an inventory distinguishing logical axioms, implementation assumptions, execution
    trust and model/environment contracts. Authoritative proofs use no `sorry`, `native_decide` or
    axioms outside `propext`, `Quot.sound` and `Classical.choice`. CI checks both transitive axioms
    and the registered semantic-premise closure, and fails when a stage is covered by neither a
    theorem nor a registered premise. Claims with undischarged compiler implementation obligations are
    labelled conditional.
  - *The holes only shrink.* For an unchanged supported subset and target profile, no undischarged
    obligation may be added or strengthened without owner approval. Splitting, renaming or
    discharging obligations preserves recorded lineage. Extending the subset, runtime, environment or
    target profile publishes an explicit assumption diff; new or strengthened assumptions need owner
    approval.
  - *Example-driven growth.* Features extend this path cumulatively, each with rule-indexed accepted
    and refusal examples, trapping examples where admitted, semantics, checker correspondence, the
    applicable soundness and preservation proofs, a program-specific correctness theorem for its
    motivating example, transport of that theorem to the exact compiled artifact through the composed
    compiler theorem under its named premises, and classified Lean/native differential tests. Programs grow from simple
    examples to file-copy (phase C's acceptance workload) and small real programs, ordered by the
    constructs they need, then to larger real software.
  - *Two kinds of proof.* Compiler correctness (the composed theorem: the executable does what the
    source means, under its named premises) and program correctness (Lean theorems about one program:
    its functional behaviour, failure behaviour and authority) are proved separately; a program is
    fully proven only with both. A postcondition does not establish termination or freedom from
    traps; capability checking establishes allowed authority use, not application correctness.
    Inspection comes from capabilities and proofs. The legacy oracle is a differential cross-check
    only and never overrides the Lean semantics.
  - *Backend order* (revised 2026-11-06 by the owner: the LCB joins slice 0; relayed by the orchestrator from the owner session: asked
    whether the LCB should join slice 0, unverified, with its adapter proven early and an ARM CI job,
    the owner answered "yeah the lean compiler backend should be added i think right?", after stating
    "the objective is to have a first slice of the compiler fully proven with the full best pipeline
    in llvm and lean compiler backend where we prove lean compiler backend in the futgure right"). From slice 0, every
    supported example is built through two unverified backends, BIR → LLVM and BIR → LCB-IR → the
    Lean Compiler Backend, each labelled unverified. BIR is a complete backend contract designed for
    both from its first definition: no BIR construct, invariant or lowering choice depends on one
    backend. CI builds and runs each example through both and compares their full observations
    (exit status, the trap line, startup refusal, later the event traces), never exit codes alone,
    with each other and with the expected outcome; any mismatch fails. The LCB output runs natively
    on a GitHub-hosted AArch64 macOS runner, the platform of the first native proof profile
    ([targets](../ROADMAP.md#targets)), free for this public repository. Rejected: qemu-user on
    concrete-ci-2, which would add an unmodelled emulator to the execution trust and runs only Linux
    binaries; a hosted Linux AArch64 runner, which is not the proof profile's platform; and a
    self-hosted ARM machine, which does not exist (and self-hosted runners never run pull requests).
    Proofs then come in this order: the BIR → LCB-IR adapter's refinement proof is the first backend
    proof target, right after the front-end and lowering proofs; the LP0 pilot composes it with the
    LCB's theorems for the supported subset; native proof closure through the LCB for the profile
    follows the pilot. LLVM and LCB claims have separate assumption inventories, and the end-to-end
    theorem names their premises separately; proving the BIR → LCB adapter removes that adapter
    obligation only when composed with the applicable LCB theorems, and the LLVM profile stays
    unverified.
  - *What it revises.* It amends the new-compiler row (slice 0, not slice 1, gets the first
    BIR → LLVM printer; slice 1 extends the same path) and strengthens the proof-order row's minimal
    path (proofs as each used lowering lands). It adds an earlier subset before row Q8.2's slice-1
    subset and an earlier conditional image theorem before row Q8.1's slice-1 endpoint, neither of
    which upgrades native assurance; Q8.1's source-to-BIR endpoint for slice 1 stands. Rows Q8.3–Q8.7
    (independent frontend judgments, component/launcher separation, exact artifact closure,
    non-vacuity), the freeze sequence (Q9.14, Q9.19; revised 2026-11-06 to A2b → A2i → A2c by the
    [long-term changes](#decided-project-long-term-2026-11-06)), P18 and OD115–OD117 are inherited;
    early example-specific Lean proofs need no new source contract forms. The arithmetic decisions,
    grant schema, target order and retention decisions are not reopened.
  - *Revised 2026-11-06* by the [long-term changes](#decided-project-long-term-2026-11-06): the backend
    order gains a bounded BIR → LCB → native pilot after slices 0 and 1, and per-compilation
    certificates are strengthened to discharge compiler-execution trust where they cover it, any gap they
    leave staying an explicit execution assumption. Revised again on 2026-11-06
    by the owner: the LCB joins slice 0 as a second unverified backend, and its adapter is the first
    backend proof target (*Backend order* above). This revises the new-compiler row's single
    slice-0 BIR → LLVM printer in the same way.
    *Revised 2026-11-08* by [foundation question 17](#foundation-q17): the backend-order equality
    stays, with a per-native-trace Core refinement check; allocation-dependent observations are
    decided at slice 24. The [complete adapter theorem](#decided-2026-11-08-adapter) says an adapter
    error produces no artifact and success implies correctness, retiring the adapter premise (R-0579).
- <a id="decided-project-long-term-2026-11-06"></a>**Long-term changes to the plan** (owner, 2026-11-06:
  after asking "is this the best long term design", the owner was asked whether to accept all five
  changes below (A2i before the freeze, the LP0 LCB pilot, certificates, the modular specification
  with an owner view, adversarial workloads) and answered "1", option 1: accept all five of Codex's
  BEST-WITH-CHANGES recommendations; Claude and Codex agree).
  - *Integrate before freezing.* A new stage A2i comes between A2b and the A2c freeze. It connects the
    separately proved parts of the proposed spec through shared Core interfaces and one integrated
    semantics, and proves their representative interactions: a borrow across deferred cleanup, an
    allocator reset with outstanding loans, and cleanup that needs authority, together with the
    [README obligations](../ConcreteSpec/README.md) O7 (capabilities in the cleanup and brand parts) and O9 (the range-view run
    joined to the static access rules). The semantic contract (R-0496) is part of A2i. The owner then
    freezes integrated scopes, not an untested whole-language architecture; sending Core back after
    the freeze remains a recovery mechanism, not the planned sequence. This revises row Q9.19's
    A2a → A2b → A2c to A2a → A2b → A2i → A2c.
  - *Bound the LLVM hole* (revised 2026-11-06 by the owner: the LCB joins slice 0, quoted in the
    [backend order](#decided-project-proof-infrastructure)). The LCB runs
    unverified beside LLVM from slice 0, and its BIR → LCB-IR adapter is the first backend proof
    target ([backend order](#decided-project-proof-infrastructure)). After B0 and B1 (the slices
    before LP0; [vertical slices](#decided-project-vertical-slices-2026-11-06)) and before the
    language grows large, the LP0 pilot composes that adapter proof with the
    LCB's theorems for the supported subset and with the slice theorem under named premises, kept
    separate from the LLVM premises. Every remaining backend obligation has its own task and
    milestone. "The holes only shrink" prevents regression; this rule requires progress. The LLVM
    path stays unverified, as the owner ordered.
  - *Compiler-execution trust.* Proving the compiler's Lean definitions does not prove that their
    natively compiled executable computes them. Each compilation emits a certificate that the Lean
    kernel checks, connecting the exact input to the exact emitted BIR through proved judgments or
    validators, without trusting native evaluation; the backend input is bound to that BIR (a digest
    gives identity, not semantic correspondence). Wherever a certificate does not close the gap, the
    Lean compiler, runtime and toolchain are listed as explicit execution assumptions. Verifying
    programs compiled through the LCB does not by itself verify execution of the compiler. This
    strengthens R-0552 and R-0521, required from slice 0's first authoritative claim.
  - *One authoritative specification library.* The normative definitions form one library split into
    cohesive modules (for example syntax, ownership, borrows, capabilities, observations), with
    `ConcreteSpec/Spec.lean` kept as the public import; proofs stay in separate files. A browsable
    owner view, generated from the same sources, shows each rule's English doc comment, its examples,
    its dependencies and links to the proofs that cover it; it states no rule of its own. The view
    (R-0555) and the modular layout (R-0560) are delivered before the freeze. The outside-reader check
    (R-0559) runs before the freeze and again for each feature. This revises the
    [Lean-is-the-specification](#decided-project-lean-is-the-spec) row's "one main normative file".
  - *Diversify examples early.* Small adversarial workloads that combine features in difficult ways
    run alongside file-copy from the first slices on, so no single application dictates the
    architecture.
- <a id="decided-project-no-hidden-traps"></a>**No hidden traps and bounded execution** (owner,
  2026-11-06: "ok to the no hidden traps", "we also should be able to know that a function is bounded
  and doesn't have an infinite loop or recursion", "for sure i know i want to be able to know
  beforehand if a function terminates", "for sure i want to know that something can't have hidden
  traps and that we have bounded execution a la spark"). The reviewed proposal (Claude and Codex,
  three rounds, Codex AGREE) and the termination analysis (Codex verdict D-SITE) are archived in
  [no-hidden-traps-2026-11-06](archive/no-hidden-traps-2026-11-06/PROPOSAL.md); the numbers below are
  its owner questions. The owner decided questions 1, 11 and 12 explicitly and stated the
  termination requirement; questions 2–10, 13 and 14 are decided under the owner's rule (Claude and
  Codex agree it is the best long-term design). Spellings stay with the owner (see the end of this
  row). Each guarantee is published only when its evidence lands (R-0574).
  - *No hidden traps (Q1).* Accepted safe code has no reachable implicit language trap: every
    operation that could fail at run time (an index, a division or remainder, an overflowing
    arithmetic operation, a shift, a range, `byte_at` and the other indexed primitives, size and
    offset arithmetic) carries checked evidence that it cannot fail, or its failure is handled by a
    branch written in the source. An explicit `abort()` remains terminal behaviour; stack exhaustion
    and foreign behaviour are named target and trust premises. The Core semantics keeps its trap
    outcomes (an unchecked Core program can trap); admission rules them out for accepted programs,
    and the theorem is `checked_no_implicit_traps`: an accepted program's run never ends in an
    implicit trap.
  - *Evidence (Q2, Q4, Q7, Q8, Q9).* A decidable, deterministic checker whose soundness is proved in
    Lean decides integer octagons (`±x ± y ≤ c`) over typed place versions in mathematical integers,
    with exact copies, translations and sign changes, interval products and quotients, atomic
    disequalities taken from written conditions, and fixed limits that are part of the
    specification (a limit gives "not established", never a guess); the richer two-variable form
    (TVPI) comes only if workloads need it. No SMT solver, and [OD117](#od117) stands. A claim used
    to admit an operation needs closed evidence: a `#[requires]` used for safety is discharged at
    every call, including external entry points (an exported function's precondition joins its
    foreign contract; `main` relies on nothing beyond the launcher's contract); a callee's
    `#[ensures]` counts only when proved (or a named trusted assumption) for the state after all
    returning cleanup; an `#[invariant]` needs proved initialization and preservation. `assume` and
    assumed evidence cannot admit an operation in safe code, and a vacuous precondition used for
    safety is refused in every build. A generated run-time check is removed only where its
    operation has operation-specific discharged evidence (PASS-9).
  - *When the checker cannot see it (Q3, Q6).* The author writes a guard, a precondition with closed
    evidence, a named operation (wrapping or saturating, already decided, or a new checked operation
    returning `Result` for `+ - * / % << >>` and unary `-`, with distinct errors for overflow, zero
    divisor and invalid shift), or names through the evidence ledger a Lean theorem whose statement is
    exactly the generated residual obligation, bound to the typed identities, contracts, checker
    version and target. Plain `a + b` stays the normal spelling; it needs evidence.
  - *Loops (Q5).* One structural rule for both loop forms and no new loop form: the loop's write
    footprint is forgotten at the head, a counted loop's bounds are snapshotted before the first
    iteration ([OD47](#od47)), an `#[invariant]` is checked on entry and on every back edge, and the
    exit state joins every normal exit; no inferred fixpoints.
  - *Bounded execution (Q11, Q12).* Each function has separate facts in the evidence ledger, each
    proved, conditional on named trusted assumptions, or not established with its reason:
    terminates, recursion depth bound, stack bound (for the final artifact and target), may-abort,
    may allocate, may block, may call foreign code. *Bounded* is derived: terminates and a stack bound
    both established; it gives no execution-time deadline. A counted loop bounds its iterations
    (`max(0, b₀ − a₀)`); a `while` loop needs a proved `#[variant]`; a recursive cycle (including
    cycles through indirect calls, callbacks and re-entry) has one measure, written as a
    function-level `#[variant]` ([OD82](#od82) extended), decreasing on every call edge inside the
    cycle; a loop or cycle terminates only when its bounds, guards, bodies, callees and cleanup
    terminate too. A Lean termination theorem (row P18) closes termination only; depth and stack
    need their own evidence.
  - *Every function has termination evidence with its premises, or a report naming the explicitly
    permitted unresolved obligations (Q13, "d-site"; wording revised 2026-11-08,
    [ISS-0014 F7](#decided-2026-11-08-f7)).* Termination evidence is required by default.
    Every undischarged termination obligation must carry an explicit permission at its source: the
    loop, the recursive cycle, the indirect call, or the external, foreign or blocking boundary;
    otherwise the program is refused. A permission covers only its identified obligation and never
    waives a nested loop, a callee or a callback. It is a checked permission to leave that obligation
    open, not a claim that the code diverges, and not a function category, function-type
    distinction or calling convention ([OD116](#od116) stands). Summaries compose through calls,
    callbacks, cleanup and re-entry; callers need no repeated permission, and every report shows the
    source permission and the call path. So before running, every function has either termination
    evidence with its premises or an explanation naming the written permission responsible. Generic
    functions are proved parametrically under checked premises or per instance; analysis failure
    is never permission.
  - *Policies (Q13).* The other facts are derived, reported and conservative (a capability shows
    permission, not occurrence). A written module or project policy may require any of them at named
    boundaries (established termination, a recursion depth or stack bound, no abort, no allocation,
    no blocking, no foreign code), states whether named trusted assumptions are acceptable, and reads
    the same summaries as the reports, so a newly added permitted dependency cannot silently remove a
    core's guarantee. The old Predictable profile ([OD124](#od124)) is not equivalent and stays in the
    refusal chapter.
  - *Stack (Q14).* Target-contract work, not a current guarantee: first, adequate stack excludes
    exhaustion (if the reserved stack is at least the artifact's bound, no run exhausts it, and the
    launcher refuses to start with status 125 when it is smaller); second, a defined outcome for
    inadequate stack, which needs probes, failure handling and a target status of its own.
  - *Order (Q10).* Within the A2i integration, before the freeze, the spec gains the Core admission
    rules, the checker as an executable Lean definition with its correspondence and soundness proofs
    (the specification's checker is the checker the compiler runs, as for every other rule), and
    `checked_no_implicit_traps`. With the slices (phase B) follow the compiler's use of it at each
    stage, the per-function facts report and the per-compilation evidence. Slice 0 is unchanged (its
    values are all known; `slice0_never_traps` is the first instance). The spec example `add100`,
    accepted today with an input-dependent trap, becomes a refused example with accepted guarded
    variants.
  - *Rows revised.* [OD10](#od10) and ARITH-3 (checked by default with an abort becomes: evidence
    required, named forms for the rest), MEM-6 (abort out of range becomes: evidence required), MEM-9,
    ARITH-13 and [OD118](#od118) (refusal of proven violations is subsumed by refusal of unproven
    safety), Q4.6 and Q4.7 (`byte_at` and the range form without `else` need evidence; the open
    question on refusing a provably out-of-range view index disappears), Q6.1 and Q6.2 (static refusal
    widens from proven violations to unproven safety; known values remain facts), [OD97](#od97) (the
    profile option is subsumed), and ARITH-9: `#[overflow_checked]` is retired (owner, 2026-11-06, relayed by the orchestrator from
    the owner session: "ok do everything", approving the unanimous recommendation of Claude, Codex,
    agy and Kimi to retire it as obsolete under no hidden traps). Qualified: CON-2, Q9.11 and [OD125](#od125) (a claim used for safety
    admission needs closed evidence), CON-6 and [OD80](#od80) (`assume` cannot admit an operation in
    safe code), [OD120](#od120) (a vacuous precondition used for safety is refused), [OD82](#od82)
    (extended to functions), Q7.10 and Q8.5 (extended by the stack target-contract obligations of Q14, which are future target work, not current guarantees). Unchanged: STMT-1, STMT-2, OD101 (general trap semantics), Q6.3–Q6.6
    (with the interactions stated in the proposal), CON-1 and P18.
  - *Spellings* (owner, 2026-11-06: "ok agreed with the 3 decisions"; checked by Codex, agy and Kimi,
    whose shared refinements are recorded here under the owner's rule that what Claude and Codex agree
    on is recorded).
    1. *Checked operations*, in [OD99](#od99)'s family: `checked_add`, `checked_sub`, `checked_mul`,
       `checked_div`, `checked_rem`, `checked_shl`, `checked_shr` and `checked_neg`, each returning
       `Result<T, ArithmeticError>` with `ArithmeticError { Overflow, DivisionByZero, InvalidShift }`.
       Signed `MIN / -1` and `MIN % -1` give `Overflow`. `checked_shl` and `checked_shr` fail only on an
       invalid shift count (`InvalidShift`); a valid shift keeps the decided bit-discarding semantics.
       `ArithmeticError` is separate from `try_convert`'s `OutOfRange` ([OD106](#od106)).
    2. *Naming a Lean theorem*: `#[proof(path::to::theorem)]`, repeatable, on the function
       declaration. The path resolves to a typed theorem identity, never a string (rule 13), and the
       axiom and dependency checks stay mandatory. The theorem's role follows from its statement:
       (a) a statement of obligation form for this function that exactly equals a current generated
       obligation discharges it, and every discharge edge is recorded, each obligation identity with
       its own edge even when several obligations are identical, never by first match; (b) a statement
       of obligation form that matches no current obligation (stale or mistyped) is refused with a
       diagnostic, never reclassified; (c) any other statement must refer to the annotated function's
       current semantic identity or its generated semantic contract, and is recorded in the facts as a
       proven property; (d) a theorem unrelated to the function (for example one proving `True`) is
       refused.
    3. *The termination permission*: `#[may_not_terminate("reason")]`, with a mandatory, non-empty
       reason. It attaches before a `while` loop; on one designated function per recursive component,
       waiving only that component's cycle obligation (a second marker for the same component is
       refused); on an extern or blocking declaration; or as a prefix to an expression, where the
       checker requires the target to be an indirect call. It never relaxes [OD115](#od115):
       specification functions stay total. Grammar, which must stay LL(1) and is checked mechanically:
       a statement factors one leading attribute-prefix production before branching on loop or
       expression statement; an expression attribute attaches to the immediately following postfix
       expression (so `#[may_not_terminate("r")] fp(x) + g()` attaches to `fp(x)`); the checker
       classifies the targets. This extends [OD82](#od82). The grammar data in ConcreteSpec is updated
       in the spec work (A2i).
- <a id="decided-project-core-statement"></a>**The core statement** (owner, 2026-11-06: "concrete core
  idea is to be fully proven system programming language with no gc where i can know everything").
  README.md and PHILOSOPHY.md open with it: Concrete is a fully proven systems programming language
  with no garbage collector, where you can know everything a program does: what it does, what it may
  touch, whether it can fail or stop, and what is proved about it. "Fully proven" means the decided
  proof model ([proof infrastructure](#decided-project-proof-infrastructure)): compiler correctness
  is proved end to end, with every unproven step named as an explicit assumption and never silently
  trusted, and a program's own correctness is proved by Lean theorems about it. The statement says
  what the language is for, not what is proved today: each guarantee holds only as its evidence
  lands, compiler correctness and program correctness need separate proofs, and native claims remain
  conditional on their named assumptions (the unverified LLVM path among them).
- <a id="decided-project-facts-report"></a>**The per-function facts report from slice 0** (owner,
  2026-11-06: "we need to know from the start if a function is doing what etc"). The report that
  answers "what may this function do" is a slice-0 deliverable (B0, R-0575), not a phase-F addition.
  For each function it states, derived from the Lean rules and never claiming what they do not
  establish: the capabilities used and the grants and resources actually reachable; allocation and
  the allocator; trusted, foreign and opaque boundaries and the assumptions they carry; every
  operation that could fail and how it is handled (proven safe, a written branch, a checked
  operation); termination (termination evidence with its named premises, or the responsible source
  permission and the call path to it); the recursion
  depth and stack bound, or why none is established; proof status (each obligation and the theorem
  that discharges it); and whether the report is complete. Its schema is versioned and readable by
  people, CI and language models. From slice 0 the compiler also answers queries over the same facts
  (owner, 2026-11-06: "i want to have since the get go the ability to ask the compiler what a function
  can do, allocate, etc"): asked about one function or module, it returns that function's facts,
  each with its reason and evidence, both as readable text and in the versioned machine format. The
  report and the query are one fact source, not two implementations. Slice 0's facts are small, but
  the machinery exists from the first commit and grows with each feature. Revised 2026-11-07 by the
  [early-evidence decision](#decided-2026-11-07-early-evidence): the JSON schema for diagnostics and
  facts is frozen and versioned from the first front-end output, with golden tests; R-0178 keeps its
  compatibility policy. R-0494 grows this fact source into the single verdict authority, and R-0201
  builds the audit commands (`audit`, `explain`, `why`, `diff`) on the query. The query's
  command is `concrete facts` ([slice-0 surface](#decided-slice0-surface-2026-11-06)). It continues the legacy compiler's `--report` family (effects, caps, alloc, recursion,
  stack-depth), re-derived from the new rules. The design, checked by Codex, agy and Kimi (each
  ACCEPT-WITH-CHANGES, converging on the points below, recorded under the owner's rule that what
  Claude and Codex agree on is recorded):
  - *One derivation.* Every fact is a typed judgment defined in Lean, with a derivation-soundness
    theorem, and an obligation-discovery completeness theorem wherever it claims an absence. One
    derivation feeds the readable view, the machine format and every policy; the legacy compiler
    drifted with three independent producers.
  - *Closed status per fact:* established; conditional (on named assumptions, transitive debt from
    `assume`, unproved invariants, trusted or foreign contracts); refuted (with a witness path); not
    established (with the blocker and its site); not applicable. Coverage is stated per fact, not as
    one global flag, and an unknown fact never satisfies a policy.
  - *Separate vocabulary.* Empty capabilities do not mean "touches nothing": authority (`with(...)`),
    resources (handles, allocators, `Kept<H>`) and memory reads and writes through `&mut` and borrows
    are separate facts. "Can fail" is split into discharged implicit-trap sites, `Result` errors,
    explicit `abort`, allocation failure, stack exhaustion and foreign behaviour. Determinism,
    information flow, constant time and concurrency are separate future judgments; termination and
    a stack bound imply none of them.
  - *Honest numbers.* A stack number comes only from final-artifact and target evidence, never from a
    source estimate. An opaque, indirect, foreign or recursive path without sufficient evidence gives
    "not established", never a finite guess; proved depth and evidence covering every possible target
    may establish a bound using final-artifact frame sizes, while a bound relying on named trusted
    contracts stays conditional. "Bounded" never implies a wall-clock deadline.
  - *Composition.* Local and transitive summaries, module rollups and drill-down to the call site and
    obligation; transitive through indirect and opaque calls, cleanup and callbacks; fail-closed.
  - *Policies consume the same facts.* A policy such as the
    [predictable policy](#decided-project-predictable-policy) is a named, versioned bundle over these
    facts, never a second analysis or semantics mode ([OD124](#od124)); its result is satisfied,
    violated or incomplete, and only satisfied passes. Requiring termination rejects permitted
    divergence.
  - *Identities and versions.* Typed identities (module, function, instance; no bare-name
    collisions); versioned schema and semantics; units; deterministic order; machine-readable
    reasons; replay commands; every answer bound to the compiler, spec, dependency, target and
    artifact digests. An unknown version never satisfies CI.
- <a id="decided-project-predictable-policy"></a>**The predictable policy** (owner, 2026-11-06: "yes
  this is critical"). An optional policy a module or project turns on, built on the per-function facts
  ([facts report](#decided-project-facts-report)): every function in its scope allocates nothing,
  never blocks and calls no foreign code, and, where the policy demands it, has termination evidence
  and a stack bound. Where the policy is on, a violation is refused at compile time, naming the
  function, the fact and its source; the facts query reports which policy covers each function. It
  follows the slice-0 facts report and query and is required from slice 1 (R-0576), not deferred.
  Admission requires established evidence of no allocation, no blocking and no foreign calls; an
  unknown or incomplete fact is refused. The policy explicitly states whether named trusted
  assumptions are acceptable, as required by Q13. It takes up the idea of the
  legacy predictable profile and of R-0220 (PredictableV1, deferred with a trigger), replacing that
  trigger by this decision; unlike R-0220's draft it admits no allocation at all, bounded or not.
  It is a policy over reported facts, not a function category (OD116) and not a build profile that
  changes behaviour (OD124).
- <a id="decided-project-reproducible-builds"></a>**Reproducible builds from slice 0** (owner,
  2026-11-06: "yes to this too"; revised 2026-11-07: "can we have reproducible builds since the
  beginning right?" and "ok add the reproducible asap"). From slice 0, the same source, compiler
  revision, toolchain pin and target give byte-identical output: the BIR, LLVM IR text, LCB job and
  output, and final binary (R-0577). The toolchain pin covers the nix flake, LCB revision and
  LLVM/clang version. Artifacts contain no timestamps, absolute paths or host names
  (`-ffile-prefix-map`, `SOURCE_DATE_EPOCH`, deterministic link order), and compiler output never
  depends on hash-map iteration order. CI builds every slice-0 example twice in different
  directories and on two machines (a GitHub runner and concrete-ci-2), compares SHA-256 and fails on
  any difference. `concrete facts` carries the build identity: compiler SHA, toolchain pins and
  target. This moves the reproducibility half of R-0104 (merged into R-0149 in phase G) to B0;
  R-0149 keeps incremental-build equivalence. The slice-0 worker owns the work on `wip/slice0` when
  Claude capacity returns; work started on `wip/slice0-repro`.
- <a id="decided-project-concrete-toml"></a>**Policies and declared assumptions live in
  `Concrete.toml`** (owner, 2026-11-06: "concrete.toml is fine", in place of a separate policy
  file). A project's policies, such as the
  [predictable policy](#decided-project-predictable-policy), and its declared assumptions (target,
  heap, stack, foreign functions and the trusted surface) are written in the project's
  `Concrete.toml`. There is no separate policy or assumptions file.
  - *Typed, versioned data.* Policy and assumption sections are typed and versioned; an unknown
    section, key or version is refused, never ignored.
  - *Only tightening.* A module may tighten a project policy, never relax it.
  - *Dependencies.* A dependency's `Concrete.toml` never relaxes the consumer's policy: dependencies
    are checked against the consumer's policy, transitively and fail-closed.
  - *Assumptions.* Assumptions are declared only where the facts cannot derive them. The facts query
    reports each one with the facts that rely on it, and any change to the declared set is reported
    as an assumption diff that fails CI until it is recorded with the change (R-0589).
  - *Tables* (owner, 2026-11-06: "ok do everything", after Claude, Codex, agy and Kimi chose unanimously). The sections are the typed, versioned `[policy]` and `[assumptions]` tables;
    an unknown key or version is refused. Slices 7 and 19 extend them.
- <a id="decided-project-os-sandboxing"></a>**OS-level sandboxing is outside the compiler's scope**
  (owner, 2026-11-06: "shouldn't be even part of a compiler, that's something the user can decide"). OS-level sandboxing
  (seccomp/landlock, Capsicum, pledge/unveil) is outside the compiler's scope; users may apply it
  themselves. No task or option covers it.
- <a id="decided-project-diagnostics-2026-11-06"></a>**Diagnostics are checker outputs** (owner,
  2026-11-06: "a", option (a) on every question of the [proposal](archive/crucial-2026-11-06/DIAGNOSTICS.md), reviewed by
  Codex, agy and Kimi). The checker returns a typed result, never a Bool, and every diagnostic is
  one record rendered several ways. Rule IDs are the Lean rule's name plus that rule's own revision
  (for example `StmtOk.let_.admitted@2`), bumped when the rule's meaning changes, including through
  its dependencies, and checked; retired IDs stay in a registry (revised 2026-11-06 (owner, 2026-11-06: "ok do everything", after Claude, Codex, agy and Kimi chose unanimously), replacing
  "plus the spec version"; R-0603); there are no numeric codes. Fixes are offered only after being rechecked and
  labelled with their status; only a fix proved meaning-preserving by a lemma may be applied
  automatically. There are no warnings: weaker findings are facts, and policies may refuse them.
  Output is human text on a terminal and JSON lines otherwise, both from the one record, forced by
  `--format=human|json`. The checker result type is fixed in A2i, before the freeze (R-0592); the
  record, its JSON schema, goldens and the parser's diagnostics land in B0 (R-0593). It refines
  R-0479.
- <a id="decided-project-memory-2026-11-06"></a>**Heap facts and memory policies** (owner,
  2026-11-06: "a", option (a) on every question of the [proposal](archive/crucial-2026-11-06/MEMORY.md), reviewed by Codex,
  agy and Kimi). Each function reports, per allocator lineage, requested bytes, net change and peak
  in logical bytes, and the allocator footprint where its contract defines one; each is a sound
  bound with a status, or "not established". Bounds are polynomials with `max` over counts, lengths
  and depths. Std states a growth upper bound for each container operation. Policies may guarantee
  both logical bytes and footprint. Budgets are written only in `Concrete.toml` policies
  ([row](#decided-project-concrete-toml)). "Allocation cannot fail" is a derived fact, established
  only from an allocator success theorem. Stack stays a separate fact from target artifacts. The
  byte-accounting instrumentation is fixed in A2i (R-0592); slice 0 proves its zero-heap facts
  (R-0594); the analysis, its theorems and the policy entries come with the allocation slice
  (R-0595), not in phase E.
- <a id="decided-project-infoflow-2026-11-06"></a>**Secrets, noninterference and constant time**
  (owner, 2026-11-06: "a", option (a) on every question of the [proposal](archive/crucial-2026-11-06/INFOFLOW.md), reviewed
  by Codex, agy and Kimi). Noninterference and constant time are two separate claims (authority
  rule 14), each a theorem about the source semantics of every accepted program, holding at the
  binary only under named backend premises. The surface is the type `Secret<T>`, with `classify`,
  `declassify(x, "reason")`, `ct_select` and `ct_eq`; a `declassify` is traced in the facts like a
  `#[may_not_terminate]` permission. Control flow on a secret is refused (write `ct_select`);
  container lengths are public, and a secret length is refused. `Secret<T>` is `Copy` only for
  scalar `T`; secret arrays and heap secrets are linear and wiped on destroy, which revises
  [Q2.2](#q2-2-revision). The observer model is the baseline constant-time model (branches, exact
  addresses, variable-time operations); speculative leakage is not covered. The leakage-trace
  interface is fixed in A2i (R-0592); `Secret<T>` lands as its own slice with its proofs (R-0596).
  Its sources include the pure `classify` of a value passed in; grant-backed sources come with the
  console, files and network ([vertical slices](#decided-project-vertical-slices-2026-11-06)).
  Revised 2026-11-07 by the [randomness decision](#decided-2026-11-07-stack-randomness): the entropy capability arrives at slice 6, yields
  `Secret<T>` at slice 7 and gains fill-bytes at slice 15, with its source named as a trusted premise
  in facts.
  Extended 2026-11-08 by the [foundation decision](#foundation-q18): `Secret<T>` has exactly `T`'s
  layout; layout does not establish constant time, the information-flow rules do.
- <a id="decided-project-pipeline-2026-11-06"></a>**The new compiler pipeline** (owner, 2026-11-06,
  relayed by the orchestrator from the owner session: the owner asked "is there any way to improve the full compiler design or pipeline?"; after
  the Codex, agy and Kimi pipeline review was reported, "did we also log that we will have the new
  compiler pipeline that we designed in this session?" and "ok decisions is fine"; the open set was
  then approved with "ok do everything"; reviewed by Claude, Codex, agy and Kimi,
  [review](proposals/MERGED.md)). It
  supersedes the pipeline of [VERIFIED_PIPELINE.md](../legacy/docs/compiler/VERIFIED_PIPELINE.md).
  The slice-0 design (`Concrete/README.md`, on branch `wip/slice0`) becomes the detailed
  description once it lands.
  - *Stages.* Bytes → lexer → LL(1) parser (the grammar is data, with a mechanical LL(1) check) →
    AST → resolve → HIR (the resolved surface only) → elaboration → Core → checker → CheckedCore
    (the single admission point, with its certificate and discharged-evidence tokens; admission
    is re-checked after Mono) → Mono Core → Place MIR (which only expands residual checks) →
    Memory CFG (layout, ABI, byte and provenance memory) → SSA → BIR. BIR is a complete backend
    contract: layout, endianness, calling convention, trap kind and site, and the frame-accounting
    handoff.
  - *Backends.* From BIR, an unverified LLVM printer, and the BIR → LCB-IR adapter (the first
    backend proof) feeding the Lean Compiler Backend on AArch64, proved later. Both run from slice
    0, and CI compares their full observations ([backend order](#decided-project-proof-infrastructure)).
  - *Proof per stage.* Direct proofs for the lexer and parser (a correspondence theorem), resolve
    and elaboration, sequencing, cleanup, representation lowering and BIR → LCB-IR. Proved
    validators for Mono, SSA (a direct proof is allowed in slice 0), optimizations, register
    allocation and linking. After slice 0, per-edge certificates replace the whole-compiler
    `decide` certificate (R-0582, R-0583).
  - *The theorem.* The end-to-end theorem has named premises, with the LLVM and LCB premises
    separate; the holes only shrink.
  - *One evidence graph.* Facts, diagnostics and source sites come from one evidence graph with
    typed site identities.
- <a id="decided-slice0-surface-2026-11-06"></a>**The slice-0 surface** (owner, 2026-11-06, relayed by the orchestrator from the owner session:
  presented as four questions with option (a) recommended, the owner answered "for the decisions a
  is okay").
  The commands are `concrete build` and `concrete facts` (the [facts query](#decided-project-facts-report)).
  A form the language decides but the current slice does not yet support gets its own refusal,
  "not supported in this slice", distinct from a refusal of an invalid program, so the two are never
  confused. An integer literal with a leading zero (such as `007`) is refused, so no literal reads as
  octal. The trap site an executable reports is a named premise of the theorem until it is proved
  (spec obligation O4).
- <a id="decided-project-vertical-slices-2026-11-06"></a>**Thin vertical slices**
  (owner, 2026-11-06, relayed by the orchestrator from the owner session: "and let's have vertical slices where everything is proven and work
  first with integers right?", then "reorder based on what you believe is more important" and "have
  the full slices thought and ranked in order by you, codex, kimi and agy, they should decide it
  together"; the agreed order was approved with "ok do everything"). The language grows in thin vertical slices, each fully proven end to end
  (source, every stage, BIR, both backends, facts and diagnostics, conformance examples) before
  the next starts, so every construct is proven on the whole path as soon as it lands and no stage
  runs ahead of its proofs. "Fully proven" means proven under the named premises the
  [backend order](#decided-project-proof-infrastructure) permits: the source-to-BIR stages are
  proved; the LLVM build stays unverified and qualified by tests; the LCB path carries named premises
  until its proof lands (the adapter first, then LP0), the two backends' premises kept separate.
  The order (owner, 2026-11-06: "ok do everything", after Claude, Codex, agy and Kimi chose unanimously) is the agreed slice plan in the [roadmap](../ROADMAP.md#vertical-slices), with
  the common acceptance shape: slice 1 stays row [Q8.2](#q8-2-revision) and gains the explicit
  `abort()` (moved from slice 3), LP0 follows slice 1 before any growth, integers are complete at
  slice 2, authority comes at slice 6 and secrets at slice 7, file-copy and 0.1 at slice 18,
  RocksDB after slice 25 and ethlambda after slice 27. Slice 7's secret sources include the pure
  `classify` of a value passed in, with no wrapper duplicating it, and the entropy capability's
  `Secret<T>` output under the [randomness decision](#decided-2026-11-07-stack-randomness);
  grant-backed sources come with the console, files and network. Before RocksDB and ethlambda are accepted, their programs are
  audited, and a real need for concurrency or foreign function values goes to the owner (R-0604).
  Revised 2026-11-07 by the [final-slice decision](#decided-2026-11-07-final-slices): the approved
  order gains slice 28 for concurrency, with ethlambda and the encrypted tunnel after it. Slice 27
  keeps httpget, tcpserve and the sequential web server.
- <a id="decided-2026-11-07-step-bounds"></a>**Step and time bounds** (owner, 2026-11-07: "ok go
  ahead all yes then as you said right", approving the recorded recommendation). This answers when
  quantitative bounds arrive and what they mean. The step-counting cost model is built with loops at
  slice 4 and extended through calls at slice 5; proofs of step bounds are available at slice 8.
  Bounds count abstract operations in input and pattern size. A wall-clock claim needs separate
  backend evidence; a step bound is not a wall-clock deadline.
- <a id="decided-2026-11-07-showcases"></a>**All seven showcases** (owner, 2026-11-07: "showcase i
  would like everything right?"). This answers which of the proposed showcases to adopt: all seven,
  with the Codex/Kimi placements recorded in the [showcase plan](proposals/EXAMPLES.md#showcases):
  - `grep`: slices 16 → 18 → 22 for dynamic patterns;
  - image decoding: QOI at slices 19 → 21, PNG with DEFLATE at slices 21–22;
  - the EVM interpreter: slices 15 → 21 → 23;
  - the embedded key-value store: slice 23, with durability "not established" and the RocksDB
    comparison at slice 25;
  - the WebAssembly sandbox: slices 21 → 23 → 26;
  - the crypto flagship: slices 7 → 15 → the file encryptor at 18, then the encrypted tunnel after
    slice 28 and the randomness/nonce audit;
  - the static web server: sequential at slice 27, with its concurrent version after slice 28.
  Each showcase states its functional, resource, authority and backend claims separately. Codex and
  Kimi recommended all seven; agy recommended grep, QOI, EVM and the tunnel.
- <a id="decided-2026-11-07-final-slices"></a>**Concurrency is the final slice; ethlambda and the
  encrypted tunnel follow it** (owner, 2026-11-07: "concurrency i want to leave at the last task"
  and "ethlambda can't be done before conccurency"; the tunnel placement was approved with "ok go
  ahead all yes then as you said right"). This answers the concurrency and ethlambda scheduling
  questions and the follow-up about the tunnel. Slice 27 is clock, network and devices and keeps
  httpget, tcpserve and the sequential web server. Slice 28 is concurrency, the last language slice;
  ethlambda acceptance and the encrypted tunnel come after it, the tunnel after the
  randomness/nonce audit. The file encryptor at slice 18 is the encryption showcase until then.
  RocksDB after slice 25 needs no concurrency and remains the earliest full real program for the
  legacy-deletion trigger. The reviewers' suggested structured/scoped spawn-join model with linear
  ownership transfer and no shared mutable state is not an owner decision; the concurrency model
  remains to be decided when slice 28 comes.
- <a id="decided-2026-11-07-tools"></a>**Developer tools** (owner, 2026-11-07: "ok go ahead all yes
  then as you said right", approving the recorded recommendation). This answers when the tools
  arrive: the test runner lands at slice 8 with `#[test]`, extends to modules at slice 17, and the
  formatter lands at slice 17. The LSP comes later.
- <a id="decided-2026-11-07-performance"></a>**Speed tracking** (owner, 2026-11-07: "ok go ahead all
  yes then as you said right", approving the recorded recommendation). This answers when performance
  is measured and how it is reported. Flagship runtime is tracked from slice 2. Compiler wall time,
  per-stage time and memory are tracked from slice 0. Every measurement is recorded by exact SHA,
  backend and target, and is report-only until the noise is understood. Revised 2026-11-08 by the
  [compile-speed budget](#decided-2026-11-08-compile-budget) and
  [speed target](#decided-2026-11-08-speed-target): the compile-speed budget is tracked per example;
  speed and size stay report-only until the owner sets a target against C from measured data at
  the first real showcase (grep, slice 16).
- <a id="decided-2026-11-07-stack-randomness"></a>**Early stack bounds and randomness** (owner,
  2026-11-07: "1 and 2 should be done early too", referring to stack-overflow bounds and randomness
  in the coordinator's "what are we forgetting" list; then "ok let's add it", approving the
  coordinator's exact slices):
  - *Stack bounds.* From slice 0, `concrete facts` reports each program's maximum stack use,
    measured from the final binary on both backends. An unknown bound, or one over the
    `Concrete.toml` stack budget, is refused, so stack overflow is never a hidden trap. Slice 5
    (recursion) extends it with proven bounds.
  - *Randomness.* An explicit entropy capability, granted to `main` like the other grants, arrives
    with capabilities at slice 6. Its output is `Secret<T>` at slice 7, and fill-bytes arrives with
    arrays at slice 15. Its source (for example `getrandom`) is a named trusted premise in facts.
- <a id="decided-2026-11-07-early-evidence"></a>**Five cheap early items** (owner, 2026-11-07:
  "ok let's do 1, 2, 3, 4, 5", approving the coordinator's list):
  - *Trusted-base statement.* From slice 0, `concrete facts` states what is not proven: the Lean
    kernel, LLVM printer and LLVM, LCB's MIR→assembly step, linker, OS and named runtime premises.
  - *Differential fuzzer.* A random-program fuzzer runs against the Lean evaluator, starting with
    the slice-0 front end and growing one feature per slice. It runs on concrete-ci-2.
  - *Sanitizers.* From slice 0, every example's LLVM output is also built and run under
    AddressSanitizer and UndefinedBehaviorSanitizer in CI. Revised 2026-11-08
    ([UBSan](#decided-2026-11-08-ubsan)): UBSan is dropped, since it instruments C at clang's front
    end and checks nothing on LLVM IR input; ASan stays.
  - *Binary size.* From slice 0, binary size is tracked per example per commit next to speed
    tracking, report-only. Revised 2026-11-08 by the
    [compile-speed budget](#decided-2026-11-08-compile-budget) and
    [speed target](#decided-2026-11-08-speed-target): the compile-speed budget is also tracked per
    example; speed and size stay report-only until the owner sets a target against C from measured
    data at the first real showcase (grep, slice 16).
  - *JSON schema.* A frozen, versioned JSON schema for diagnostics and facts output, with golden
    tests, starts with the first front-end output.
- <a id="decided-2026-11-07-tracking"></a>**Where these decisions and their work are tracked** (owner,
  2026-11-07: "ok let's add all this right? where is the best place? should we track also in docs and roadmap or changelog?", after the coordinator's table of a home and a gate for each item). One home per
  fact, and no new documents:
  - `docs/decisions.md` holds the decision and the owner's quote;
  - `ROADMAP.md` holds the work and its slice and, for each item, its home (spec or tooling) and its
    gate;
  - `changelog.d/` holds what landed, written at landing time;
  - the Lean spec holds the language meaning: the stack-bound claim and the budget refusal, the
    entropy capability and its premise, the trusted-premise list, and the diagnostics and facts
    types as the source of the JSON schema;
  - `Concrete/README.md` and `required-checks.txt` hold the gate list, and the check scripts and CI
    enforce it.
  The gates are: reproducibility (two directories, two machines, hashes compared); stack (the
  final-artifact bound against the claim); a trusted-base golden; the fuzzer (short in CI, long
  nightly on concrete-ci-2); ASan (UBSan dropped 2026-11-08, [row](#decided-2026-11-08-ubsan)); speed and size, report-only; and the JSON schema
  generated from the Lean types, with goldens. All of them join `required-checks.txt` when the
  compiler lands on main.
- <a id="decided-2026-11-07-cleanup"></a>**The documentation and tooling cleanup** (owner,
  2026-11-07: "ok go ahead all yes then as you said right", approving the Codex/Kimi cleanup list).
  This answers whether that cleanup may proceed; it does not perform it. The approved scope is:
  simplify `AGENTS.md` by dropping the legacy-only `/file-bug`, `/fix-bug`, ledgers and campaigns;
  make `CLAUDE.md` a one-line import of `AGENTS.md`; simplify `SELF_HOSTED_RUNNERS.md`, `LANDING.md`,
  `ConcreteSpec/README.md`, `README.md`, `ROADMAP.md` (the dead `check_roadmap.sh` reference and
  "when wip/philosophy lands") and the `PHILOSOPHY.md` opening link; remove legacy handling from
  `train.sh`, `bot.sh`, `resolve_conflicts.py` and `gates_remote.sh`, including the false reuse
  claim; fix the stale parts of `.claude/commands/land.md` and `creview.md`; refresh proposals
  `IDEAS.md`, `MERGED.md` and `SPARK.md`; fix
  `changelog.d/2026-11-06-facts-report-readers.md` now that model-first reading is decided; remove
  the dead `prepush_record.sh` and `treestate.sh`; delete `scripts/land/legacy_move.sh` and
  `move_prereqs.py`, leaving them in git history, and the empty `required-checks-transition.tsv`,
  updating the inventory, retention and `legacy_frozen` diagnostics.
- <a id="decided-2026-11-07-foundation-first"></a>**The foundation first, then per slice** (owner,
  2026-11-07: "ok to option b then for freeze the foundation>?", answering what of the spec is
  written before the freeze with option (b), the foundation then per slice). Before slice 1 builds
  on it, the shared foundation is fully written in the Lean spec and frozen: types, values and
  layout, ownership and places, capabilities and grants, outcomes and traps, the step model's shape,
  and the diagnostics and facts types. Each later slice adds its own rules on top of that foundation
  without rewriting it. Changing a frozen foundation definition is an owner decision: the earlier
  proofs are re-run and the change is recorded here. This answers the scheduling question S1 of the
  [spec plan](proposals/SPEC_UNIFICATION.md#51-answered-scheduling-questions-coordinator-2026-11-06),
  which had proposed writing every slice's spec side before the freeze. What the foundation contains
  is the [next row](#decided-2026-11-08-foundation).
- <a id="decided-2026-11-08-foundation"></a>**The Lean foundation: contracts C1–C10 and the answers to
  its questions** (owner, 2026-11-08: "ok all recommended", answering every question of the
  [foundation proposal](proposals/FOUNDATION.md), draft 3, with its recommendation; the proposal was
  reviewed by Codex, Kimi and agy in four rounds and by Claude, and its last edit was checked by Codex
  and Kimi). The foundation is ten contracts, each an interface with its laws, written in the Lean
  spec ([C1 execution, calls and cleanup](proposals/FOUNDATION.md#c1-execution-calls-and-cleanup),
  [C2 scalars, failure and arithmetic](proposals/FOUNDATION.md#c2-scalars-failure-and-arithmetic),
  [C3 target, layout and representation](proposals/FOUNDATION.md#c3-target-layout-and-representation),
  [C4 byte memory and value validity](proposals/FOUNDATION.md#c4-byte-memory-and-value-validity),
  [C5 dynamic borrow, brands and authority](proposals/FOUNDATION.md#c5-dynamic-borrow-brands-and-authority),
  [C6 observations, environment and concurrency extension](proposals/FOUNDATION.md#c6-observations-environment-and-concurrency-extension),
  [C7 secret leakage and accounting](proposals/FOUNDATION.md#c7-secret-leakage-and-accounting),
  [C8 evaluator adequacy and termination](proposals/FOUNDATION.md#c8-evaluator-adequacy-and-termination),
  [C9 identities, primitive contracts, evidence and ghost erasure](proposals/FOUNDATION.md#c9-identities-primitive-contracts-evidence-and-ghost-erasure),
  [C10 frames and ABI](proposals/FOUNDATION.md#c10-frames-and-abi)), with the
  [pipeline and validation contract](proposals/FOUNDATION.md#3-pipeline-and-validation-contract)
  they serve. The rules themselves live only in the Lean spec; ROADMAP R-0607 to R-0616 hold the
  work, each with its home and gate. The answers, numbered as in the proposal (questions 12 and 13
  were removed as already decided by OD106 and by Q2.3 and Q3.8):
  - <a id="foundation-q1"></a>*Question 1*, [scope](proposals/FOUNDATION.md#q1): the interface and law boundary
    of C1–C10 is approved. The foundation is frozen only after its Lean implementation, its kernel
    proofs, its interaction tests, review by the four models and the owner's acceptance.
  - <a id="foundation-q2"></a>*Question 2*, [state](proposals/FOUNDATION.md#q2): one hybrid state, structured
    places for safe typed storage plus byte and provenance blocks, materialized only on raw
    address-taking, `expose` or passing an address to foreign code (C4).
  - <a id="foundation-q3"></a>*Question 3*, [target profiles](proposals/FOUNDATION.md#q3): read-only profiles
    separate address width, pointer representation, length width, byte order and address spaces.
    The existing 64-bit little-endian profile is unchanged. This generalizes Q3.7, Q3.9 and Q3.10
    and OD126's profile (noted at each).
  - <a id="foundation-q4"></a>*Question 4*, [enum layout](proposals/FOUNDATION.md#q4): the existing profile's
    `i32` enum tags stay for now; compact tags are decided at the layout slice.
  - <a id="foundation-q5"></a>*Question 5*, [niches](proposals/FOUNDATION.md#q5): option (b), tagged layout now
    and no niches; a future niche only by owner decision.
  - <a id="foundation-q6"></a>*Question 6*, [release context](proposals/FOUNDATION.md#q6): release-context
    erasure only with a preservation proof (noted at Q1.7).
  - <a id="foundation-q7"></a>*Question 7*, [`usize`](proposals/FOUNDATION.md#q7): option (c), the `u64` meaning
    everywhere per Q3.5, with proved narrower representations where bounds justify them. No source
    `usize` or `isize` is added.
  - <a id="foundation-q8"></a>*Question 8*, [native image](proposals/FOUNDATION.md#q8): R-0505's later
    native-image closure and Q8.1's conditional endpoint stay.
  - <a id="foundation-q9"></a>*Question 9*, [trap kinds](proposals/FOUNDATION.md#q9): the trap kind names and
    their renderings are decided before the first slice that prints them.
  - <a id="foundation-q10"></a>*Question 10*, [columns](proposals/FOUNDATION.md#q10): source columns count bytes,
    and a tab counts one byte, with conformance tests (noted at the
    [trap line](#decided-project-runtime-2026-11-06)).
  - <a id="foundation-q11"></a>*Question 11*, [UTF-8 failures](proposals/FOUNDATION.md#q11): their classification
    is deferred to the text slice.
  - <a id="foundation-q14"></a>*Question 14*, [entropy](proposals/FOUNDATION.md#q14): its grant shape is deferred
    to slice 6.
  - <a id="foundation-q15"></a>*Question 15*, [struct invariants](proposals/FOUNDATION.md#q15): the SPARK exposure
    definition is in the spec before the freeze; the source feature comes at slice 17.
  - <a id="foundation-q16"></a>*Question 16*, [registries](proposals/FOUNDATION.md#q16): lawful extensible
    registries; an unknown operation is refused (noted at Q7.1, Q7.10 and Q9.7).
  - <a id="foundation-q17"></a>*Question 17*, [qualification](proposals/FOUNDATION.md#q17): the decided
    backend-order equality stays, plus a per-native-trace Core refinement check;
    allocation-dependent observations are decided at slice 24.
  - <a id="foundation-q18"></a>*Question 18*, [`Secret<T>`](proposals/FOUNDATION.md#q18): `Secret<T>` has `T`'s
    layout (noted at the [information-flow decision](#decided-project-infoflow-2026-11-06)).

  *Revisions of decided rows*, as the proposal's [revision register](proposals/FOUNDATION.md#4-revision-register)
  states them:
  - **OD126; Q3.7, Q3.9, Q3.10** (question 3): the address and profile interface is generalized,
    preserving the provenance rules and the zero-byte exception; the existing 64-bit little-endian
    profile is unchanged, including Q3.10's `base + size ≤ 2^64−1` one-past bound. Any generalized
    profile needs an analogous checked bound.
  - **Q1.7** (question 6): proved release-context erasure, including owning Text where applicable;
    no unconditional one-pointer claim.
  - **Q7.1, Q7.10; Q9.7** (questions 16 and 14): lawful registry instances rather than a permanently
    closed inventory; the existing grant contracts are preserved. Entropy details are deferred.
  - Retained without revision: Q3.5 and its dependents (Q1.11, Q2.4, Q4.6, TYPE-19, FFI-7) keep
    the `u64` semantics and permit only proved narrower representations (question 7); OD126 and
    FFI-7's `i32` enum tags (question 4); Q8.1, the early-evidence decision and R-0505 (question 8);
    the natural native struct layout of the [runtime decision](#decided-project-runtime-2026-11-06),
    which supersedes FFI-7/10's unspecified-layout prose, with the `repr` restrictions retained.
- <a id="decided-2026-11-08-eleven"></a>**Eleven plan and process decisions** (owner, 2026-11-08: "ok
  go ahead with all the decisions", approving the coordinator's list of eleven, each as
  recommended). The process rules (items 4, 6, 7 and 8) are stated in [AGENTS.md](../AGENTS.md#rules);
  the work is in ROADMAP.
  1. <a id="decided-2026-11-08-ubsan"></a>*UBSan leaves the slice-0 gates; ASan stays.*
     UndefinedBehaviorSanitizer instruments C at clang's front end, so on LLVM IR input it checks
     nothing; a gate that cannot fail is not kept. This revises the
     [early-evidence](#decided-2026-11-07-early-evidence) and [tracking](#decided-2026-11-07-tracking)
     rows (R-0301).
  2. <a id="decided-2026-11-08-adapter"></a>*A complete adapter theorem.* The BIR → LCB-IR adapter
     theorem is complete: an adapter error produces no artifact, and success implies correctness.
     This retires the adapter premise (R-0579).
  3. <a id="decided-2026-11-08-landing-shrink"></a>*Smaller landing scripts.* Keep the train, its
     review leg, the gates and the `legacy/` protection; drop the landing bot, notify, install-bot,
     the systemd units and duplicate helpers; the old copies move to `legacy/` (R-0617).
  4. <a id="decided-2026-11-08-quota"></a>*Claude's quota goes to the critical path:* the spec, slice 0
     and the front end. Mechanical work goes to Codex and Kimi as writers.
  5. <a id="decided-2026-11-08-front-end"></a>*The front end starts now.* The lexer and the LL(1)
     parser are written now, in parallel with the foundation (R-0620); since the later answer "ok do
     the written grammar", the parser waits for the owner-approved written grammar and its Lean
     judgment ([written grammar](#decided-2026-11-08-written-grammar), R-0622).
  6. <a id="decided-2026-11-08-one-writer"></a>*One writer for `docs/decisions.md` and `ROADMAP.md`
     at a time;* other workers send it their records.
  7. <a id="decided-2026-11-08-review-caps"></a>*Review rounds capped by risk:* docs and roadmap 2,
     scripts 3, compiler and spec 5 (R-0618).
  8. <a id="decided-2026-11-08-clones"></a>*One clones folder:* every branch's clone is
     `~/projects/clones/<branch>`, removed after the branch lands (R-0619).
  9. <a id="decided-2026-11-08-no-libc"></a>*A no-libc runtime* on the proven path comes as a later
     slice, around slices 24–25; until then libc stays a named premise (R-0621).
  10. <a id="decided-2026-11-08-compile-budget"></a>*A compile-speed budget,* tracked per example and
      report-only like binary size (R-0550).
  11. <a id="decided-2026-11-08-f7"></a>*The termination wording* (ISS-0014 F7): "every function has
      termination evidence with its premises, or a report naming the explicitly permitted
      unresolved obligations". It replaces "termination is known beforehand", which overstated what a
      d-site permission establishes, in the [no-hidden-traps row](#decided-project-no-hidden-traps),
      README.md, PHILOSOPHY.md and the pending no-hidden-traps changelog fragment.
- <a id="decided-2026-11-08-std-table"></a>**A std-per-slice table, no user-guide chapters for now, the written grammar and the speed target**
  (owner, 2026-11-08: "ok let's do 2, for now let's not do 3"). Item 2 is approved: `ROADMAP.md`
  gets a table of which standard-library module arrives in which slice, with its spec contract, its
  std source, its proof status and the showcases that need it
  ([table](../ROADMAP.md#std-per-slice)). Item 3, a user-guide chapter per slice, is not done for
  now; it has no roadmap item. Item 1 was then approved (owner, 2026-11-08: "ok do the written
  grammar"): <a id="decided-2026-11-08-written-grammar"></a>before the parser is built, the full
  surface grammar is written down for the owner's review, every construct with its decided row and
  the open spellings flagged; after approval it is encoded in Lean as the independent grammar
  judgment (row Q8.3), and only then is the parser built against it (R-0622). Item 4 was approved
  too (owner, 2026-11-08: "and yes speed target is fine"):
  <a id="decided-2026-11-08-speed-target"></a>speed and size stay report-only until the first real
  showcase (grep, slice 16); then a performance target against C is set from measured data, as an
  owner decision (R-0623).
- <a id="decided-2026-11-08-capabilities-kept"></a>**Capabilities stay as decided: `with(...)` permission
  sets plus grant values** (owner, 2026-11-08: "i don't see an isue with noisier if it's clearer").
  This confirms the existing design with no revision: the [authority rules](#decided-2026-11-02-authority)
  and the Q5 and Q7 rows stand as written, and foundation contract C5 is written to them. The
  answer closes a comparison with a capabilities-as-values-only (object-capability) model, in
  which all four reviewing models recommended keeping today's design, because `with(...)` is the
  checked ceiling in a function's signature when structs own capabilities. Follow-up for the
  allocation slice: whether destroying a collection still needs `with(Alloc)` when its release
  metadata travels with it (R-0624, raised by agy).
- <a id="decided-project-spark-2026-11-06"></a>**What Concrete takes from SPARK** (owner, 2026-11-06: "ok do everything", after Claude, Codex, agy and Kimi chose unanimously; the
  [review](proposals/SPARK.md) items 1, 2, 3, 6, 7, 9 and 10).
  - *Function values with safety preconditions.* A function whose `#[requires]` is a safety
    precondition is refused as a function value, including through wrappers and specialization. A
    binding task designs function-type contracts, trait methods included, as a prerequisite for
    accepting slice 20 (function values), or earlier if a workload pulls it (R-0601); it is never
    broadened to non-safety contracts.
  - *Struct invariants.* `#[invariant(...)]` on a struct with private fields holds at every
    exposure. The definition is written in the spec before the freeze. Revised 2026-11-07 (owner:
    "ok go ahead all yes then as you said right", approving the recorded recommendation): the source
    feature moves from the structs slice (slice 9) to the modules slice (slice 17), where field
    privacy exists.
  - *Facts at a point.* `assert(e) by thm(...)` extends [OD79](#od79). Its role is strictly
    separate from `#[proof]`: `#[proof]` discharges the function's obligations, `assert(e) by
    thm(...)` establishes one fact at one point, and the theorem's hypotheses are fully discharged.
  - *Observable events.* Core gets an extensible observable-event kind now, which also protects
    secret wipes (R-0602); device semantics come later.
  - *Unused permissions.* A permission that justifies nothing is a fact that a `Concrete.toml`
    policy may refuse; the decided refusals (an unmatched `#[proof]`, a duplicate
    `#[may_not_terminate]`) stay.
  - *Measures.* Lexicographic measures come when a workload needs them (R-0605).
  - *Assurance.* Assurance is a set of separate named, versioned properties per module, each with
    its scope, evidence and coverage, not a ladder (R-0606).
- <a id="decided-project-runtime-2026-11-06"></a>**Trap line, default layout and spec version** (owner, 2026-11-06: "ok do everything", after Claude, Codex, agy and Kimi chose unanimously).
  - *The trap line* ([OD101](#od101)'s form, spec obligation O4): `concrete: trap: <kind> at
    <path>:<line>:<col> (site <id>)`, the path relative to the project root with forward slashes,
    line and column 1-based. Extended 2026-11-08 by the [foundation decision](#foundation-q10): a
    column counts bytes, and a tab counts one byte.
  - *Default struct layout:* declaration order, natural alignment defined exactly per target, the
    size rounded up to the alignment, and zero-sized fields taking no bytes. It is not a C ABI
    promise (R-0502).
  - *Spec version:* every output carries one `spec_version`, in one header covering every record
    (JSON lines included): 0.x before the freeze, 1.0 at A2c, bumped by every normative change and
    checked in CI. It is distinct from the product's 1.0 (R-0603).
- <a id="decided-project-lean-root"></a>**A minimal root** (owner, 2026-11-06: "keep the folders and
  root of the new compiler simple and lean"). The root and the new compiler's folders stay small:
  the top-level entries and the immediate entries under `docs/` and `scripts/` are those listed in
  [scripts/checks/root_inventory.txt](../scripts/checks/root_inventory.txt), which a root check
  enforces, and something comes back from `legacy/` only in the change that needs it. This keeps the
  [restart](#decided-project-restart)'s minimal day-one root (R-0558) after the move.
- <a id="decided-project-outside-readers"></a>**The outside readers** (owner, 2026-11-06: "me but also
  agy and codex and kimi if it's available"). The outside-reader pass (R-0559) is done by the owner and
  independent models: agy (Gemini), Codex, and Kimi when available. They read the browsable owner view of the
  integrated spec. The pass runs before the freeze (A2c) and again for each feature
  ([long-term changes](#decided-project-long-term-2026-11-06)). <a id="outside-readers-ordering"></a>*Reading
  order* (owner, 2026-11-07: "ok go ahead all yes then as you said right", approving the recorded
  recommendation): Codex, agy and Kimi read first; every point one of them finds unclear is recorded
  and resolved before the owner's formal read and before the freeze. A real design question still
  goes to the owner. Kimi's absence, when it is unavailable, is recorded rather than waited on.
- <a id="decided-project-contracts"></a>**Contracts and termination in verified growth** (row P18,
  2026-11-05). No source `old`, quantifier, implication or snapshot construct (OD117); entry, exit and
  frame properties are stated as Lean theorems (a source frame clause would be a new owner decision);
  spec functions have a body and are total (OD115); an ordinary function can get its own termination
  proof, with no total-function category (OD116).
- <a id="decided-project-refusals"></a>**The refusal list** (rows P16, P17a, P17b, 2026-11-05). The
  statuses in `PHILOSOPHY.md` stand; default arguments are a permanent refusal; compile-time
  evaluation and broad `#[cfg]` reopen only with a workload, a proof story, phase separation, an audit
  report and a new owner decision.
- <a id="decided-project-review"></a>**Review** (owner, 2026-10-18, reaffirmed 2026-11-04: "always codex
  should check everything"). Codex reviews every change, plan, specification, decision row and piece
  of infrastructure before it is published or brought to the owner. A second, independent reviewer
  (Kimi, Grok or agy/Gemini) reviews as well when one is available, as the owner required for cleanup
  branches on 2026-10-28; when none is (quota, credit or sign-in), its absence is recorded with the
  review and never assumed. A review never replaces the gates. Extended 2026-11-08 (owner: "also
  remember we have agy not only codex kimi and claude"; also on 2026-11-08: "ok but review the
  foundation with all the models right? agy, kimi and codex apart from claude that is us"; "use agy laso";
  "have everything reviewed by the other llms"): every branch gets an agy review beside the
  Codex and Kimi reviews. agy cannot read files, so its prompt carries the diff and the context it
  needs and ends with a required verdict line. (The coordinator's relay added that agy can also act
  as a writer.)
- <a id="decided-project-throughput"></a>**Development throughput** (2026-10-22). The development
  feedback loop (landing, review, CI) is a priority track beside the main sequence
  ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-10-22--development-throughput-priority)).
- <a id="decided-project-supersession"></a>**Editorial supersession of legacy task directions**
  (2026-11-03). The new-compiler and restructure decisions supersede in-place repairs and migration of
  frozen compiler internals; the archived task bodies keep their history and regression obligations
  ([record](archive/roadmap-2026-11/ROADMAP_DECISIONS.md#2026-11-03--editorial-supersession-of-legacy-task-directions)).

## Owner decisions

**Only the project owner decides these items, OD1 – OD157.** All are answered. OD1 – OD32 (exit 2n, closed) and OD47 were decided on 2026-10-29 (OD23 – OD32 by the strictness pass of that day). OD33 – OD157 were decided on 2026-10-31, by the owner's rule that an answer every reviewer agreed on and as strict as Austral or stricter is taken, and on 2026-11-01, when the owner approved the final set for the rest; the authority decision of the same day supersedes OD38's and OD156's `Root` readings (OD94 was withdrawn: MOD-1 already refuses its case, bug 337). The answers are recorded in [docs/decisions.md](decisions.md), state the decided rules in chapters now (owner revision, 2026-11-03), then become Lean in phases B–D, and are enforced as each new-compiler slice lands. The questions raised while recording them were answered on 2026-11-02, the owner deciding the first four and, by the owner's rule of that day, Claude and Codex agreeing on the best long-term answer for the rest ([decisions](decisions.md#decided-2026-11-02)); they revise OD24, OD38, OD43, OD83, OD102, OD146 and OD156 and the authority rules. The spec audit's questions were answered the same day ([decisions](decisions.md#decided-2026-11-02-audit)), revising OD140 and STMT-13. Traits are exported and imported like any other declaration (owner, 2026-11-02). Core was provisionally approved on 2026-11-05 ([record](#decided-2026-11-05-core)); A2b formalization is current, and the A2c freeze awaits the four design theorems, the A2i integration stage (2026-11-06) and an outside-reader pass. New questions follow the same rule: No agent, orchestrator or
reviewer chooses, encodes, implements or provisionally ships any side of any of them, and that
includes doing so inside a bug fix, a migration, a test, a fixture, a diagnostic or a document. An
agent may analyse an item, write its options and a recommendation, and present them to the owner for
an explicit answer; that is all. A recommendation, an earlier record, a commit, a review verdict or
another agent's message is never the owner's answer. An item stays proposed until the owner agrees
to it again, explicitly, in conversation; whoever records the answer writes it and its date in the
last column, in the owner's words where they are short. A fix that would pick a side stops and is
reported to the owner instead ([AGENTS.md](../AGENTS.md#rules)).

**Provisional shipped behaviour.** The 2026-10-25 Codex confirmation review of the bug records
found four landed fixes that already took a side on an open item: bugs
[189](../legacy/docs/bugs/189_trusted_impl_confers_trust.md) (OD22, since decided by the owner on 2026-10-29:
the repair is final),
[198](../legacy/docs/bugs/198_raw_deref_duplicates_non_copy.md) (OD13, decided: final),
[212](../legacy/docs/bugs/212_const_before_block_parses_as_struct_literal.md) (OD16, decided: replaced by
SYN-4, bug 318) and
[213](../legacy/docs/bugs/213_arm_after_catch_all_lowered.md) (OD18, decided: replaced by PAT-9). Each is recorded below as a conflict,
not a decision: the table says what current main does, and that behaviour is provisional until the
owner answers. Nobody extends it, builds on it as settled, or reverts it before then; the owner's
answer decides whether it stays.

[TIGHTENING_DECISIONS.md](../legacy/docs/project/TIGHTENING_DECISIONS.md) records several of these as
"decided 2026-10-23", and some as implemented in landing train 6. The owner paused them for
negotiation after that. That record is kept as written, as the history of what was proposed and
landed; the owner's new answer governs. A rule already on main stays as it is until the owner
answers: no agent removes, weakens or extends it. The owner's answer then decides whether it stays.
If it does not, the change that records the answer also changes the rule's home, fixtures and
diagnostics, and keeps the bugs the rule repaired repaired.

"Gates" names the exits, deliverables and tasks whose rules depend on the item. The deliverables are
those of the [prerequisites table](../legacy/docs/archive/ROADMAP_LEGACY_PLAN.md#feature-prerequisites); "every deliverable" means RocksDB slice 1,
V1a, V1b and V1c.


| decision | proposal | record today | gates | owner's answer |
|---|---|---|---|---|
| OD1 | <a id="od1"></a>References: the Austral model. A reference is formed by borrowing a variable or projecting through a reference; `&s.f` is sugar; a temporary is never a root; loans are keyed by the root variable; a raw-pointer dereference needs a trusted validity premise | D2 and §4.5; implemented in landing train 6 (REF-5, REF-11) | exit 2i (G12), so every deliverable; bug 182's repair (exit 0b); V2 (row 6) | decided 2026-10-29 by the owner: the Austral model: a reference is formed by borrowing a variable or projecting through a reference; `&s.f` is sugar; a temporary is never a root; references are second-class, never stored or returned; a raw-pointer dereference needs a trusted validity premise; loans are keyed by the root variable (confirmed by OD15 (a), decided 2026-10-29) |
| OD2 | <a id="od2"></a>`&mut` arguments: an implicit reborrow; overlapping exclusive arguments refused; a deferred call keeps its loan until it runs; one defined order for cleanup, loan end and write-back | D1 and §4.5; the reborrow implemented in landing train 6 (REF-10); the defer and exit-order rules not yet | exit 2i (G9, B1, B2), so every deliverable; R-0496 (Core reborrow form) | decided 2026-10-29 by the owner: (1) passing a `&mut` on is plain lending, each call's use ending when it returns, with no reborrow concept or syntax; (2) a call is refused when an exclusive argument overlaps any other argument (`h(r, r)`, `h(&mut x, &x)`, `h(&mut a, &mut a.f)` refused); as tightened by OD15 (a) the same day, two arguments that borrow the same root conflict whenever one is exclusive, so even `h(&mut a.f, &mut a.g)` is refused; (3) `&mut` refers to the place, a write through it is the write to that place at once, and copy-in/copy-out is not part of the language (only an optimization proven equivalent); (4) `defer` keeps OWN-12 and a borrow passed to a deferred call stays live until the call runs; (5) one exit sequence on every non-abort exit: the exit value, then the scope's deferred calls (last registered first, innermost scope first), then the scope's loans end, then the remaining locals are destroyed; an abort runs none of it **Canonical current root-based exclusivity rule: REF-11 and OD15(a); this historical overlap formulation is a reference to that rule.** |
| OD3 | <a id="od3"></a>Pattern binders through a borrowed scrutinee: the binder is always `&T`; its mode is stored in Core; the root cannot be reassigned while a binder's loan lives (the rule that reopened G17's Copy case) | D3 and §4.5; implemented in landing train 6 (REF-9), and with it the refusal of G17's Copy case (closed 2026-10-23 in the references chapter of the specification) | exits 2i (G17) and 2k (explicit match binders), so every deliverable; bug 181's repair (exit 0b); R-0496 | decided 2026-10-29 by the owner: the binder is always `&T`; its mode is stored in Core; the root cannot be reassigned while a binder's loan lives. Already enforced (REF-9, PASS-2, REF-8) |
| OD4 | <a id="od4"></a>Foreign function values: all refused now; typed `extern "C" fn` types later | D4; the refusal implemented in landing train 6 (FFI-1); the typed form not built | bug 166's repair (exit 0b), so every deliverable; R-0285's callback companion example; R-0283, R-0287 | decided 2026-10-29 by the owner: all foreign function values are refused now; typed `extern "C" fn` types may come later |
| OD5 | <a id="od5"></a>Generics: a bare `<T>` means Any; `T: Copy` is explicit; Copy for a generic struct is declared and checked, never derived | D5 (today's behaviour, made normative) and D6 with its refinement (a), under which a generic declared `Copy` is Copy when every argument is; D6 implemented 2026-10-23 (OWN-D1, TYPE-14) | R-0499 and R-0510 (the Core checker and checked specialization, row 4); V5 (row 6) | decided 2026-10-29 by the owner: a bare `<T>` means Any and `T: Copy` is explicit; Copy for a generic struct or enum is declared and checked, never derived, and a generic declared Copy is Copy when every argument is |
| OD6 | <a id="od6"></a>Traits are coherent: one impl per (trait, type), the orphan rule, an ambiguous method call must be qualified, resolution by typed identity | D7; implemented by bug 186's repair (TRAIT-1 – TRAIT-9) | bug 186's repair (exit 0b), so every deliverable; R-0548, R-0549; V5 | decided 2026-10-29 by the owner: traits are coherent: one impl per (trait, type), the orphan rule, an ambiguous method call must be qualified, resolution by typed identity. Completed 2026-11-02: qualified as `Trait::method(&x, ...)` ([decisions](decisions.md#decided-2026-11-02-audit)) **Canonical current qualification rule: this OD6 as completed by the audit below; the audit supplies syntax, not a second rule.** |
| OD7 | <a id="od7"></a>An unsafe-module marker in source (for example `trusted mod`), which never confers trust by itself; a gate lists the marked modules | D10; pending (TRUST-6, R-0509) | R-0509's trusted-base inventory; RocksDB slice 1 (where its `extern` declarations live); V6 | decided 2026-10-29 by the owner: an unsafe-module marker in source (for example `trusted mod`) never confers trust by itself, a gate lists the marked modules, and trust stays per method (OD22) **Revised 2026-11-03: this historical module-marker requirement was superseded by OD61 (2026-11-01), which removed `trusted mod`; trust and inventory remain per declaration.** |
| OD8 | <a id="od8"></a>Global state: immutable globals everywhere; mutable state only as declared cells in unsafe-marked modules, reached through capabilities; no `static mut` | D8; pending (TRUST-6, R-0509) | R-0509, R-0496; V6 | decided 2026-10-29 by the owner: Austral's capability model, extended. (1) Constants only: no mutable global state of any kind (no `static mut`, no cells); a constant is truly immutable, has no interior mutability and never contains a capability, token or handle. (2) Global resources are linear tokens minted at startup: `main` receives a root resource value (in the spirit of Austral's `RootCapability`) and splits it; hardware and runtime singletons (allocator arena, UART and MMIO, panic buffer, errno, C libraries with internal state) are produced or taken only by `trusted fn` wrappers returning or taking linear tokens, and a gate lists those wrappers. (3) Tokens are ordinary values: every effect shows as a token parameter, under the existing loan and exclusivity rules (OD1, OD2, OD15), with no separate effect system. (4) Interrupt handlers, FFI callbacks and future threads get only the tokens explicitly given to them, by installation, transfer or a lock granting a borrow. (5) No life before `main`, no cleanup protocol for global state, and abort runs nothing (OD10). (6) An implicit-context mechanism, if ergonomics later demands one, is a new owner decision, never a hidden global. The cell variant was rejected after the Codex and Grok reviews (interrupts, FFI re-entrancy, linear cell contents, effect polymorphism, concurrency). Now TRUST-8 to TRUST-10 (pending, R-0557) Revised 2026-11-01 – 11-02: items 2 and 3 are superseded by the authority decision (grants handed to `main`; `with(...)` plus resource values); item 5 stands ([decisions](decisions.md#decided-2026-11-02-authority)) |
| OD9 | <a id="od9"></a>Modules and interfaces: one file per module, `pub` as the interface, interface artifacts generated by the compiler, no handwritten interface files | D9; pending (TIGHTENING_DECISIONS §5, step 6) | R-0492 and R-0497 (interface data); separate compilation in V6; OD20 | decided 2026-10-29 by the owner: one file per module with `pub` as the interface; interface artifacts generated by the compiler, no handwritten interface files; a gate diffs each module's generated interface between commits so any public-API change shows in review (R-0556) |
| OD10 | <a id="od10"></a>Arithmetic: checked by default, named wrapping and saturating operations, shifts with a checked count; an abort runs no deferred call | T-ARITH, recorded as settled (today's behaviour), with §4.5's abort rule | exits 2h and 2j, so V1a, V1b and V1c (checked `+ - *` and their traps); R-0493 | decided 2026-10-29 by the owner: integer arithmetic is checked by default; wrapping and saturating arithmetic are named operations; the shift count is checked; an abort runs no deferred call **Revised 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): plain arithmetic is admitted only with evidence that it cannot fail; wrapping, saturating and checked (`Result`) forms cover the rest; overflow is still never silent.** |
| OD11 | <a id="od11"></a>Casts: `as` only when lossless by value domain; every lossy conversion is a named function | T-CAST: ARITHMETIC_POLICY §8 (2026-10-21) and §4.5's value-domain rule; not implemented | exit 2k; the V1 increment that admits casts | decided 2026-10-29 by the owner: `as` only when lossless by value domain; every lossy conversion is a named function |
| OD12 | <a id="od12"></a>Contracts (H27): a pure, non-consuming specification judgment, with machine and mathematical arithmetic kept distinct | T-H27 and §4.5; pending (R-0473) | R-0473 (row 12); any V1a or V1b claim stated with a contract | decided 2026-10-29 by the owner: a contract is a pure, non-consuming specification judgment, with machine and mathematical arithmetic kept distinct |
| OD13 | <a id="od13"></a>Raw-pointer ownership: `ptr::read_owned`, an explicit replace or take through `&mut T`, a trusted ownership obligation for a raw address | T-RAWDUP and §4.5; implemented in landing train 6 (TRUST-7). **Provisional (bug 198):** the current compiler refuses a by-value `*p` of a non-Copy pointee through a raw pointer (E0311) and moves the value out only with the intrinsic `read_owned(p)`, with 26 std sites migrated; provisional until the owner answers | RocksDB slice 1 (its trusted binding code); R-0509, R-0514; V6 | decided 2026-10-29 by the owner: a value moves out of raw memory only through `read_owned(p)` or an explicit replace or take through `&mut T`, and a raw address carries a trusted ownership obligation; bug 198's provisional repair is final |
| OD14 | <a id="od14"></a>Type validity (G2, G13, G15, G16): one structural well-formedness judgment before specialization; function types that return a reference refused everywhere | T-G2, T-G13, T-G15, T-G16; implemented 2026-10-23 (G13, G15 and G16 recorded closed in the references chapter of the specification) | exit 2i, so every deliverable | decided 2026-10-29 by the owner: one structural well-formedness judgment runs before specialization, and function types that return a reference are refused everywhere |
| OD15 | <a id="od15"></a>G10: whole-owner freezing under a shared borrow stays. G19: no pass assumes `&mut` exclusivity, and the operational loan rules are defined now | T-G10 (keep the freeze) and T-G19 (the policy sentence) | exit 2i (the G10 decision record), so every deliverable; R-0496, R-0505 | decided 2026-10-29 by the owner. (a) Whole-owner freezing: a live borrow of any part of a value freezes the whole owner, and loans are keyed by the root binding (REF-11 as in the current compiler); this tightens OD2's part 2: at a call, two arguments that borrow the same root conflict whenever one is exclusive, even disjoint fields (`h(&mut a.f, &mut a.g)` is refused, as in the current compiler); OD1's "keyed by the root variable" stands. (b) The strict option: the language guarantees `&mut` exclusivity, which the checker enforces (OD2, OD15a), and no compiler pass or optimization may assume or exploit it until the checker's guarantee is proven in Lean (R-0499 with the Core semantics R-0496); until then the operational loan rules are defined now, G19 included: a pointer or alias derived from a loan is valid only while that loan lives. Now REF-11@3 (partial, bug 319, which OD23 adds) and REF-14 (pending, R-0496) **Canonical current root-based exclusivity subject: REF-11 (including OD23’s re-lent case); OD2 and OD23 refer here rather than defining separate variants.** |
| OD16 | <a id="od16"></a>A struct literal in an `if`, `while` or `match` head is refused unless parenthesized | not in the record. **Provisional (bug 212):** the current compiler reads an uppercase name followed by `{` in an `if`, `while` or `match` head as the start of a struct literal, refuses `if n > LIMIT { … }` with an E0001 that suggests parentheses, and states that case rule in `grammar/concrete.ebnf` and SYN-1; provisional until the owner answers | V1c (V1's surface grammar has conditionals and loops); R-0500 | decided 2026-10-29 by the owner: refused unless parenthesized, with no exceptions; the uniform rule replaces the uppercase-name heuristic (bug 212's provisional behaviour). Now SYN-4 (pending, bug 318); whether a literal inside a call's argument list in a head counts as parenthesized is OD34 |
| OD17 | <a id="od17"></a>A field write requires a `mut` binding. Bug 216: `s.y = 1` is accepted on a binding not declared `mut`, while `&mut s.y` and `a[i] = v` are refused | not in the record; bug 216 open | bug 216's repair (class 5, R-0499); V2 (aggregates) | decided 2026-10-29 by the owner: a field write requires a `mut` binding. Now OWN-10@2 (partial; bug 216 implements it) |
| OD18 | <a id="od18"></a>Match arms: the first matching arm in source order wins; an unreachable arm is refused. Today an unguarded catch-all arm is moved to the end (bug 213) | not in the record. **Provisional (bug 213):** the current compiler first moves unguarded catch-all arms after the other arms (CoreCanonicalize), so a specific arm written after a catch-all moves before it and stays selectable; in that Core order, it accepts an arm after the first unguarded catch-all and does not lower it, and does not refuse it; provisional until the owner answers | exit 2k (the match rules) and exit 2c's differential legs; V2 (match) | decided 2026-10-29 by the owner: the first matching arm in source order wins and an unreachable arm is refused; this changes the current compiler, where CoreCanonicalize moves unguarded catch-all arms to the end (bug 213's provisional behaviour) |
| OD19 | <a id="od19"></a>Outside the language list: the scope of [PROVABLE_V1](../legacy/docs/verification/PROVABLE_V1.md), that is, whether discarded statements, guards and ranges are admitted | open; it holds the model-coverage branch (`wip/model-coverage-3`) | that branch's landing; exit 2c's model-diff coverage | decided 2026-10-29 by the owner: the provable subset admits discarded statements, guards and ranges, each entering as its Core semantics lands (this unblocks `wip/model-coverage-3`) **Revised 2026-11-03: the guards and ranges fragments were superseded by OD55 and OD56 (2026-10-31), which removed those forms; discarded statements remain subject to the decided discard rules.** |
| OD20 | <a id="od20"></a>Outside the language list: the visibility of std's internal `std.libc` bindings | bug 226 open (a std API decision) | bug 226's repair (MOD-2); OD9 | decided 2026-10-29 by the owner: std's internal `std.libc` bindings are private to std; programs cannot see them |
| OD21 | <a id="od21"></a>Representation rights of a parent over its child module (added 2026-10-25, from bug 262): when a parent module imports its child's newtype or struct, every stage lets the parent construct the newtype and read and write the struct's private fields, because Check counts the children's declarations among the module's own for construction and field rights; Resolve also lets a parent name a child's newtype as a symbol without an import. Two options: enforce TYPE-11 as written (a newtype or private field is constructed or accessed only inside the module that declares it, so a child is another module), or amend TYPE-11 to grant a parent these rights over the declarations it imports from its children | the behaviour dates from construction rights slice 1 (2026-07-18); it contradicts TYPE-11@1's wording ("outside the module that declares it"); bug 262's record names `tests/programs/module_qualified_impl` as a program that applying TYPE-11 strictly would refuse; the wider impact is not yet measured (no `scripts/tools/rule_impact.sh` scan is recorded); bug 262's record (branch `wip/newtype-ctor-stage`) leaves the question to R-0011 and makes no recommendation | R-0011; the construction-rights fixtures (`module_qualified_impl` and bug 262's `error_262_*` and `regress_262_*` fixtures); bug 262's follow-up (whether Resolve binds a child's newtype in its parent) | decided 2026-10-29 by the owner: only the declaring module; a newtype is constructed, and a private field read or written, only inside the module that declares it, and a parent module gets no rights over its child (TYPE-11 enforced as written) |
| OD22 | <a id="od22"></a>Trust on an `impl` block (added 2026-10-25, from bug 189). Bug 189's repair made the parser refuse `trusted impl` (E0001) and moved trust onto each method (`trusted fn`, 175 methods marked), while TRUST-5@1 in [the specification](../legacy/docs/spec/trusted.md#TRUST-5) still says a `trusted fn` or `trusted impl` may perform raw-pointer operations. Two options: keep the refusal and amend TRUST-5 to drop `trusted impl`, or restore `trusted impl` as TRUST-5@1 states it and revert bug 189's refusal | **Provisional (bug 189):** the current compiler refuses `trusted impl` and trusts only methods declared `trusted fn`; the specification text is unchanged, so the current compiler and TRUST-5@1 disagree; bug 189's record cites the 2026-10-23 rule that a marker never confers trust (D10, itself OD7, proposed); provisional until the owner answers | bug 189's repair (exit 0b) and its pins (`error_189_trusted_impl_refused.con`, `check_trusted_method.sh`); TRUST-5; R-0509's trusted-base inventory; OD7 | decided 2026-10-29 by the owner: trust is per method, `trusted fn` only; `trusted impl` stays refused, so bug 189's provisional repair is final |
| OD23 | <a id="od23"></a>REF-11: every argument of a call, the receiver included, is overlap-checked against its root, re-lent `&mut` bindings included (added 2026-10-29, from a Grok review of the spec) | the current compiler exempts a re-lent reference binding (REF-11@2), so `r.add(r.step)` is accepted; bug 319 | exit 2q; R-0499 | decided 2026-10-29 by the owner ("strict across the board"): every argument of a call, the receiver included, is overlap-checked against the root, including re-lent `&mut` bindings, so `r.add(r.step)` is refused; read the Copy field into a `let` first. Now REF-11@3 (partial, bug 319) **Canonical current rule: REF-11 and OD15(a); this is the historical clarification of its re-lent case.** |
| OD24 | <a id="od24"></a>STMT-7: `main` returns `u8` or `Unit` (added 2026-10-29, from a Grok review of the spec) | the current compiler accepts any result type, masks an integer to 0–255 and maps `bool` natively; bug 320 | exit 2q; V1c | decided 2026-10-29 by the owner ("strict across the board"): `main` returns `u8` or `Unit` (exit 0); no masking, no bool mapping, no other result type. Now STMT-7@3 (partial, bug 320). Revised 2026-11-02 by the owner: `u8` only ([decisions](decisions.md#decided-2026-11-02-main)) |
| OD25 | <a id="od25"></a>PAT-3/PAT-5: ignoring a payload or a field is written (added 2026-10-29, from a Grok review of the spec) | a bare variant name ignores a Copy payload and a Copy struct `let` may omit fields; bug 321 | exit 2q; exit 2k | decided 2026-10-29 by the owner ("strict across the board"): a bare variant name is legal only for a fieldless variant; ignoring a payload is written `Variant { .. }` or `field: _`; a struct `let` names every field or ignores one explicitly with `field: _`. Now PAT-3@3 and PAT-5@3 (partial, bug 321) |
| OD26 | <a id="od26"></a>TYPE-6 with TRUST-1: operators take numbers only (added 2026-10-29, from a Grok review of the spec) | trusted and `Unsafe` code may compare raw pointers and add an integer to one; bug 322 | exit 2q; R-0502 | decided 2026-10-29 by the owner ("strict across the board"): arithmetic, shifts and comparisons take numbers only; pointer offset, difference and ordering are `ptr::offset` and named functions. Now TYPE-6@2 (partial, bug 322) |
| OD27 | <a id="od27"></a>STMT-6/OWN-15: `break <expr>` is refused at parse time (added 2026-10-29, from a Grok review of the spec) | a value after `break` in a `while` or `for` statement is parsed and dropped; bug 323 | exit 2q; exit 2j | decided 2026-10-29 by the owner ("strict across the board"): `break <expr>` is refused at parse time. Now STMT-6@2 (partial, bug 323) |
| OD28 | <a id="od28"></a>TRAIT-10: a `Destroy` bound is satisfied only by an impl (added 2026-10-29, from a Grok review of the spec) | every Copy type and every array of destroyable elements counts as `Destroy`; bug 324 | exit 2q; R-0499 | decided 2026-10-29 by the owner ("strict across the board"): a `Destroy` bound is satisfied only by an impl; Copy types are not `Destroy` (discard them with `discard`); arrays get one written impl, or one language impl that is its own spec entry. Now TRAIT-10@2 (partial, bug 324); which array form is OD35 |
| OD29 | <a id="od29"></a>OWN-7: a statement expression has type `Unit` (added 2026-10-29, from a Grok review of the spec) | only a syntactically pure non-Unit Copy value is refused (E0294); a call's result is dropped silently; bug 325 | exit 2q; exit 2j | decided 2026-10-29 by the owner ("strict across the board"): a statement expression must have type `Unit`; every other unused result needs `discard(e)`; the syntactic purity heuristic is removed. Now OWN-7@3 (partial, bug 325) |
| OD30 | <a id="od30"></a>MEM-4: `e.f` requires the struct or a reference to it (added 2026-10-29, from a Grok review of the spec) | a field access opens one `Heap` layer implicitly; bug 326 | exit 2q; R-0499 | decided 2026-10-29 by the owner ("strict across the board"): `e.f` requires `e` to be the struct or a reference to it; opening a `Heap` or `HeapArray` uses an explicit non-consuming place form; `*` stays the consuming move-out. Now MEM-4@3 (pending, bug 326); the place form's spelling is OD36 |
| OD31 | <a id="od31"></a>ARITH-2: no `Int` fallback for an unconstrained literal (added 2026-10-29, from a Grok review of the spec) | an unconstrained integer literal is `Int` and a float literal `Float64`; bug 327 | exit 2q; exit 2j | decided 2026-10-29 by the owner ("strict across the board"): an integer literal takes its type from its context, as today; the fallback to `Int` where nothing is expected is removed, so an unconstrained literal is refused; suffixes are not required; float literals get an explicit rule under the same principle. Now ARITH-2@2 (partial, bug 327) |
| OD32 | <a id="od32"></a>OWN-15: no receiver auto-borrow (added 2026-10-29, from a Grok review of the spec) | a `&self` or `&mut self` method on an owned place borrows it implicitly; bug 328 | exit 2q; R-0499 | decided 2026-10-29 by the owner ("strict across the board"): no receiver auto-borrow: a method with `&self` or `&mut self` on an owned place is written `(&s).m()` or `(&mut s).m()`; a receiver that is already a reference is unchanged. Now OWN-15@3 (pending, bug 328) |
| OD33 | <a id="od33"></a>Inline submodules under OD9 (added 2026-10-29, from recording OD9): OD9's answer is one file per module, and today the language also accepts an inline submodule (`mod m { ... }` inside its parent's file, used by most specification examples and many fixtures). Two options: inline submodules stay (a module is one file or one inline block), or every module is its own file and the inline form is refused. Recommendation: every module its own file, as OD9's answer reads; the specification's examples and the fixtures move their inline modules into project examples when exit 2q migrates the corpus. Austral has one module per file pair and no inline modules Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): no inline `mod m { }`: one file per module | the current compiler accepts inline submodules; MOD-7 (pending, R-0556) records OD9 without settling this; OPEN-33 | R-0556; the specification's examples and the fixture corpus | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): No inline `mod`; one file per module |
| OD34 | <a id="od34"></a>A struct literal inside a call's argument list, an index or an array literal within an `if`, `while` or `match` head (added 2026-10-29, while recording OD16): whether it counts as parenthesized under SYN-4. Two readings: only a grouped expression `( expr )` parenthesizes, so `if same(p, P { v: 1 }) { ... }` is refused; or any enclosing bracket does, so it is accepted (Rust's reading). Recommendation: any enclosing bracket, since inside a call's parentheses the head's `{` cannot be meant, and refusing it would require parentheses inside parentheses Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): only an enclosing `(` or `[` parenthesizes, stated as one invariant: in a condition head, a `{` at bracket depth zero opens the block | not in the record; the current compiler accepts it (the uppercase heuristic reads a struct literal anywhere in a head) | bug 318's repair (SYN-4); V1c | decided 2026-11-01 by the owner (final set): Only enclosing `(`/`[` parenthesize; `{` at depth 0 opens the block |
| OD35 | <a id="od35"></a>How an array satisfies a `Destroy` bound (added 2026-10-29, while recording OD28, which allows either form): one impl written in std for `[T; N]` with `T: Destroy`, or one language impl that is its own specification entry. Recommendation: the language impl, since an array's destruction is its elements' in order and std cannot write an impl generic over the length without const generics Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): a language impl `[T; N]: Destroy` when `T: Destroy`, elements destroyed in index order, with its own identity in coherence | the current compiler counts an array of destroyable elements as `Destroy` with no impl (bug 324) | bug 324's repair (TRAIT-10) | decided 2026-11-01 by the owner (final set): Language impl `[T; N]: Destroy` when `T: Destroy`, index order |
| OD36 | <a id="od36"></a>The spelling of the explicit non-consuming place form that opens a `Heap` or `HeapArray` (added 2026-10-29, while recording OD30, which requires one and keeps `*` as the consuming move-out). Options: a borrow through the cell (`(&h).f`, `(&mut h).f`), a named projection (`h.open().f`), or a dedicated operator. Recommendation: the borrow form, which needs no new syntax and matches OD32's explicit receiver borrow Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): only through a borrow block (`borrow h as r { r.f }`), no `(&h).f`; specify the result type for `Heap<T>`, `&Heap<T>` and `&mut Heap<T>`, one heap layer per block (MEM-4), and `HeapArray` elements | the current compiler opens one heap layer implicitly (`h.f` on `Heap<S>`, bug 326) | bug 326's repair (MEM-4) | decided 2026-11-01 by the owner (final set): Only through a borrow block; no `(&h).f` |
| OD37 | <a id="od37"></a>The names of the pointer difference and ordering functions (added 2026-10-29, while recording OD26). Options: `ptr::diff(p, q) -> Int` and `ptr::cmp(p, q) -> Ordering` beside `ptr::offset`; or no ordering at all, only `ptr::addr(p)` (via `ptr::expose`) compared as integers. Recommendation: `ptr::diff` and `ptr::cmp`, both trusted, each with its provenance premise (same allocation) stated as an obligation; Austral has no named pointer-difference or ordering functions, and its `Pointer` and `Address` types are compared with the ordering operators Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): one trusted `ptr::diff` (same-allocation premise), ordering read from its sign, no `ptr::cmp`; specify the representability of its result, one-past pointers included (Q8 is marked agreed in the picks; ROADMAP records no owner answer for it) | trusted code compares raw pointers with `==` and `<` today (bug 322) | bug 322's repair (TYPE-6, TRUST-1) | decided 2026-11-01 by the owner (final set): One trusted `ptr::diff`, ordering from its sign, no `ptr::cmp` |
| OD38 | <a id="od38"></a>The root resource API (added 2026-10-29, while recording OD8). Options: `fn main(root: Root) -> u8` with trusted splitting functions (`root.split_alloc()`, `root.split_console()`, ...) returning linear tokens; or a fixed set of token parameters `main` may declare (`fn main(alloc: Alloc, io: Console)`). Recommendation: the single `Root` value, as Austral's `RootCapability`, split by trusted functions the wrapper gate lists Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): `fn main(root: Root) -> u8` (or Unit), `Root` split into linear tokens by trusted functions; specify the split functions and how leftover authority is consumed | `main` takes no parameters today (STMT-7) | R-0557 (TRUST-9) and STMT-7 | decided 2026-11-01 by the owner (final set): Superseded by the authority decision of 2026-11-01: there is no `Root` type; `main`'s parameters are the target's singletons, hosted `fn main() with(...) -> u8` and freestanding `fn main(uart: Uart, arena: Arena) with(Device, Alloc) -> u8`; revised 2026-11-02: `main` receives the target's grants and returns `u8` only ([decisions](decisions.md#decided-2026-11-02-authority)) |
| OD39 | <a id="od39"></a>The interface artifact format (added 2026-10-29, while recording OD9). Options: a generated `.coni` text file per module beside the build output; a JSON interface in the build directory; or the `pub` declarations rendered as Concrete source. Recommendation: rendered Concrete source (declarations without bodies), deterministic and reviewable as a diff Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): the `pub` declarations rendered as Concrete source without bodies, generated by the compiler, with an API-diff gate; it also carries private layout, impl methods, attributes, constants, capabilities and generic bodies, and is not read as FFI-6 bodyless foreign bindings | the compiler has the declaration-level `FileSummary` and `--report interface`, but no persisted per-module interface artifact and no API-diff gate of the proposed form | R-0556 (MOD-7) | decided 2026-11-01 by the owner (final set): `pub` decls rendered as Concrete source, compiler-generated, API-diff gate |
| OD40 | <a id="od40"></a>PAT-9 and the fallback arm of a desugared `if let`, `let ... else` or `while let` (added 2026-10-29, while fixing bug 317). Options: the fallback arm is not a written arm and is not judged; or it is judged, so `if let` over a one-variant enum is refused as unreachable. Recommendation: not judged, since the source has no arm to delete Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): moot if OD52 removes the desugared forms | `if let` over a one-variant enum is accepted | bug 317's repair (PAT-9) | decided 2026-11-01 by the owner (final set): Moot: OD52 removed `if let`/`while let`/`let...else` |
| OD41 | <a id="od41"></a>PAT-9 and integer ranges that span their type (added 2026-10-29, while fixing bug 317). Options: a catch-all after ranges covering the whole integer type is not refused (PAT-2 still requires it); or it is refused and PAT-2 is relaxed to accept ranges that cover the type. Recommendation: not refused, keeping PAT-2 as decided Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): close as range-specific under OD56, recording in PAT-2 and PAT-9 that an integer match still needs a catch-all and that listing every literal is not coverage | such a match is accepted | bug 317's repair (PAT-9, PAT-2) | decided 2026-11-01 by the owner (final set): Close as range-specific; integer matches keep a required catch-all, listing every literal is not coverage |
| OD42 | <a id="od42"></a>Comparisons on `bool` and `char` under OD26 (added 2026-10-29, while recording OD26, whose answer says "arithmetic, shifts and comparisons take numbers only"). Two readings: numbers only, so `b == true` and `c < 'z'` are refused (a `bool` is tested directly, a `char` converted by a named function); or "numbers" excludes pointers only, and `bool` and `char` keep equality (and `char` ordering). Recommendation: keep `==` and `!=` on `bool` and `char` and ordering on `char`, and refuse only pointers, which is what OD26's alignment with TRUST-1 is about Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): keep `==` and `!=` on `bool` and `char` and ordering on `char`, refuse ordering on `bool`; amend TYPE-6 and OD26 explicitly | the current compiler compares `bool` and `char` | bug 322's repair (TYPE-6) | decided 2026-11-01 by the owner (final set): Keep `==`/`!=` on bool/char and `<` on char; refuse ordering on bool |
| OD43 | <a id="od43"></a>How a type position resolves a name (added 2026-10-29, from the spec gap bug 229's ruling found). Options: (a) the current compiler's rules: type positions search the type namespace only, a user `enum Option` is always the builtin, and a parent sees its child's newtypes; (b) a user declaration shadows a builtin of the same name, with a warning; (c) a user type may not take a builtin type's name (refused). Recommendation: (c), which removes the shadowing question entirely; Austral reserves its builtin type names the same way Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (c) refused, for builtin-name collisions only, with the complete reserved set published (also for aliases and import renames); this answer would not retire OD43, whose type-versus-value lookup and child-module questions stay open in it. A user `struct Copy HeapArray` is treated as linear today | the current compiler follows (a) | MOD-1; bug 229's record | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse builtin-name collisions, publish reserved set. Completed 2026-11-02 by the owner: one namespace per module, and a child module's declarations only through `child::T` or an import ([decisions](decisions.md#decided-2026-11-02-namespace)) |
| OD44 | <a id="od44"></a>Two packages of one program that define the same top-level module name (added 2026-10-29, from bug 074's ruling). Options: (a) refused when the project loads, naming both packages (the current compiler); (b) module paths are qualified by their package, so both coexist. Recommendation: (a) until packages depend on packages (R-0440), then revisit with (b) Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (a) refused at load, naming both packages, until packages depend on packages (R-0440) | the current compiler refuses (bug 074) | MOD-1, MOD-4; R-0440 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse at load, naming both, until R-0440 |
| OD45 | <a id="od45"></a>Capability-variable inference (added 2026-10-29, from bug 063's ruling). Main today binds a callee's `cap C` variable from the capability set of an argument's function type when its type peek (`PeekType`) can compute that type without checking the argument, and refuses a variable no argument determines (E0242, `pick_generic::<i64>()`). Options: (a) specify the current compiler's peek-based rule, listing the argument forms it covers; (b) bind from the checked type of every argument, whatever its form; (c) require an explicit capability argument whenever an argument is not a name. Recommendation: (b), so whether a call infers does not depend on the argument's spelling Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (b) bind from the checked type of every argument; refuse unresolved or inconsistent ones; no result-context inference | the current compiler is (a) without the list | TRUST-4, TYPE-1; bug 063's record | decided 2026-11-01 by the owner (final set): Bind from checked type of every argument; no result-context. **Revised by the owner 2026-11-05 (row Q5.1/Q5.4, [revision](#decided-2026-11-05-revisions)): capability arguments are written explicitly at every polymorphic call and checked; no capability inference** |
| OD46 | <a id="od46"></a>Generic type-argument inference (added 2026-10-29, from bug 308's ruling). Main today binds each type parameter from the types its peek (`PeekType`) computes for the arguments given for it, a value `if` or `match` included since bug 308, but answers `.placeholder` for a generic call's result and some arms with binders, and refuses a parameter no argument determines; it never infers from the expected result type. Options: (a) specify the current compiler's peek-based rule, listing the forms it covers; (b) bind from the checked type of every argument, whatever its form; (c) also infer from the expected type at the call site. Recommendation: (b), local and predictable, with explicit type arguments for the rest; Austral infers type parameters from the arguments, and a `let` declaration's type can disambiguate a return-type-polymorphic call Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (b) from checked argument types only, never from the expected result; arguments that need an expected type are refused, not defaulted | the current compiler is (a) without the list | TYPE-13, TYPE-15; bug 308's record | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): From checked argument types only |
| OD47 | <a id="od47"></a>Loops: `while` and a counted range loop (added 2026-10-29) | the current compiler has `while` and the C-style `for (init; cond; step)`, `for (cond)` and `for { }`; bug 331 | exit 2q; R-0499; V1a's loops and exits | decided 2026-10-29 by the owner: (1) the C-style `for` is removed in every form; (2) loops are `while cond { ... }` and `for i from a until b { ... }`: half-open (`a`, ..., `b - 1`, empty when `a >= b`), the index immutable in the body, `a` and `b` evaluated once before the first iteration, the index of the bounds' integer type (both bounds of one type), `break` and `continue` as usual (`continue` advances to the next index), `from` and `until` reserved (whether reserved or contextual was reopened by the reviews of that day: OD50), LL(1) as `for` IDENT `from` expr `until` expr block with the restricted head expression for `b` (OD16); (3) in Core the counted loop desugars to the one `while` form, carrying its termination measure `b - i`. Now STMT-6@3, STMT-11@2 and STMT-12 (pending, bug 331) |
| OD48 | <a id="od48"></a>The index type of a counted loop over two literals (added 2026-10-29, while recording OD47). Options: (a) refused, as OD31 refuses any literal with no expected type (write `for i from 0 until n` with a typed bound, or annotate); (b) the index is `Int` there. Recommendation: (a), consistent with OD31 Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (a) refused, as OD31 refuses any literal with no expected type; a typed bound supplies the other bound's type, in either order | the counted loop is not in the current compiler | bug 331's repair (STMT-6) | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refused, as OD31 |
| OD49 | <a id="od49"></a>The arithmetic of a counted loop's termination measure (added 2026-10-29, while recording OD47). Options: (a) the measure is a mathematical integer in the proof only, never computed at run time; (b) it is computed in the unsigned type of the bounds' width; (c) a counted loop whose `b - a` cannot be represented is refused. Recommendation: (a): the loop compares `i < b` and increments `i`, which cannot overflow below `b`, so the measure need not exist at run time Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (a) a mathematical integer in the proof only, never computed at run time | the counted loop is not in the current compiler | bug 331's repair; the contracts chapter's loop variant | decided 2026-11-01 by the owner (final set): Mathematical integer in the proof only |
| OD50 | <a id="od50"></a>Reserved or contextual `from` and `until` (added 2026-10-29, from the reviews of OD47). Options: (a) reserved words everywhere, as OD47 first said: `let from: Int` is refused and the lexer has two more keywords; (b) contextual keywords, meaningful only between `for IDENT` and the block, so existing names stay legal. Recommendation: (a), one lexical rule and no context-dependent tokens, at the cost of two names; Austral reserves its loop words Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (a) reserved everywhere | the current compiler has neither word (bug 331) | bug 331's repair; SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Reserved everywhere |
| OD51 | <a id="od51"></a>Reverse, stepped and collection iteration (added 2026-10-29, from the reviews of OD47). Options: (a) none: the counted loop is ascending by one, everything else is a `while`; (b) add a descending form (`for i from a down until b`) and a step (`by k`) later, each its own decision; (c) add iteration over a collection. Recommendation: (a) now, revisiting (b) when a workload needs it; a `while` keeps the proof story at one loop construct Reviewed pick (2026-10-30, a recommendation that supersedes the recommendation above where they differ): (a) none now; each a later decision when a workload needs it | the current compiler has no counted loop (bug 331) | STMT-6 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): None now |
| OD52 | <a id="od52"></a>`if let`, `while let` and `let ... else` (added 2026-10-30, item S1 of the owner picks of that day). Question: Whether `if let`, `while let` and `let ... else` stay in the language or are removed in favour of `match`. Options: (a) keep the three forms (PAT-6, their desugaring to `match`); (b) remove them, `match` being the only refutable pattern form. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) remove. Austral: none of the three; `case` is the only refutable form | all three are accepted and desugar to a `match` with a catch-all arm (PAT-6) | PAT-6, PAT-8, PAT-9, OPEN-40, SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD53 | <a id="od53"></a>Struct update `..base` (added 2026-10-30, item S2 of the owner picks of that day). Question: Whether the struct update form `S { a: 1, ..base }` stays in the language. Options: (a) keep it; (b) remove it, every field written. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) remove. Austral: no struct update; every field is written | accepted (TYPE-7, OWN-15's value flow for `..base`) | TYPE-7, OWN-15 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD54 | <a id="od54"></a>`newtype` and `.0` (added 2026-10-30, item S3 of the owner picks of that day). Question: Whether `newtype` declarations and the `.0` projection stay, or a one-field struct with a private field replaces them. Options: (a) keep `newtype` and `.0`; (b) remove both, using a one-field struct whose field is private to its module. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) remove. Austral: no newtype; a type is made opaque by the module interface hiding its definition (a record being one possible definition) | `newtype` declarations and `.0` are accepted; `unwrap(id)` is an intrinsic | TYPE-7, TYPE-11, ARITH-5 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD55 | <a id="od55"></a>Match guards (added 2026-10-30, item S10 of the owner picks of that day). Question: Whether match guards (`pattern if cond =>`) stay in the language. Options: (a) keep them (PAT-4); (b) remove them, the condition written inside the arm. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) remove. Austral: no guards | guards are accepted and read-only (PAT-4) | PAT-4, PAT-2, PAT-9 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD56 | <a id="od56"></a>Range patterns (added 2026-10-30, item S11 of the owner picks of that day). Question: Whether integer range patterns (`1..=9 =>`) stay in the language (this amends OD19). Options: (a) keep them (PAT-7); (b) remove them, the comparison written in the arm or an `if` chain. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) remove; then close OPEN-41 as range-specific, recording in PAT-2 and PAT-9 that an integer match still needs a catch-all and that listing every literal is not coverage, so that catch-all is never unreachable. Austral: no range patterns | range patterns are accepted (PAT-7) | PAT-7, PAT-2, PAT-9, OPEN-41, OD19 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove; close OD41 as range-specific |
| OD57 | <a id="od57"></a>The region name of a borrow block (added 2026-10-30, item S12b of the owner picks of that day). Question: Whether a borrow block keeps its region name (`borrow x as r in R { }`) or drops `in R`. Options: (a) keep `in R`; (b) drop it, the block itself being the region. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) drop `in R`. Austral: the borrow statement names its region (`borrow x as r in R do ... end`); anonymous borrows `&x` in call arguments name none | the region name is written and has no other use in the language | REF-8, REF-11, SCOPE-D1 | decided 2026-11-01 by the owner (final set): Drop `in R` |
| OD58 | <a id="od58"></a>Borrow blocks stay (added 2026-10-30, item S12 of the owner picks of that day). Question: Whether borrow blocks (`borrow x as r in R { }`, as written today) stay the way to hold a reference across statements. Options: (a) keep them; (b) remove them, references living only within one call's arguments. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) keep (recorded as already agreed in the picks; no owner record yet). Austral: the borrow statement is the way to hold a reference across statements | borrow blocks are accepted (REF-8, REF-11) | REF-6, REF-8, REF-11, OPEN-36 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Keep |
| OD59 | <a id="od59"></a>One way to consume a `Heap` (added 2026-10-30, item S7 of the owner picks of that day). Question: Which operations consume a `Heap<T>`: the move-out `*h` (OD30), `destroy(h)`, `free(h)` or a new `take(h)`. Options: (a) keep `*h` and `free(h)` as today; (b) `*h` as move-out-and-free and `destroy(h)` extended to a Heap, `free` deleted, no `take`; (c) `take(h)` replaces `*h` as the move-out, `destroy(h)` extended to a Heap, `free` deleted. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b): `*h` and a `destroy(h)` extended to a Heap, no `free`, no `take` (a `take` would be another spelling of `*h`). Austral: not checked | `*h` moves out and frees and `free(h)` frees the cell and returns its value (MEM-5); `destroy(h)` on a Heap is refused (E0272: destroy() requires a named type) | MEM-5, OWN-13, OPEN-36 | decided 2026-11-01 by the owner (final set): `*h` + `destroy(h)`, no `free`, no `take` |
| OD60 | <a id="od60"></a>One consuming receiver form for `Destroy` (added 2026-10-30, item S8 of the owner picks of that day). Question: Whether `Destroy` is implemented through one consuming receiver form only. Options: (a) keep the receiver forms the current compiler accepts; (b) one consuming form (`fn destroy(self)`) only. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b) one consuming form. Austral: no destructor trait; a linear type's module exports an ordinary consuming function | a `Destroy` impl may take `self` or `&self`; `&mut self` is refused (E0587) | OWN-13, TRAIT-9, TRAIT-10 | decided 2026-11-01 by the owner (final set): One consuming form |
| OD61 | <a id="od61"></a>One coordinated removal list (added 2026-10-30, item review new 7 of the owner picks of that day). Question: Whether the decided and proposed removals (inline `mod`, the C-style `for`, `if let` / `while let` / `let ... else`, `newtype`, `..base`, range patterns, guards, `in R`, `break <expr>` and the `trusted mod` marker) are migrated as one coordinated list. Options: (a) one list, migrated in exit 2q's single transition; (b) each removal on its own schedule. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) one list, including dropping TRUST-6's `trusted mod` marker, which S14 removes (S14 is marked agreed in the picks; ROADMAP records no owner answer for it). Austral: not applicable | TRUST-6 (pending) still requires the `trusted mod` marker, which S14's pick would drop (no owner answer is recorded for S14) | TRUST-6, STMT-6, PAT-6, PAT-7, PAT-4, TYPE-7, MOD-4, SYN-1 | decided 2026-11-01 by the owner (final set): One list (incl. dropping `trusted mod`) |
| OD62 | <a id="od62"></a>Unused values and variables (added 2026-10-30, item Q3 of the owner picks of that day). Question: Whether an unused local variable or parameter is refused (Go's rule) and whether an unused `Result` or `Option` may be dropped by `discard`. Options: (a) refuse only an unused `Result` or `Option` (OWN-6); (b) Go's rule: any unused local or parameter is refused (an intentionally unused parameter is named `_`), and `discard` refuses `Result` and `Option`. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (b), stated as one invariant: every name a body binds is used or is `_` (a bodyless declaration has no body, so needs no exception); `discard` and wildcard drops refuse `Result` and `Option`, Copy or not; to clarify: `_` as a loop index, and an unused `&mut` binding under REF-10. Austral: not checked | unused Copy locals and parameters are accepted; OWN-6 refuses an unused fallible result | OWN-5, OWN-6, OWN-7, REF-10 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Every bound name used or `_`; `discard` refuses Result/Option |
| OD63 | <a id="od63"></a>Float literals take their expected type (added 2026-10-30, item Q4 of the owner picks of that day). Question: Whether a float literal takes the float type its position expects and is refused where nothing is expected, as ARITH-2@2 states under OD31's note that float literals get an explicit rule under the same principle. Options: (a) yes, as ARITH-2@2 states for integers and floats alike; (b) a float literal defaults to `f64`. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a). Austral: not checked | `let x = 1.5;` is accepted as `Float64` (ARITH-2@2 is partial, bug 327) | ARITH-2, ARITH-7 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Expected type, refused where none |
| OD64 | <a id="od64"></a>Raw pointers derived from a borrow (added 2026-10-30, item G19 of the owner picks of that day). Question: What a raw pointer derived from a borrow may do: whether it is valid only while the borrow lives, may escape the borrow block, may be passed to C, and how extern parameters say so. Options: (a) valid only while the borrow lives and never escaping it; (b) the operational loan rules of REF-14 only. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a): no returning, no escaping storage (a local `let` inside the block stays allowed), no converting to an integer and no capturing in an outer `defer`; borrow-derived pointers go only to call-only `extern` parameters; C uses it only during a call (memory C keeps must come from an allocation with its own owner); `extern` parameters say call-only (the default) or kept; field pointers come from the same borrow of the whole owner; deferred calls in the block run before the borrow ends; provenance survives copies, offsets, field pointers, helpers and indirect calls; a shared borrow never yields write access; `ptr::expose` is refused on such a pointer; the annotation's syntax gets an LL(1) check. Austral: not checked | no pass assumes `&mut` exclusivity (OD15); REF-14 bounds aliases by their loan | REF-14, TRUST-1, TRUST-3, FFI-3, OWN-12 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Valid only inside the borrow; call-only extern params |
| OD65 | <a id="od65"></a>Empty structs (added 2026-10-30, item review new 1 of the owner picks of that day). Question: Whether a struct with no fields (`struct S {}`) is allowed, as a unit-like type for capability and root tokens, or refused. Options: (a) allowed; (b) refused. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (raised by the review). Austral: not checked | the parser accepts `struct S {}` and `S {}`; the grammar requires at least one field | TYPE-7, TYPE-16, TRUST-9, OPEN-38 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Allow |
| OD66 | <a id="od66"></a>The unit literal `()` (added 2026-10-30, item review new 2 of the owner picks of that day). Question: Whether `()` is the unit value's literal, given that the grammar has no production for it. Options: (a) add `()` to the grammar; (b) no unit literal, Unit produced only by a statement or a Unit call. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (raised by the review). Austral: the unit value is written `nil` | the grammar has no production for `()` | SYN-1, TYPE-4 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Add `()` |
| OD67 | <a id="od67"></a>Locals that reuse a top-level name (added 2026-10-30, item review new 4 (SCOPE-4) of the owner picks of that day). Question: Whether a local binding may reuse the name of a top-level function, an import alias or an intrinsic (MEMORY_SEMANTICS §15.4 also lists constants). Options: (a) allowed, as today; (b) refused, as SCOPE-1 refuses shadowing a local. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (raised by the review). Austral: not checked | allowed | SCOPE-1, SCOPE-2, MOD-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD68 | <a id="od68"></a>Failure inside a deferred call (added 2026-10-30, item review new 5 of the owner picks of that day). Question: What OWN-12's text says about a failure inside a deferred call, given that an abort runs no deferred call (STMT-1, STMT-2). Options: (a) OWN-12 states that a trap inside a deferred call ends the program and runs no further deferred call, as STMT-2 and OD10 say for every abort; (b) the remaining deferred calls still run after a trapping one, which would amend STMT-2 and OD10. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (raised by the review). Austral: not checked | failure is abort only (STMT-2); OWN-12's rationale leaves the case open | OWN-12, STMT-1, STMT-2, STMT-11 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Trap ends the program, no further deferred call |
| OD69 | <a id="od69"></a>What "the remaining locals are destroyed" means (added 2026-10-30, item review new 6 of the owner picks of that day). Question: Whether STMT-11's last exit step ("the remaining locals are destroyed") means storage teardown only, with no synthesized `Destroy` call, as OWN-13 requires. Options: (a) storage teardown only, no call, as OWN-13 requires; (b) a remaining local whose type implements `Destroy` is destroyed by a synthesized call, which would amend OWN-13. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (raised by the review). Austral: no implicit destruction | nothing is destroyed implicitly (OWN-13) | STMT-11, OWN-13 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Storage teardown only |
| OD70 | <a id="od70"></a>Struct fields with no comma (added 2026-10-30, item P2 of the owner picks of that day). Question: Whether struct fields written without a separating comma (`struct S { a: i32 b: i32 }`) are refused. Options: (a) refused, the grammar wins; (b) the grammar adds the form. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse. Austral: separators are required | the parser accepts it | SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD71 | <a id="od71"></a>Enum variants with no comma (added 2026-10-30, item P3 of the owner picks of that day). Question: Whether enum variants written without a separating comma are refused. Options: (a) refused; (b) the grammar adds the form. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse. Austral: separators are required | the parser accepts it | SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD72 | <a id="od72"></a>An enum with no variants (added 2026-10-30, item P4 of the owner picks of that day). Question: Whether an empty enum `enum E { }` is refused or is the uninhabited type. Options: (a) refused; (b) the grammar adds it as the uninhabited type. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse until a workload needs an uninhabited type. Austral: not checked | the parser accepts it | SYN-1, PAT-2 | decided 2026-11-01 by the owner (final set): Refuse until a workload needs it |
| OD73 | <a id="od73"></a>Reserved words used as identifiers (added 2026-10-30, item P5 of the owner picks of that day). Question: Whether `cap` and `type`, which the lexer reserves, are refused as identifiers where the parser lets them through. Options: (a) refused, reserved words stay reserved; (b) the grammar lets them through there. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse. Austral: keywords are reserved | `expectIdent` accepts `cap` (and `type`) as a variant name | SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD74 | <a id="od74"></a>A raw pointer type with no qualifier (added 2026-10-30, item P6 of the owner picks of that day). Question: Whether a bare `*T` is refused or read as `*mut T`. Options: (a) refused, `*const` or `*mut` required; (b) the grammar adds `*T` as `*mut T`. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse; the qualifier is the safety-relevant part. Austral: not applicable | the parser reads `*T` as `*mut T` | SYN-1, TRUST-1 | decided 2026-11-01 by the owner (final set): Refuse; qualifier required |
| OD75 | <a id="od75"></a>An empty type parameter list (added 2026-10-30, item P7 of the owner picks of that day). Question: Whether `impl<> S` (an empty type parameter list) is refused. Options: (a) refused; (b) the grammar adds it. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse. Austral: not applicable | the parser accepts it | SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD76 | <a id="od76"></a>Unqualified struct patterns in `match` (added 2026-10-30, item G1-b of the owner picks of that day). Question: Whether an unqualified struct pattern is allowed in `match` (`match s { S { a } => ... }`), given that only `let` destructures structs today (the `if let` form follows OD52). Options: (a) refused in `match`, PAT-1's wording fixed to say so; (b) allowed. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) refuse in `match`; fix PAT-1's wording. Austral: not checked | the parser refuses it in `match` and `if let` and accepts it in `let` | PAT-1, PAT-5, SYN-1 | decided 2026-11-01 by the owner (final set): Refuse in `match`; fix PAT-1 |
| OD77 | <a id="od77"></a>Resync the grammar to the decided language (added 2026-10-30, item B of the owner picks of that day). Question: Whether `grammar/concrete.ebnf` is resynchronized for the items the language already decided: `E#V` becomes `E::V`, binding renaming, a function body with no trailing value and `;` for bodyless functions, no generic trait methods, assignment targets are places, unknown attribute names refused, and no `break <expr>`. Options: (a) approve the resync, as actual productions with a factored `place` prefix for assignment; (b) defer it, the divergences staying recorded in grammar/conformance_known.tsv (the decided language does not change either way). Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) approve, with actual productions, a `place` prefix and `break <expr>` removed. Austral: not applicable | the grammar is stale on these items (grammar/conformance_known.tsv) | SYN-1, PAT-1, STMT-6, STMT-8, OWN-8, FFI-6 | decided 2026-11-01 by the owner (final set): Approve resync with actual productions |
| OD78 | <a id="od78"></a>`mod X;` in the grammar (added 2026-10-30, item C1 (review new 3) of the owner picks of that day). Question: Whether the grammar gains `mod name;` (a module in its own file), which the parser accepts and OD33's pick would make the only module form. Options: (a) add it to the grammar; (b) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) add, item by item. Austral: each module is its own pair of files | the parser accepts it; the grammar lacks it | MOD-4, OPEN-33, SYN-1 | decided 2026-11-01 by the owner (final set): Add `mod X;` item by item |
| OD79 | <a id="od79"></a>`assert` in the grammar (added 2026-10-30, item C2 of the owner picks of that day). Question: Whether the grammar gains the proof-annotation statement `assert expr;`. Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): individual review required; no pick recorded. Austral: not checked | the parser accepts it | CON-2, CON-3, SYN-1 | decided 2026-11-01 by the owner (final set): Add `assert`. Extended 2026-11-06 by `assert(e) by thm(...)` ([SPARK row](#decided-project-spark-2026-11-06)) |
| OD80 | <a id="od80"></a>`assume` in the grammar (added 2026-10-30, item C3 of the owner picks of that day). Question: Whether the grammar gains the proof-annotation statement `assume expr;`. Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): individual review required; no pick recorded. Austral: not checked | the parser accepts it | CON-2, CON-3, SYN-1 | decided 2026-11-01 by the owner (final set): Keep `assume`, tracked: every claim depending on it is marked assumed **Qualified 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): `assume` cannot admit an operation in safe code.** |
| OD81 | <a id="od81"></a>`ghost let` in the grammar (added 2026-10-30, item C4 of the owner picks of that day). Question: Whether the grammar gains the proof-only binding `ghost let` (with `ghost` a contextual keyword). Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): individual review required; no pick recorded. Austral: not applicable | the parser accepts it | CON-4, SYN-1 | decided 2026-11-01 by the owner (final set): Add, with `ghost` reserved |
| OD82 | <a id="od82"></a>Loop contract attributes and where attributes attach (added 2026-10-30, item C5 (R7) of the owner picks of that day). Question: Whether the grammar gains `#[invariant(e)]` and `#[variant(e)]` before a loop, and whether attributes attach by kind (declaration attributes to the next declaration, loop attributes to the next loop). Options: (a) add them to the grammar and attach attributes by kind; (b) remove them from the parser; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a): attach by kind, declaration attributes to the next declaration, `#[invariant]` and `#[variant]` to the next loop. Austral: not checked | the parser accepts them | CON-2, STMT-12, SYN-1 | decided 2026-11-01 by the owner (final set): Add; attributes attach by kind **Extended 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): `#[variant]` also attaches to a function, one measure per recursive cycle; `#[may_not_terminate("reason")]` also attaches as a prefix to an expression (an indirect call), through one attribute-prefix production in statements.** |
| OD83 | <a id="od83"></a>The call-site allocator binding in the grammar (added 2026-10-30, item C6 of the owner picks of that day). Question: Whether the grammar gains the call-site allocator binding `f(...) with(Alloc = e)`. Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): individual review required; no pick recorded. Austral: not checked | the parser accepts it | TRUST-4, MEM-5, SYN-1 | decided 2026-11-01 by the owner (final set): No call-site binding `f(...) with(Alloc = e)`. Under the authority decision, one allocator form per target: hosted, `with(Alloc)` and no allocator value; freestanding, an `Arena` parameter plus `with(Alloc)`. Revised 2026-11-02 by the owner's rule: one form on every target, an `Allocator<A>` value plus `with(Alloc)` ([decisions](decisions.md#decided-2026-11-02-allocation)) |
| OD84 | <a id="od84"></a>Struct destructuring `let` in the grammar (added 2026-10-30, item C7 of the owner picks of that day). Question: Whether the grammar gains struct destructuring `let S { a } = e;`. Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): individual review required; no pick recorded. Austral: destructuring `let` of records exists (not checked) | the parser accepts it (PAT-5) | PAT-5, SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Add struct-destructuring `let` |
| OD85 | <a id="od85"></a>Variant destructuring with `else` in the grammar (added 2026-10-30, item C8 of the owner picks of that day). Question: Whether the grammar gains `let E::V { a } = e else { ... };`, which OD52's pick would remove. Options: (a) add it to the grammar; (b) remove it from the parser, so the language loses the form; (c) keep the recorded divergence for now. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): follows OD52 (removed under its pick). Austral: no `let ... else` | the parser accepts it (PAT-8) | PAT-8, OPEN-52, SYN-1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove (follows OD52) |
| OD86 | <a id="od86"></a>The body of an unbraced match arm (added 2026-10-30, item R1 of the owner picks of that day). Question: Whether the grammar narrows an unbraced match-arm body to an expression, a block or `return`, which is what the parser accepts (`continue;` as an unbraced body is refused). Options: (a) narrow the grammar; (b) widen the parser. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) narrow. Austral: not applicable | the parser accepts an expression, a block or `return` as an unbraced arm body and refuses other statements | SYN-1, PAT-3 | decided 2026-11-01 by the owner (final set): Narrow |
| OD87 | <a id="od87"></a>Capability arguments in an expression turbofish (added 2026-10-30, item R2/R3 of the owner picks of that day). Question: Whether capability arguments (`T + C`, `{}`) may be written in an expression or method turbofish. Options: (a) the grammar narrows to type arguments there until a workload needs them; (b) the parser adds them. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) narrow. Austral: not applicable | the parser refuses them; the grammar derives them | SYN-1, TRUST-4, OPEN-45 | decided 2026-11-01 by the owner (final set): Accept explicit capability arguments in a turbofish (inference fills omitted ones). **Revised by the owner 2026-11-05 (row Q5.1/Q5.4, [revision](#decided-2026-11-05-revisions)): explicit capability arguments are required; inference no longer fills omitted ones** |
| OD88 | <a id="od88"></a>The shape of capability arguments (added 2026-10-30, item R8 of the owner picks of that day). Question: Whether the grammar states the capability-argument shape rules the parser checks (a union of names only; type arguments before capability arguments). Options: (a) state them in the grammar; (b) leave them to the parser. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a). Austral: not applicable | the parser checks them; the grammar does not | SYN-1, TRUST-4 | decided 2026-11-01 by the owner (final set): State in grammar |
| OD89 | <a id="od89"></a>Capability parameters on a trait impl (added 2026-10-30, item R9 of the parser/grammar divergence report of 2026-10). Question: Whether a trait impl may declare capability parameters, which the grammar derives and the parser refuses. Options: (a) refused, the grammar narrowed; (b) allowed. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (in the divergence report, not the picks). Austral: not applicable | the parser refuses them (declare them on an inherent impl) | SYN-1, TRAIT-9, TRUST-4 | decided 2026-11-01 by the owner (final set): Refuse; declare on inherent impl |
| OD90 | <a id="od90"></a>`struct Copy <T>` and contextual keywords (added 2026-10-30, item Copy of the owner picks of that day). Question: Whether `Copy` stays a contextual keyword, with the LL(1) checkers taught to model it, or becomes a reserved word (the other unreserved words, `self`, `repr`, `packed` and `align`, stay as they are unless decided separately). Options: (a) reserve `Copy` as a keyword, refusing it as an identifier; (b) keep it contextual, the LL(1) checkers taught to model a quoted unreserved terminal as also IDENT, each conflict found listed for the owner (letters as in the divergence report). Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): (a) reserve `Copy`: one lexical rule, consistent with OD50 (reserved `from` and `until`) and OD43 (builtin names refused as user names). Austral: its keywords are reserved | contextual; the `struct Copy <T>` conflict is invisible to the checkers' token model | SYN-1, OWN-D1 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Reserve `Copy` |
| OD91 | <a id="od91"></a>A cast followed by `<` (added 2026-10-30, item LL(1) type\|5.2 of grammar/ll1_known_conflicts.tsv). Question: How `x as T < y` parses, given that `<` after a cast's type name may start type arguments or be the less-than operator. Options: (a) a cast's type takes no type arguments unless parenthesized (`x as (T<U>)`), so `<` is less-than; (b) the parser's reading: `<` always starts type arguments, so the comparison needs parentheses (`(x as T) < y`); (c) refuse `<` directly after a cast's type and require parentheses either way. Pick (the coordinator's pick after the Kimi, Codex and Grok review of 2026-10-30, a recommendation and not a decision): none given (in the LL(1) ledger, not the picks). Austral: a conversion is the cast expression `e : T`, which takes no type arguments after it, so the conflict does not arise | the parser always reads type arguments, so `x as T < y` is refused (grammar/ll1_known_conflicts.tsv, row type\|5.2) | SYN-1, SYN-2, ARITH-5 | decided 2026-11-01 by the owner (final set): `x as T < y` is less-than; a generic cast type needs parentheses `x as (Vec<T>)` |
| OD92 | <a id="od92"></a>A capability set inferred from callbacks (added 2026-10-30, raised while absorbing CALLABLE_VALUES and HANDLE_CAPABILITIES). Question: Whether a combinator may write its capability set as that of its callbacks (`with(f)`), the checker computing the union of the sets of the callbacks its body calls. Bears on TYPE-D1, TYPE-17, TRUST-4. The current compiler: no such form; `with(f)` reads `f` as a capability name (an unresolved one, which MOD-1 refuses and the current compiler accepts: bug 337), so a combinator names a capability parameter (`fn map<T, U, cap C>(.., f: fn(&T) with(C) -> U) with(C)`). The callable-values design (2026-06-12, [CALLABLE_VALUES_AND_CAPABILITIES.md](../legacy/docs/archive/design-records/CALLABLE_VALUES_AND_CAPABILITIES.md) §6) recorded the shortcut as specified and not built, after [research/language/capability-polymorphism.md](../legacy/research/language/capability-polymorphism.md); no roadmap item tracks it. Options: (a) no shortcut, combinators name capability parameters; (b) add it, as set propagation and not row unification. Austral: not applicable (capabilities are values). Pick: none given (raised by the absorption of 2026-10-30). | see OPEN-92 | see OPEN-92 | decided 2026-11-01 by the owner (final set): No shortcut; name a capability parameter |
| OD93 | <a id="od93"></a>Widening a function value's capability set (added 2026-10-30, raised while absorbing CALLABLE_VALUES and HANDLE_CAPABILITIES). Question: Whether a function value converts to a function type whose capability set contains its own, implicitly by subset or by an explicit conversion. Bears on TYPE-4, TYPE-17, TRUST-4. The current compiler: refused (E0220): `fn(Int) -> Int` is not a `fn(Int) with(Console) -> Int`, nor `with(File)` a `with(Std)`, and there is no explicit conversion; a capability-polymorphic parameter accepts either by instantiating its variable. The callable-values design (§10) says there is no implicit widening, and that "widening is explicit or via lattice subsumption only", with a lattice example (`Concurrent ⊇ Async`) whose names are not capabilities; HANDLE_CAPABILITIES R7 keeps handle types invariant, as TYPE-4 does. Options: (a) exact types, as in the current compiler; (b) subsumption into a larger set; (c) an explicit conversion. Austral: not applicable (capabilities are values). Pick: none given (raised by the absorption of 2026-10-30). | see OPEN-93 | see OPEN-93 | decided 2026-11-01 by the owner (final set): Exact types **Canonical current capability-set rule: authority rule 4; this earlier exact-types answer refers to it.** |
| OD94 | <a id="od94"></a>Names in `with(...)` that are not capabilities (added 2026-10-30, raised while absorbing CALLABLE_VALUES and HANDLE_CAPABILITIES). Question: Whether a name in `with(...)` that is not a capability, a capability alias or a capability variable in scope is refused. Bears on TRUST-D1, TYPE-D1, TRUST-4. The current compiler: accepted as a capability of its own: `fn main() with(Foo) -> Int` compiles and runs, and a call to a function that requires `Foo` is refused only in a caller that does not list it (E0520). The compiler's `validCaps`, TRUST-4's rationale and [SAFETY.md](../legacy/docs/verification/SAFETY.md) name nine capabilities. Options: (a) refuse an unknown name; (b) an open vocabulary. Austral: not applicable (capabilities are values). Pick: none given (raised by the absorption of 2026-10-30). | [MOD-1](../legacy/docs/spec/modules.md#MOD-1) refuses the name; the current compiler accepts it (bug 337) | MOD-1@1 | withdrawn 2026-10-30: not an owner question; MOD-1@1 refuses the name (bug 337) |
| OD95 | <a id="od95"></a>What `Time`, `Env`, `Process` and `Alloc` mean (added 2026-10-30, raised while absorbing CALLABLE_VALUES and HANDLE_CAPABILITIES). Question: What authority each of `Time`, `Env`, `Process` and `Alloc` names. Bears on TRUST-D1, TRUST-4. The current compiler: no document states them; HANDLE_CAPABILITIES §2 defined `Console`, `File` and `Network`, and SAFETY.md `Random` (TRUST-D1). std requires `Time` for its clock and sleep functions, `Env` for environment variables and for `std.net`'s `bind` and `connect`, `Process` for exit, spawn, wait and kill, and `Alloc` for heap allocation. Options: state each as std uses it, or narrow or split it (std's `Env` on socket functions is the case to settle). Austral: not applicable (capabilities are values). Pick: none given (raised by the absorption of 2026-10-30). | see OPEN-95 | see OPEN-95 | decided 2026-11-01 by the owner (final set): State each; move socket `bind`/`connect` from `Env` to `Network` |
| OD96 | <a id="od96"></a>Two foreign bindings of one C symbol (added 2026-10-30, raised while absorbing CALLABLE_VALUES and HANDLE_CAPABILITIES). Question: Whether two foreign bindings of one C symbol (`#[link_name]`) must agree on its C signature. Bears on FFI-3, FFI-5. The current compiler: accepted: `abs_a(x: i32) with() -> i32` and `abs_b(x: i64) with() -> i64`, both bound to `abs`, compile and the binary runs, while the interpreter stops at run time on the mismatched width. HANDLE_CAPABILITIES §5 (encoding A, one binding per effect for one C symbol) planned to refuse a mismatch with a diagnostic. Options: (a) refuse; (b) allow, each binding's signature trusted on its own. Austral: not applicable. Pick: none given (raised by the absorption of 2026-10-30). | see OPEN-96 | see OPEN-96 | decided 2026-11-01 by the owner (final set): Refuse |
| OD97 | <a id="od97"></a>A build profile that omits or demands an overflow check (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: Whether a build profile may omit the run-time check of an integer operation that no proof discharges, or refuse such an operation at compile time. Bears on ARITH-3, ARITH-9. The current compiler: every profile emits every check, and no option turns one off; ARITH-3's rationale says a profile changes reports, never code generation, and OD10 decided that arithmetic is checked "by default". The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §3.1 instead let a release profile omit a check that is "explicitly configured off and reported", and a provable or high-integrity profile refuse an unproved overflow site. Options: (a) every profile keeps every check that no discharged proof removes; (b) a release profile may turn checks off when configured and reported, never wrapping; (c) as (a), and a profile may also refuse an operation whose no-overflow obligation is not discharged. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md (2026-10-30). | see OPEN-97 | see OPEN-97 | decided 2026-11-01 by the owner (final set): Keep every check; a profile may refuse undischarged ops **Subsumed 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): every build refuses an operation without discharged evidence.** |
| OD98 | <a id="od98"></a>Pointer and reference conversions written with `as` (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: Which conversions between raw pointers and references `as` writes (`&x as *const T`, `p as &T`, `p as &mut T`, `p as *mut U`). Bears on TRUST-1, TRUST-3, REF-5, ARITH-5. The current compiler: `&x as *const T` is accepted in safe code, `p as &T` from a raw pointer is accepted in trusted or `Unsafe` code (the binary and `--interp` agree), and a reference cast between different pointee types (`a as &Int` with `a: &A`) is refused (E0553). No entry states these: TRUST-3 forms a reference from a raw pointer with `&*p`, and REF-5 lists borrowing and projection as the ways a reference is formed. The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §8 kept `as` "the spelling of pointer and reference casts (`as *const T`, `as *mut T`, `as &K`, `as &mut V`)", 281 lines of std. Options: (a) `as` keeps every one of them; (b) `as` converts only a reference to a raw pointer, and a reference is formed from a raw pointer only by `&*p` (TRUST-3); (c) pointer conversions become named functions. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md (2026-10-30). | see OPEN-98 | see OPEN-98 | decided 2026-11-01 by the owner (final set): Reference to raw pointer conversion only in trusted/Unsafe code (equal to Austral) |
| OD99 | <a id="od99"></a>The names of the named conversions (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: The spellings of the named conversions of ARITH-5, ARITH-10 and ARITH-11 (`try_convert`, `truncate`, `reinterpret`, the integer-to-float and `f64`-to-`f32` conversions, and the float roundings `trunc`, `round`, `floor`, `ceil`). Bears on ARITH-5, ARITH-10, ARITH-11. The current compiler: none of them exists (E0101). ARITH-5's sentence names `truncate` and `reinterpret`, while the archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §8.2 calls its spellings indicative, to be fixed by the API's owner; it names the integer-to-float and `f64`-to-`f32` conversions by their rounding only. Options: (a) the spellings above, as builtins; (b) other names, or std functions rather than builtins. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md (2026-10-30). | see OPEN-99 | see OPEN-99 | decided 2026-11-01 by the owner (final set): These spellings, as builtins |
| OD100 | <a id="od100"></a>Comparisons on a type parameter (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: Whether a comparison on a value of a `Copy`-bounded type parameter is accepted and checked again at each instantiation, or refused in the generic body. Bears on TYPE-6, TYPE-9, PASS-1, OPEN-42. The current compiler: `a < b` with `a, b: T` and `T: Copy` is accepted, and an instantiation at a type with no comparison is refused after monomorphization (E0229, `post-mono`); without the `Copy` bound it is refused in the body (E0229, `check`). TYPE-9's rationale says a generic body is checked once, from its bounds, which a per-instantiation check departs from. Options: (a) keep the current compiler's per-instantiation check; (b) refuse a comparison on a type parameter until a bound states it (a comparison trait); (c) refuse it. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md §8a (2026-10-30). | see OPEN-100 | see OPEN-100 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse until a bound states it |
| OD101 | <a id="od101"></a>What a trap writes (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: Whether a run-time trap writes a message naming the operation, its operands and its source location before the process ends, and in what form. Bears on STMT-2, STMT-7, ARITH-3. The current compiler: the binary writes nothing and ends by `SIGABRT`, and `--interp` reports a run-time error naming the trap (`arithmetic overflow (checked +)`). The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §9.2 described a message `concrete: arithmetic overflow in function 'f' at file:line` with the operation, the operands and the policy. Options: (a) the binary writes nothing; (b) it writes one line naming the trap and its location; (c) the §9.2 form. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md (2026-10-30). | see OPEN-101 | see OPEN-101 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): One line naming the trap and location. Its form, decided 2026-11-06: [runtime row](#decided-project-runtime-2026-11-06) |
| OD102 | <a id="od102"></a>`Float32` and `Char` as type spellings (added 2026-10-30, raised while absorbing ARITHMETIC_POLICY and VALUE_MODEL). Question: Whether `Float32` and `Char` are other spellings of `f32` and `char`, as `Float64` and `Bool` are of `f64` and `bool`. Bears on TYPE-19, SYN-3. The current compiler: the parser maps `Float64` and `Bool` to `f64` and `bool` but not `Float32` or `Char`, so `fn g(x: f32) -> Float32 { return x; }` is refused (E0220) while the resolver's `tyFromName` maps all four. The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §1 names `Float32`/`f32` as two spellings. Options: (a) `Float32` and `Char` become spellings of `f32` and `char`; (b) neither, keeping the current compiler's `Float64` and `Bool`; (c) `Float32` and `Char` decided separately. Whether every capitalized spelling (`Int`, `Uint`, `Float64`, `Bool`) is removed is a separate removal question, not asked here. Austral: not checked. Raised by the absorption of ARITHMETIC_POLICY.md (2026-10-30). | see OPEN-102 | see OPEN-102 | decided 2026-11-01 by the owner (final set): No `Float32` or `Char` aliases. Completed 2026-11-02 by the owner: the aliases `Int`, `Uint`, `Float64` and `Bool` are removed too ([decisions](decisions.md#decided-2026-11-02-aliases)) |
| OD103 | <a id="od103"></a>`as` between reference types (added 2026-10-30, raised while absorbing MEMORY_SEMANTICS). Question: Whether `as` may convert a reference type to a reference type, given that REF-5 lists borrowing and projecting as the only operations that form a reference. Bears on REF-5, REF-6, ARITH-5, TRUST-4. The current compiler: an identity cast between equal reference types is accepted and denotes the operand's place (`read(r as &Int)` with `r: &Int`, and `read(&v as &Int)`, exit 42 on both consumers); every other cast between reference types, `&mut Int as &Int` included, is E0553 at core-check under ARITH-5's tag, whose sentence covers only numeric, `bool` and `char` conversions; a cast from a reference to a raw pointer is allowed (TRUST-4). The design record (MEMORY_SEMANTICS §15.3) listed a cast of a traced reference binding (`r as &U`) among the reference-forming operations. Options: (a) refuse `as` between reference types; (b) allow the identity cast as a no-op on the operand's place. Conversions between a reference and a raw pointer are OPEN-98's, not this question's. Austral: not checked. Pick: none given (raised by the MEMORY_SEMANTICS absorption, 2026-10-30). | see OPEN-103 | see OPEN-103 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse |
| OD104 | <a id="od104"></a>A `#[variant]` written on a counted loop (added 2026-10-30, from the Codex and Kimi review of the OD47 loop rules). Question: whether a `#[variant]` attribute written on a counted loop is refused, checked like any loop variant, or ignored. Options: (a) refused, the loop's own measure being its only variant; (b) allowed and checked as a loop variant (CON-2); (c) allowed and ignored. No pick given | the counted loop is not in the current compiler (bug 331) | STMT-12, CON-2 | decided 2026-11-01 by the owner (final set): Refuse |
| OD105 | <a id="od105"></a>Where a counted loop's `#[invariant]` is checked (added 2026-10-30, from the same review). Question: where an `#[invariant]` on a counted loop is checked, given that CON-2 checks a loop invariant before the loop and after every iteration. Options: (a) as CON-2 says for every loop; (b) at each entry to the body, so nothing is checked when the loop runs no iteration. No pick given; (b) needs proof requirement 2 | the counted loop is not in the current compiler (bug 331) | STMT-12, CON-2 | decided 2026-11-01 by the owner (final set): As CON-2: before the loop and after every iteration |
| OD106 | <a id="od106"></a>The result type of a checked conversion (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether a checked conversion (`try_convert`) reports a value it cannot preserve as `Option::None` or as a `Result` error carrying the reason. Bears on ARITH-5, ARITH-10. The current compiler: no checked conversion exists (E0101, R-0500). The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §8.2 wrote `try_convert::<T>(x) -> Option<T>` "(or a `Result` with a reason)" and left the choice to the API's owner. Options: (a) `Option<T>`; (b) a `Result` whose error names the reason (out of range, not integral, NaN, infinite, not representable). Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | no checked conversion exists (E0101, R-0500) | ARITH-5, ARITH-10 | decided 2026-11-01 by the owner (final set): `Result<T, OutOfRange>` (failure, not absence) |
| OD107 | <a id="od107"></a>What a float-to-integer rounding gives for NaN, infinities and out-of-range values (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether each float-to-integer rounding operation (`trunc`, `round`, `floor`, `ceil`) gives a value or an error for NaN, an infinity or a result outside the target type's range, and which value. Bears on ARITH-1, ARITH-11. The current compiler: the rounding operations do not exist (R-0500); a float-to-integer `as` truncates toward zero and aborts on NaN, an infinity or a value out of range, natively and in `--interp`. The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) §8.2 required a stated result for every input, "either as a value or as an error". Options: (a) an error, as `try_convert` reports; (b) a value: the nearest value of the type for an out-of-range input or an infinity, and 0 for NaN; (c) a trap, as `as` does today. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | the rounding operations do not exist; a float-to-integer `as` truncates toward zero and aborts on NaN, an infinity or a value out of range | ARITH-1, ARITH-11 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): An error, as `try_convert` |
| OD108 | <a id="od108"></a>A capability listed twice in a set (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether a capability set that lists one capability twice (`with(Console, Console)`) is the same set as the one that lists it once, is refused, or is a different set. Bears on TYPE-D1, TYPE-17, TYPE-4. The current compiler: accepted where it is written, and a different type: `fn(Int) with(Console) -> Int` is not a `fn(Int) with(Console, Console) -> Int`, in either direction (E0220), because `CapSet.normalize` sorts a set and does not remove a repeated name. The callable-values design ([CALLABLE_VALUES_AND_CAPABILITIES.md](../legacy/docs/archive/design-records/CALLABLE_VALUES_AND_CAPABILITIES.md)) calls the capabilities of a function type a set. Options: (a) the same set; (b) refuse a repeated capability where it is written; (c) a different set, as in the current compiler. Austral: not applicable (capabilities are values). Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | accepted, and a different set: `with(Console, Console)` is not `with(Console)` (E0220) | TYPE-D1, TYPE-17, TYPE-4 | decided 2026-11-01 by the owner (final set): Refuse a repeated capability |
| OD109 | <a id="od109"></a>Specializations that differ only in a function type's capabilities (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether the symbol of a generic function's instantiation includes the capability set of a function-type argument, so that two instantiations that differ only in that set have distinct symbols. Bears on TYPE-17, TYPE-18. The current compiler: one: `pick<T: Copy>` instantiated at `fn(Int) -> Int` and at `fn(Int) with(Console) -> Int` emits the single function `pick_for_Fn_T_Int_to_Int_E`, because Mono's `tyToSuffix` drops a function type's capability set while it keeps a struct's capability arguments (E0809's history), and the program runs correctly since capabilities have no run-time representation (TYPE-18). The archived [HANDLE_CAPABILITIES.md](../legacy/docs/archive/design-records/HANDLE_CAPABILITIES.md) R8 required collision-free symbol identity across instantiations and left code sharing to its own argument. Options: (a) the set is part of the symbol, as for struct capability arguments; (b) it is not, one symbol serving both, stated as erasure with its correctness argument. Whether two symbols share one body stays an implementation choice (TYPE-18). Austral: not applicable (capabilities are values). Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | one specialization: Mono's symbol drops a function type's capability set | TYPE-17, TYPE-18 | decided 2026-11-01 by the owner (final set): Set is part of the symbol |
| OD110 | <a id="od110"></a>Enums at the foreign boundary (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether a value of enum type may cross an `extern fn` boundary, and if so in what representation. Bears on FFI-3, FFI-7. The current compiler: refused: `extern fn f(x: E)` with `enum Copy E { A, B }` is E0574 (a non-FFI-safe parameter); only scalars, raw pointers and `repr(C)` structs cross. The design record [LAYOUT_CONTRACT.md](../legacy/docs/archive/design-records/LAYOUT_CONTRACT.md) says enums must not cross (§3.2); before it was archived it also said they cross as integers. Options: (a) refused, as in the current compiler; (b) a fieldless enum crosses as an integer of a stated width, which needs a stated discriminant for each variant. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | refused (E0574) | FFI-3, FFI-7 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refused |
| OD111 | <a id="od111"></a>Misaligned fields of a packed struct (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether a `#[repr(packed)]` struct may hold a field whose alignment exceeds the alignment of its offset, and whether such a field may be borrowed. Bears on FFI-4, FFI-8, REF-5. The current compiler: both accepted: `#[repr(packed)] struct P { v: u8, l: u32 }` places `l` at offset 1, and `&p.l` is accepted and reads the field correctly in the binary and in `--interp`. [LAYOUT_CONTRACT.md](../legacy/docs/archive/design-records/LAYOUT_CONTRACT.md) §2 restricts a packed struct to fields whose alignment does not exceed their position, without saying what enforces it. Options: (a) refuse such a field; (b) accept it and refuse a reference to it; (c) accept both, as in the current compiler. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | both accepted on both consumers | FFI-4, FFI-8, REF-5 | decided 2026-11-01 by the owner (final set): Accept field, refuse a reference to it |
| OD112 | <a id="od112"></a>Mutation through a shared reference (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether a value reached through a shared reference `&T` may be changed, by a write through a raw pointer derived from the reference or by a cell type. Bears on REF-10, OWN-10, TRUST-2, TRUST-5. The current compiler: safe code changes a value only through a `mut` binding or a `&mut` reference, and there is no cell type; a trusted function may convert `r: &Int` to `*mut Int` (`r as *const Int as *mut Int`) and store through it: the binary does the store, and `--interp` stops ("deref-assign through immutable ref"). The archived [MEMORY_SEMANTICS.md](../legacy/docs/archive/design-records/MEMORY_SEMANTICS.md) §12 said there is no `Cell`, `RefCell` or `UnsafeCell` equivalent and that mutation flows from `let mut` through `&mut`; the [overview](../legacy/docs/spec/overview.md) lists no interior mutability in safe code, with a later `UnsafeCell<T>` gated by `Unsafe`. Options: (a) never: a write through a pointer derived from a `&T` is undefined behaviour, a premise trusted code keeps (TRUST-2); (b) as (a), with a cell type gated by `Unsafe` as the one exception; (c) a trusted write through such a pointer is allowed. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | safe code cannot; a trusted write through `r as *const T as *mut T` runs in the binary and stops `--interp` | REF-10, OWN-10, TRUST-2, TRUST-5 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Never; UB premise trusted code keeps |
| OD113 | <a id="od113"></a>The ownership exceptions of trusted code (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: Whether trusted code keeps its two exceptions to the ownership rules, destroying a value through a reference and releasing with `vec_free` a vector whose elements are not Copy. Bears on TRUST-5, TRUST-12, OWN-5, OWN-8. The current compiler: both are accepted in trusted code only (elsewhere E0290 under OWN-8 and E0287 under OWN-5): std's collections destroy an element through `(p as &T)` in drop glue after its owner was consumed, and a trusted function may free a buffer it has emptied. The archived [MEMORY_SEMANTICS.md](../legacy/docs/archive/design-records/MEMORY_SEMANTICS.md) §11 said that `trusted` does not relax linearity, and TRUST-5's rationale says the same. Options: (a) keep both, each a named trusted operation with its premise (the owner was consumed; the vector is empty); (b) remove both, drop glue moving the element out of raw memory instead (TRUST-7); (c) keep only destruction through a reference; (d) keep only `vec_free` of an emptied vector. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | both accepted in trusted code only (E0290, E0287 elsewhere) | TRUST-5, TRUST-12, OWN-5, OWN-8 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove both |
| OD114 | <a id="od114"></a>How integer division rounds (added 2026-10-30, from the Codex and Kimi review of the absorption). Question: How an integer division that does not abort rounds its quotient, and which sign a nonzero remainder takes. Bears on ARITH-3. The current compiler: the quotient is truncated toward zero and a nonzero remainder has the sign of the dividend, as C99 and LLVM's `sdiv` and `srem` give (`-7 / 2` is `-3`, `-7 % 2` is `-1`, `7 % -2` is `1`), in the binary, the interpreter and the constant folder (`IntArith.evalIntBinOp`). The archived [ARITHMETIC_POLICY.md](../legacy/docs/archive/design-records/ARITHMETIC_POLICY.md) states when division aborts (§5) but not how it rounds. Options: (a) truncation toward zero, as in the current compiler; (b) floored division, the remainder taking the divisor's sign; (c) Euclidean division, the remainder never negative. Austral: not checked. Pick: none given (raised by the Codex and Kimi review of the absorption, 2026-10-30). | the quotient is truncated toward zero and a remainder has the dividend's sign (C99) | ARITH-3 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Truncation toward zero |
| OD115 | <a id="od115"></a>The body and totality of a specification function (added 2026-10-30, raised while absorbing the verification documents). Question: Whether a `spec fn` may be declared without a body, and whether its body must be shown total. Bears on CON-3, CON-5, CON-1. The current compiler: both `spec fn big(x: Int) -> bool;` and `spec fn big(x: Int) -> bool = x > 10;` are accepted, and so is a recursive body that never terminates (`spec fn loopy(x: Int) -> bool = loopy(x + 1);`), with no check. [CONTRACTS_GUIDE.md](../legacy/docs/verification/CONTRACTS_GUIDE.md) calls a `spec fn` "an erased mathematical specification, no body"; contracts.md's examples (CON-3) give it a body; [CONTRACTS_AND_VCS.md](../legacy/docs/verification/CONTRACTS_AND_VCS.md) (Soundness Bridge) requires it to be total. Options: (a) a body is required and must be total (structural recursion or a checked measure); (b) a body is optional, a body-less one an uninterpreted function a proof must constrain, and a body must be total; (c) as in the current compiler, no totality check. Austral: not applicable. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-115 | see OPEN-115 | decided 2026-11-01 by the owner (final set): Body required and total |
| OD116 | <a id="od116"></a>A checked total function category (added 2026-10-30, raised while absorbing the verification documents). Question: Whether the language has a `total fn` category, a runtime function checked to terminate without trapping that contracts may then call. Bears on CON-1, CON-3, CON-5. The current compiler: there is no such category (`total fn f(..)` is a parse error, E0001); a contract clause may still call a capability-free runtime function until CON-3's judgment lands. [CONTRACTS_AND_VCS.md](../legacy/docs/verification/CONTRACTS_AND_VCS.md) (Design Principles) distinguishes `spec fn`, a checked `total fn`, ordinary and trusted functions, and admits a `total fn` into contracts once its obligations close. Options: (a) add the category; (b) no category: contracts call only `spec fn` (CON-3's full judgment). Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-116 | see OPEN-116 | decided 2026-11-01 by the owner (final set): No category |
| OD117 | <a id="od117"></a>`old`, quantifiers and implication in contracts (added 2026-10-30, raised while absorbing the verification documents). Question: Whether contract expressions gain `old(x)`, quantifiers and an implication or equivalence operator, and with what syntax. Bears on CON-2, CON-3, SYN-1. The current compiler: `#[ensures(result == old(x))]` compiles and runs, and `--report contracts` marks the clause `invalid_contract_expression` (unknown function `old`); `forall i: Int, ...` is a parse error (E0001); there is no implication operator. [CONTRACTS_AND_VCS.md](../legacy/docs/verification/CONTRACTS_AND_VCS.md) (Contract Expression V1) lists all three as deferred. Options: (a) add each, with a syntax decided per form; (b) keep them out, a claim needing one being a Lean theorem; (c) refuse `old(..)` now as an unknown name, deciding the rest later. Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-117 | see OPEN-117 | decided 2026-11-01 by the owner (final set): No `old`, quantifiers or implication in contracts; state such properties as Lean theorems |
| OD118 | <a id="od118"></a>A proven run-time violation in trusted code (added 2026-10-30, raised while absorbing the verification documents). Question: Whether an index the compiler proves out of bounds, or a division it proves to be by zero, is refused in `trusted` and `with(Unsafe)` code as in safe code. Bears on MEM-6, ARITH-3, TRUST-5, TRUST-12. The current compiler: `a[5]` on a `[Int; 3]`, or `x / 0`, is refused in safe code (E0900, `error[runtime-safety]`) and compiles in a `trusted fn` (the index also in a function declaring `Unsafe`), where it aborts at run time on both consumers. MEM-6 states the refusal with no exemption; [KNOWN_HOLES.md](../legacy/docs/verification/KNOWN_HOLES.md) C7 records the exemption as intended. Options: (a) refuse everywhere, as MEM-6 reads; (b) keep the exemption and state it in MEM-6. Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-118 | see OPEN-118 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse everywhere **Subsumed 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): refusal of proven violations becomes refusal of unproven safety, everywhere.** |
| OD119 | <a id="od119"></a>Buffered output when the process aborts (added 2026-10-30, raised while absorbing the verification documents). Question: Whether output the program wrote before a trap or abort is flushed before the process ends. Bears on STMT-1, STMT-2, PASS-13, OPEN-101. The current compiler: print builtins write through C's buffered stdio, and `abort` does not flush it on glibc (a binary that prints `hello` and then traps prints nothing on Linux) while it does on Darwin; the interpreter models the same buffer and the same platform difference. STMT-2 says a failure ends the process at once and is silent on output already written, so the observable trace of a trapping program differs by platform. Recorded by [INTERPRETER_TRUST.md](../legacy/docs/verification/INTERPRETER_TRUST.md) §2. Options: (a) everything written before the trap is output (flush on abort, or unbuffered output); (b) what was written is unspecified on a trap, and PASS-13 compares output only for exiting runs. Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-119 | see OPEN-119 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Everything written before the trap is output |
| OD120 | <a id="od120"></a>A vacuous contract (added 2026-10-30, raised while absorbing the verification documents). Question: Whether a contract whose precondition is unsatisfiable is refused by the language or only reported, under a project policy. Bears on CON-1, CON-2. The current compiler: `#[requires(x > 5 && x < 3)]` compiles; a decided-unsatisfiable precondition makes the claim `vacuous`, never `proved`, and E0613 refuses it only under the `forbid-vacuous` policy (`Concrete.Policy`), not in a plain build. [CONTRACTS_AND_VCS.md](../legacy/docs/verification/CONTRACTS_AND_VCS.md) (Soundness Bridge) states the reporting rule. Options: (a) a language refusal in every build; (b) tooling only: always reported `vacuous`, refused under a policy, as in the current compiler. Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-120 | see OPEN-120 | decided 2026-11-01 by the owner (final set): Tooling: reported `vacuous`, refused under policy **Qualified 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): a vacuous precondition used for safety admission is refused in every build.** |
| OD121 | <a id="od121"></a>Projections from a base that is not a traceable place (added 2026-10-30, raised while absorbing the verification documents). Question: Whether a field access, index or `*` whose base is not a traceable place (an `if` or `match` value, `**r`, a reference read out of storage) is refused, or accepted once the checker can trace it. Bears on REF-5, MEM-4, MEM-8, TYPE-7. The current compiler: refused (E0238, `untraceablePlace`), whether the projection reads a Copy value or forms a reference: `(if c { a } else { b }).f`, `(**r).f`, `*w.r`. No entry states the refusal: REF-5 forbids a branch value or a stored reference as a reference's root, and MEM-4, MEM-8 and TYPE-7 do not restrict a projection's base. [KNOWN_HOLES.md](../legacy/docs/verification/KNOWN_HOLES.md) H28 calls it a deliberate restriction until R-0499's checker on Core. Options: (a) state the restriction as a rule (a projection's base is a place: a binding, its fields and elements, or `*` of a named reference); (b) accept such projections of owned values and Copy reads once the checker traces them, refusing only what REF-5 refuses. Austral: not checked. Pick: none given (raised by the absorption of docs/verification, 2026-10-30). | see OPEN-121 | see OPEN-121 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): State the restriction as a rule |
| OD122 | <a id="od122"></a>A `repr(C)` struct returned from an extern function (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Whether a `#[repr(C)]` struct returned from an `extern fn` is returned as the platform's C calling convention returns it, at every size. Bears on FFI-2, FFI-11. The current compiler: a returned struct of at most 8 bytes comes back as one 64-bit integer, stored as 8 bytes into the struct's slot even when the struct is smaller (a 4-byte `in_addr` returned by `inet_makeaddr` reads back wrong natively); a larger one is returned as an LLVM aggregate, which matches C on x86-64 and AArch64 only for some layouts. [ABI.md](../legacy/docs/platform/ABI.md) promised returns of at most 8 bytes and listed larger ones as not promised. Options: (a) every size, as C, classified by the `Layout` authority (R-0502); (b) at most 8 bytes (or 16), a larger return refused in an `extern fn` signature; (c) none, a returned struct going through an out-pointer the binding declares. Austral: not checked. Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-122 | see OPEN-122 | decided 2026-11-01 by the owner (final set): Every size per C ABI via `Layout` |
| OD123 | <a id="od123"></a>`as` on a newtype outside its module (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Whether `v as N` and `n as T`, between a newtype `N` and its inner type `T`, are accepted outside the module that declares `N`, where TYPE-11 refuses `N(v)`. Bears on TYPE-11, TYPE-24, ARITH-5, OPEN-54. The current compiler: both accepted in any module, so `x as Id` builds a foreign newtype that `Id(x)` may not (E0296), and a validated wrapper's smart constructor can be bypassed. [VALIDATED_WRAPPERS.md](../legacy/docs/stdlib/VALIDATED_WRAPPERS.md) §8 describes the cast rule as guarding the wrapper contract from an `as` bypass, which holds for casts to unrelated types only. Options: (a) accepted anywhere, as in the current compiler; (b) accepted only where `N(v)` and `.0` are (TYPE-11, with R-0500's follow-on for `.0`); (c) `as` never names a newtype, the conversions being `N(v)` and `.0`. Austral: no newtype (OPEN-54's comparison). Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-123 | see OPEN-123 | decided 2026-11-01 by the owner (final set): `as` never names a newtype |
| OD124 | <a id="od124"></a>Profiles in the specification (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Whether the profiles (the admission profiles Safe, Predictable and Proof, and the build profiles) belong to the language specification, in a chapter of their own, and whether a profile may change what an accepted program does. Bears on ARITH-9, OPEN-97, PASS-3, PASS-4. The current compiler: a profile only refuses or reports: `--check predictable` reports its five gates (no recursion, bounded loops, no allocation, no extern calls, no `File`, `Network` or `Process`), `[policy] predictable = true` in `Concrete.toml` turns a violation into E0610, and no profile changes the behaviour of a program it accepts; ARITH-9 states that for arithmetic. [PROFILES.md](../legacy/docs/platform/PROFILES.md) says a profile never changes what a program means, while OPEN-97 asks whether a build profile may omit a run-time check. Options: (a) no profiles chapter: profiles are tooling, and the spec states only that no profile changes an accepted program's behaviour; (b) a profiles chapter whose entries state each profile's admission rules as refusals, with that same guarantee; (c) as (b), with build profiles allowed to differ as OPEN-97 decides. Austral: not checked. Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-124 | see OPEN-124 | decided 2026-11-01 by the owner (final set): Profiles chapter of refusals; no behaviour change |
| OD125 | <a id="od125"></a>Contracts at run time (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Whether a `#[requires]`, `#[ensures]` or loop `#[invariant]` that no proof discharges is checked at run time, trapping when it fails, or is only a claim. Bears on CON-1, CON-2, STMT-2. The current compiler: contracts are erased metadata: a call that violates `#[requires(x > 0)]` runs normally, in the binary and in `--interp`, and `assert` elaborates to proof evidence only (syntax chapter introduction). [ERROR_CONVENTIONS.md](../legacy/docs/stdlib/ERROR_CONVENTIONS.md) lists contract-violation traps among the fatal failures. Options: (a) claims only, never checked at run time, as in the current compiler; (b) checked at run time and trapping unless discharged; (c) checked under a build profile only (OPEN-97, OPEN-124). Austral: not checked. Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-125 | see OPEN-125 | decided 2026-11-01 by the owner (final set): Claims only **Qualified 2026-11-06 by [no hidden traps](#decided-project-no-hidden-traps): a claim used for safety admission needs closed evidence.** |
| OD126 | <a id="od126"></a>Target assumptions (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Which target facts are language rules: 64-bit pointers, little-endian byte order, POSIX hosts, and the sizes of `bool`, `Unit` and pointers. Bears on FFI-2, FFI-7, TYPE-19, TYPE-20. The current compiler: one target profile: `Layout` hardcodes 8-byte pointers and references, `bool` of 1 byte, `Unit` of 0 bytes, an `i32` enum tag, and assumes little-endian POSIX hosts; FFI-2 names AAPCS64 for the native profile, and the integer types' widths follow from their names (TYPE-19). [EXECUTION_MODEL.md](../legacy/docs/platform/EXECUTION_MODEL.md) and [ABI.md](../legacy/docs/platform/ABI.md) state these as platform facts. Options: (a) language rules, a 32-bit or big-endian target being another language profile; (b) target facts, observable only through `sizeof`, `alignof` (FFI-7) and named target constants; (c) as (b), with the sizes of `bool` and `Unit` fixed by the language. Austral: not checked. Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-126 | see OPEN-126 | decided 2026-11-01 by the owner (final set): Language rules; other targets are other profiles. Generalized 2026-11-08 by the [foundation decision](#foundation-q3): profiles are read-only and separate address width, pointer representation, length width, byte order and address spaces; the existing 64-bit little-endian profile and its `i32` enum tags are unchanged |
| OD127 | <a id="od127"></a>UTF-8 in every `String` (added 2026-10-30, raised while absorbing the platform and stdlib documents). Question: Whether every `String` value that safe code can reach holds valid UTF-8, as a language guarantee. Bears on TYPE-3, SYN-5, TRUST-2. The current compiler: literals are UTF-8 (SYN-5), but nothing keeps a `String` valid: `push_char` appends a byte unchecked, `Bytes::to_string` transfers bytes without validation, and std's `read_to_string` does not validate. [STRING_TEXT_CONTRACT.md](../legacy/docs/stdlib/STRING_TEXT_CONTRACT.md) §1 states the invariant as a target, and [UNICODE_POLICY.md](../legacy/docs/stdlib/UNICODE_POLICY.md) has a validating `Bytes::to_string` returning `Option`. Options: (a) a language guarantee, every safe constructor validating and an unchecked one being a trusted operation with that premise; (b) a std convention only, `String` being bytes to the language. Austral: not checked. Pick: none given (raised by the absorption of docs/platform and docs/stdlib, 2026-10-30). | see OPEN-127 | see OPEN-127 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Language guarantee |
| OD128 | <a id="od128"></a>`->` between a match arm's pattern and body (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether a match arm may separate its pattern from its body with `->` as well as `=>`. Bears on SYN-1 and PAT-7. The current compiler: the parser accepts both (`parseMatchArms`; `2 -> { return 42; }` exits 42 on both consumers), and the grammar's `match_arm` has only `=>`. The syntax freeze review (2026-04, [SYNTAX_FREEZE_REVIEW.md](../legacy/docs/archive/design-records/SYNTAX_FREEZE_REVIEW.md) §1.5) recommended `=>` as the canonical form with a warning for `->`, which also spells a return type. Options: (a) `=>` only, `->` refused; (b) both accepted; (c) both accepted, with a warning on `->`, as the freeze review recommended. Austral: not applicable. Pick: none given (raised by the absorption of docs/compiler, 2026-10-30). | see OPEN-128 | see OPEN-128 | decided 2026-11-01 by the owner (final set): `=>` only |
| OD129 | <a id="od129"></a>Type arguments of an enum literal taken from its expected type (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether an enum literal or variant written without type arguments (`Option::Some { value: 42 }`, `Option::None`) takes them from the type its position expects, and from which positions. Bears on TYPE-7, TYPE-15 and OPEN-46, which asks the same of a generic call's type arguments and whose pick excludes the expected result type. The current compiler: the type arguments come from the expected type of a `return` (the function's result type), of an annotated `let` and of a call argument (the parameter's type); all three exit 42 on both consumers, and spec examples rely on it (PAT-1). The syntax freeze review (§1.3, kill-list items 1, 4 and 5) proposed this inference for enum literals and for constructor calls such as `Vec::new()`. Options: (a) explicit type arguments always; (b) from the expected type in the positions the current compiler uses; (c) the answer to OPEN-46, applied to enum literals. Austral: type parameters are inferred from the arguments, and a declaration's type can disambiguate. Pick: none given (raised by the absorption of docs/compiler, 2026-10-30). | see OPEN-129 | see OPEN-129 | decided 2026-11-01 by the owner (final set): Same rule as OD46: type arguments from the arguments, otherwise explicit (`None::<i32>`) |
| OD130 | <a id="od130"></a>Unlabeled pattern binders: by position or by name (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether an unlabeled binder in a struct or variant pattern (`E::V { y, x }`) binds the field of its own name or the field at its position. Bears on PAT-1, PAT-3 and PAT-10. The current compiler disagrees with itself: with `enum E { V { x: Int, y: Int } }` and `E::V { x: 40, y: 2 }`, the arm `E::V { y, x } => y` gives 40 in `match` and in `if let` (binders zip the variant's fields in declaration order, `Concrete/Elab/Elab.lean` `bindings.zip ev.fields`), while the struct destructuring `let S { y, x } = s; y` gives 2 (by name); both consumers agree. PAT-1's `field: binder` form and the grammar's `binding_list` comment ("positional") point different ways. Options: (a) by name (field punning) everywhere; (b) by position everywhere; (c) refuse an unlabeled list whose order differs from the declaration. Austral: not applicable (no punning). Pick: none given (raised by the absorption of docs/compiler, 2026-10-30; the variant-pattern disagreement may also be filed as a bug). | see OPEN-130 | see OPEN-130 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): By name everywhere |
| OD131 | <a id="od131"></a>`union` declarations (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether the language has `union` declarations, and if so what reading a field other than the one last written means. Bears on SYN-1, TYPE-7, FFI-7 and FFI-8. The current compiler: `union U { a: Int, b: Uint }` parses (`Concrete/Frontend/Parser.lean`, as a struct whose fields share storage) and compiles; a value built as `U { a: 42 }` is linear, and `union` is neither a keyword nor in the grammar. No document specifies it. Options: (a) remove it; (b) keep it, for the foreign boundary only, with its layout and read rules specified. Austral: no unions. Pick: none given (raised by the absorption of docs/compiler, 2026-10-30). | see OPEN-131 | see OPEN-131 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD132 | <a id="od132"></a>Polymorphic recursion (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether a generic function that calls itself at a strictly larger type argument (`f::<Box<T>>` inside `f<T>`) is refused, and by which check. Bears on TYPE-13, PASS-7 and PASS-12. The current compiler: such a program is not refused; compilation does not terminate (more than 200 s and 2 GB on 2026-10-30, natively and with `--interp`), since monomorphization specializes without a bound on function instances (the bound `closeInstances` has covers only generic type definitions). [PASSES.md](../legacy/docs/compiler/PASSES.md) §7 lists unbounded polymorphic recursion as Mono's error. Options: (a) refuse a call cycle whose type arguments grow, before Mono; (b) refuse at Mono when specialization exceeds a stated limit. Austral: not checked. Pick: none given (raised by the absorption of docs/compiler, 2026-10-30; the non-termination may also be filed as a bug). | see OPEN-132 | see OPEN-132 | decided 2026-11-01 by the owner (final set): Refuse growing call cycles before Mono |
| OD133 | <a id="od133"></a>User functions named `print`, `println` or `append` (added 2026-10-30, raised while absorbing the compiler documents and the grammar comments). Question: Whether a program may declare a function named `print`, `println` or `append`, which then replaces the builtin of that name in calls the program writes. Bears on MOD-3, MOD-8 and TYPE-10. The current compiler: accepted; with `fn print(x: Int) -> Int`, `print(42)` calls it (exit 42 on both consumers), because Elab desugars the variadic builtins only when no function of that name is visible, and MOD-3's reserved names do not include them. MOD-8 already binds the calls the compiler itself generates by identity. Options: (a) reserve the three names (MOD-3); (b) allow the replacement, as the current compiler does. Austral: not applicable. Pick: none given (raised by the absorption of docs/compiler, 2026-10-30). | see OPEN-133 | see OPEN-133 | decided 2026-11-01 by the owner (final set): Reserve the three names |
| OD134 | <a id="od134"></a>The capabilities of a container's generated destruction (added 2026-10-30, raised while reviewing the absorption of docs/stdlib). Question: Whether the destruction a generic container generates for its elements may require the capabilities of those elements' `Destroy` implementations beyond `Alloc`, or every `Destroy` implementation stays limited to `Alloc`. Bears on OWN-13, TYPE-D1 and TRUST-4. The current compiler: OWN-13 is enforced, so a `Destroy` implementation requires no capability beyond `Alloc`, and a container's generated destruction is `with(Alloc)`. [RUNTIME_COLLECTIONS.md](../legacy/docs/stdlib/RUNTIME_COLLECTIONS.md) rule 3 describes a different model, in which the generated destruction requires the union of its element, key and value destructors' capabilities, computed per instantiation, and calls today's limit a first-release restriction. Options: (a) keep OWN-13's limit, so destruction never needs more than `Alloc`; (b) lift it, so a `Destroy` implementation may require further capabilities and a container's destruction requires their union per instantiation. Austral: not assessed. Pick: none given (raised by the review of the absorption of docs/stdlib, 2026-10-30). | see OPEN-134 | see OPEN-134 | decided 2026-11-01 by the owner (final set): Keep `Alloc` limit |
| OD135 | <a id="od135"></a>A method's `Type_method` name in its module's namespace (added 2026-10-30, raised while reviewing the absorption of docs/compiler and docs/platform). Question: Whether an impl method `m` of a type `T` also occupies the name `T_m` in its module, so that a free function of that name is refused. Bears on MOD-3 and MOD-8. The current compiler: refused: `fn P_get(a: Int) -> Int` beside `impl P { fn get(&self) -> Int }` is E0299 under MOD-3@2 ("a function named 'P_get' is also declared in this module as an impl method"), on both consumers, because the method is entered under its mangled name. MOD-3's reserved names are the `__` prefix, `user_main` and the builtins, which do not include such names. Options: (a) keep it, listing `T_m` among the names MOD-3 reserves; (b) stop entering methods under `T_m`, so the free function is accepted. Austral: not applicable (no methods). Pick: none given (raised by the review of the absorption of docs/compiler, 2026-10-30). | see OPEN-135 | see OPEN-135 | decided 2026-11-01 by the owner (final set): Stop entering methods under `T_m` |
| OD136 | <a id="od136"></a>std's `process_exit` (added 2026-10-30, raised while reviewing the absorption of docs/compiler and docs/platform). Question: Whether std keeps `process_exit`, which ends the process through libc `exit` without running any deferred call or consuming the caller's owned values. Bears on STMT-7, OWN-2 and TRUST-4. The current compiler: `std.process.process_exit(code: i32) with(Process)` exists and calls libc `exit`; the language itself has no exit operation (STMT-7). The design record [MAIN_EXIT_MODEL.md](../legacy/docs/platform/MAIN_EXIT_MODEL.md) calls an exit operation deliberately absent, since in a linear language it would bypass the proof that every owned value is consumed. Options: (a) keep it, stating that it skips cleanup and that `Process` is what grants it; (b) remove it, status flowing back through `main`'s return only. Austral: not checked. Pick: none given (raised by the review of the absorption of docs/platform, 2026-10-30). | see OPEN-136 | see OPEN-136 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Remove |
| OD137 | <a id="od137"></a>Character literals outside ASCII (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Which byte a char literal denotes when its character is not ASCII. Bears on SYN-6, TYPE-20 and SYN-5. The current compiler: the literal silently takes the low byte of the character's code point: `'é'` (U+00E9) is 233, `'ā'` (U+0101) is 1 and `'€'` (U+20AC) is 172 as `u8`, on both consumers, and SYN-6 says only that a char literal is a token. Options: (a) refuse a char literal whose character is not ASCII, so every accepted literal is the one byte of its ASCII character; (b) accept U+0000 to U+00FF as that byte (Latin-1) and refuse anything above; (c) make `char` a Unicode scalar value, which changes TYPE-20's one-byte `char`. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-137 | see OPEN-137 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse non-ASCII |
| OD138 | <a id="od138"></a>Which positions give a literal its expected type (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Which positions give an integer literal operand its expected type under ARITH-2@3 (and a float literal's, should OPEN-63 give floats the same rule). Bears on ARITH-2, TYPE-4 and TYPE-6. The current compiler: an unconstrained integer literal is typed `Int` and a float literal `Float64` (bug 327); with `x: u8`, a literal beside `x` takes `u8` as the other operand of `+`, `<` and `&` and as the count of `>>`: `x + 300`, `x < 300`, `x & 300` and `x >> 300` are each refused natively with E0227 (`integer literal 300 is out of range for type 'u8'`), and `300 as Int` is accepted, whether through `as` or the `Int` default the probe does not show. ARITH-2@3 refuses an integer literal with no expected type but does not list the positions that supply one. Options: (a) declared positions (an annotated binding, a parameter, a return, a field) and the other operand of a binary operator, as the probe shows the current compiler doing for `+`, `<`, `&` and a shift count (other operators were not probed); (b) declared positions only, so a literal beside a typed operand needs a typed binding; (c) option (a), plus the target type of an `as` for its literal operand. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-138 | see OPEN-138 | decided 2026-11-01 by the owner (final set): Declared positions + other operand of a binary op |
| OD139 | <a id="od139"></a>A qualified call to a function that is not imported (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether `a::f()` may call a `pub` function of another module that the caller has not imported. Bears on MOD-2, SYN-10 and MOD-4. The current compiler: accepted: `mod a { pub fn answer() -> u8 { return 42; } }` and `a::answer()` in `main` exits 42 with no import, as MOD-4's and SYN-10's accepted examples also do, while MOD-2's sentence says another module uses a declaration only by importing it. Options: (a) a qualified path to a `pub` declaration is a use in its own right, and MOD-2 says so; (b) an import is required, and the unimported qualified call is refused. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-139 | see OPEN-139 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Import required |
| OD140 | <a id="od140"></a>Implicitly dropped results of `free` and of a deferred call (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether the result of `free(h)` (the pointee, of type `T`) when `T` is Copy, and a deferred call's Copy result, may be dropped without `discard`, as exceptions to OWN-7@3 (OD29). Bears on OWN-7, OWN-17, MEM-5 and OWN-15. The current compiler: both accepted: `free(h);` on a `Heap<Int>` (whose result is the `Int` moved out of the cell: `let v: Int = free(h);` after `alloc(42)` gives 42 on both consumers) and `defer f();` with `fn f() -> u8` compile and run, while OWN-7@3 (decided OD29) drops a non-Unit result only through `discard(e)`. OWN-17 states the current compiler's drop of a deferred call's result, and MEM-5 and OWN-15 describe `free(h);` as a statement; neither is named as an exception in OWN-7. Options: (a) both are exceptions, stated in OWN-7; (b) neither is, so each needs `discard`; (c) `free` is an exception and a deferred call's result is not. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-140 | see OPEN-140 | decided 2026-11-01 by the owner (final set): Neither; each needs `discard`. Earlier clarification of 2026-11-02: `free` no longer exists (OD59); a deferred call's Copy result is dropped with `discard`, while a `Result` or `Option` cannot be discarded (OD62) and is handled by a named function that returns `Unit` ([decisions](decisions.md#decided-2026-11-02-authority)). Revised 2026-11-02: `defer` takes a call whose result is `Unit` ([decisions](decisions.md#decided-2026-11-02-audit)) **Canonical current deferred-result rule: the Unit-only audit rule below; the earlier discard-inside-defer fragment is superseded, and authority rule 9 refers to the Unit-only rule.** |
| OD141 | <a id="od141"></a>More than one `main` in a program (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Which function is the entry point when more than one module of a program declares `main`. Bears on STMT-7, MOD-3 and PASS-10. The current compiler: `mod a { pub fn main() -> u8 { return 7; } }` beside `mod b { pub fn main() -> u8 { return 9; } }` fails natively inside LLVM (`redefinition of global '@__concrete_argc'`) and prints 7 under `--interp`, which runs the first, also when the second `main` is the root module's; MOD-3 makes a name unique within one module only. Options: (a) only the root module's `main` is the entry point, and others are ordinary functions; (b) a program with more than one `main` is refused; (c) a `main` outside the root module is refused. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-141 | see OPEN-141 | decided 2026-11-01 by the owner (final set): A `main` outside the root module is refused |
| OD142 | <a id="od142"></a>`X.con` beside `X/mod.con` (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Which file `mod X;` loads when both `X.con` and `X/mod.con` exist. Bears on MOD-4. The current compiler: `X.con` is loaded and `X/mod.con` is ignored without a diagnostic (with `X.con` returning 7 and `X/mod.con` 9, the program exits 7 on both consumers). MOD-4 says one module is loaded from either file. Options: (a) refuse the pair; (b) `X.con` takes precedence, as the current compiler does; (c) `X/mod.con` takes precedence. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-142 | see OPEN-142 | decided 2026-11-01 by the owner (final set): One module layout: `X.con`, children in directory `X/`; no `mod.con` |
| OD143 | <a id="od143"></a>What a contract may read (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Which names each contract position (`requires`, `ensures`, `invariant`, `variant`) may read. Bears on CON-2, CON-3 and CON-4. The current compiler: CON-3 says a contract reads parameters and `result`, CON-4 lets contracts read `ghost let` bindings, and CON-2's accepted loop invariant reads the local `i`; the checker accepts all three. Options: (a) per position: `requires` the parameters, `ensures` the parameters, `result` and ghost bindings, and a loop's `invariant` and `variant` every binding in scope, with CON-3 amended; (b) every position reads every binding in scope at that point; (c) CON-3 as written, with loop contracts and ghost reads refused. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-143 | see OPEN-143 | decided 2026-11-01 by the owner (final set): A contract reads exactly the names in scope at its position, plus `result` in `ensures` |
| OD144 | <a id="od144"></a>Postconditions and deferred calls (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether an `ensures` clause is about the state before or after the function's deferred calls run. Bears on CON-2 and STMT-11. The current compiler: `#[ensures(result == *r)]` on a function whose `defer inc(r)` runs after the result is computed is accepted and runs (contracts are erased at run time); the probe does not show which state the postcondition's proof obligation reads, no rule says, and STMT-11 computes the result before the deferred calls run. Options: (a) after every deferred call, the state the caller sees; (b) when the result is computed, before deferred calls; (c) refuse an `ensures` in a function with a deferred call that may write what the clause reads. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-144 | see OPEN-144 | decided 2026-11-01 by the owner (final set): After every deferred call |
| OD145 | <a id="od145"></a>How a contract names machine arithmetic (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: How a contract expression names machine arithmetic, which CON-3 allows in place of its default mathematical arithmetic. Bears on CON-3 and ARITH-4. The current compiler: `#[ensures(result == wrapping_add(x, 1))]` is accepted and the program runs (contracts are erased at run time); what the proof pipeline makes of the named operation was not probed. CON-3 says a contract's integer arithmetic is mathematical unless it names a machine operation, and no rule or example names one. Options: (a) the named operations of ARITH-4 (`wrapping_add`, `saturating_add` and the rest) are the machine operations in a contract; (b) a contract-only spelling; (c) contracts have only mathematical arithmetic, and CON-3 drops the exception. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-145 | see OPEN-145 | decided 2026-11-01 by the owner (final set): ARITH-4 named operations |
| OD146 | <a id="od146"></a>The result type of a test function (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether a `#[test]` function returns `i32` (STMT-10) or follows `main`'s decided `u8` or `Unit` (OD24). Bears on STMT-10 and STMT-7. The current compiler: `#[test] fn t() -> Int` is refused with E0319 (`#[test] function 't' must return i32`), and a test's result is its exit status under `concrete test`. Options: (a) keep `i32`; (b) `u8` or `Unit`, as `main` (STMT-7@3); (c) `Unit` only, a failing test aborting. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-146 | see OPEN-146 | decided 2026-11-01 by the owner (final set): `u8` or `Unit`, as `main`. Revised 2026-11-02: `u8` only, as `main` ([decisions](decisions.md#decided-2026-11-02-main)) |
| OD147 | <a id="od147"></a>`repr(C, packed)` together (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether `#[repr(C, packed)]` is accepted, and what layout it gives. Bears on FFI-4 and FFI-8. The current compiler: accepted: `#[repr(C, packed)] struct Copy P { a: u8, b: u32 }` has size 5, so packing overrides C alignment. FFI-4 refuses only `packed` with `align(N)`, and FFI-8 states C layout and packed layout separately. Options: (a) refuse the combination; (b) accept it as C field order with no padding and alignment 1, as the current compiler does, and FFI-8 says so. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-147 | see OPEN-147 | decided 2026-11-01 by the owner (final set): Accept: C order, no padding, align 1, stated in FFI-8 |
| OD148 | <a id="od148"></a>Type parameters on a trait (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether a trait declaration may have type parameters, and if so what binds them at a bound and an impl. Bears on TRAIT-1, TRAIT-9 and SYN-1. The current compiler: `trait Tr<T> { fn get(&self, x: T) -> T; }` parses, but no bound or impl head can supply `T`, so `impl Tr for S { fn get(&self, x: u8) -> u8 ... }` is refused with E0582 and E0587 (`expected return type T, got u8`). OPEN-77 lists generic trait methods among the grammar's stale items; it covers only the productions, while this entry covers what the parameters mean and what binds them. Options: (a) refuse type parameters on a trait declaration; (b) allow them, with type arguments at bounds and impl heads (`impl Tr<u8> for S`). Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-148 | see OPEN-148 | decided 2026-10-31 by the owner's rule (every reviewer agreed, as strict as Austral or stricter): Refuse type parameters on a trait |
| OD149 | <a id="od149"></a>How `[e; N]` evaluates `e` (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: How many times an array repetition `[e; N]` evaluates `e`, and which `e` it accepts. Bears on STMT-4, OWN-15 and TYPE-7. The current compiler: `e` is evaluated once per element, in index order (`[bump(&mut n); 3]` gives `[1, 2, 3]` on both consumers), and whether a linear `e` is accepted was not shown (an array of a linear type that is never consumed is refused with E0208 either way). OWN-15 says only that an array literal moves each element in, and STMT-4 orders written elements. Options: (a) `e` is evaluated once and copied, so it must be Copy; (b) `e` is evaluated `N` times in index order, as the current compiler does; (c) `e` must be a constant expression. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-149 | see OPEN-149 | decided 2026-11-01 by the owner (final set): Evaluated once, must be Copy |
| OD150 | <a id="od150"></a>Which text governs the grammar until it is resynchronized (added 2026-10-30, raised by the spec quality audit of 2026-10-30). Question: Whether, until OPEN-77's resynchronization, `grammar/concrete.ebnf` or the rule entries govern where they disagree. Bears on SYN-1 and OPEN-77. The current compiler: the parser accepts forms the EBNF does not derive (`import a.{f};`, `m::f()`, `f::<T>(x)`, value `if` and `match`, `pub` fields, bodyless declarations) and the EBNF keeps forms the entries removed (`E#V`, the C-style `for`, `break <expr>`); SYN-1 calls the EBNF the grammar, and the LL(1) checkers read it. Options: (a) the rule entries govern, and the EBNF is descriptive until the resync; (b) the EBNF governs, and an entry that disagrees is pending; (c) neither: each disagreement is decided one by one under OPEN-77. Austral: not checked. Pick: none given (raised by the spec quality audit, 2026-10-30). | see OPEN-150 | see OPEN-150 | decided 2026-11-01 by the owner (final set): Rule entries govern |
| OD151 | <a id="od151"></a>Module paths of more than one level (added 2026-10-31, raised while absorbing SYNTAX_FREEZE_REVIEW §1.1). Question: Whether a qualified path may name a member of a module nested more than one level deep (`a::b::f()`). Bears on SYN-10, MOD-4 and OPEN-139. The current compiler: the parser's lowercase module-path branch accepts one qualification pair: `a::b::f()`, with `f` in `mod b` inside `mod a`, is a parse error on both consumers (E0001, `expected <, got ident(f)`), because after `a::b` it accepts only `::<` (explicit type arguments). SYNTAX_FREEZE_REVIEW §1.1 gives `std::fs::read_to_string` as an example of module qualification, which this parser does not accept. Options: (a) one qualification pair, as in the current compiler, and SYN-10 says so; (b) any depth, every segment before the last naming a module (a repetition, which stays LL(1)). Austral: not checked. Pick: none given (raised while absorbing SYNTAX_FREEZE_REVIEW §1.1, 2026-10-31). | see OPEN-151 | see OPEN-151 | decided 2026-11-01 by the owner (final set): Allow multi-level module paths `a::b::f` |
| OD152 | <a id="od152"></a>Whether a path's first letter decides its syntactic form (added 2026-10-31, raised while absorbing SYNTAX_FREEZE_REVIEW §1.1). Question: Whether the first letter of a path's first segment decides the syntactic form of `X::y`, or one path form leaves to name resolution whether `X` is a type or a module. Bears on SYN-10, SYN-1 and MOD-1. The current compiler: the parser chooses by the first letter of `X`: an uppercase `X` gives an associated-function call or an enum literal, and a lowercase `X` the flattened name `X_y`, which name resolution looks up as one identifier (bug 343); a module named with an uppercase letter goes through the associated-function form, and `M::f()` on `mod M` builds and runs on both consumers. SYNTAX_FREEZE_REVIEW §1.1 presents the case split as how the parse stays LL(1). Options: (a) the first letter decides the syntactic form, as in the current compiler, and SYN-10 states it; (b) the parser reads `X::y` as one path form, which is also LL(1), and name resolution decides whether `X` is a type or a module. Austral: not checked. Pick: none given (raised while absorbing SYNTAX_FREEZE_REVIEW §1.1, 2026-10-31). | see OPEN-152 | see OPEN-152 | decided 2026-11-01 by the owner (final set): Resolve `X::y` by declaration, not by the first letter |
| OD153 | <a id="od153"></a>Program functions named like a builtin (added 2026-10-31, raised while reviewing the builtins catalog of spec readability 2). Question: Whether a program may declare a function whose name is a builtin's, other than `print`, `println` and `append` (OPEN-133) and the names MOD-3 reserves, and which function the program's calls of that name reach. Bears on MOD-3, MOD-1, MOD-8 and OPEN-133. The current compiler: a program function `string_length` is called by the program's calls on both consumers, and so are program functions named `string_len` and `String_len` (`string_len` returns 7 and `String_len` returns 9; a program that calls both exits 79 on both consumers), while `destroy`, `discard`, `abort`, `alloc`, `free`, `alloc_array`, `free_array` and `realloc_array` are reserved (E0578). The calls the compiler itself generates are bound by identity (MOD-8), so only the program's own calls change. Options: (a) reserve every remaining builtin's name, aliases included, and MOD-3 lists them (`print`, `println` and `append` stay with OPEN-133); (b) allow the declaration, and the program's own calls reach it, as the current compiler does, and MOD-3 says so; (c) allow the declaration, and a program reaches the builtin by a qualified name. Austral: not checked. Pick: none given (raised while reviewing the builtins catalog of spec readability 2, 2026-10-31). | see OPEN-153 | see OPEN-153 | decided 2026-11-01 by the owner (final set): Refuse program functions named like builtins |
| OD154 | <a id="od154"></a>Whether the string builtins require `Alloc` (added 2026-10-31, raised while reviewing the builtins catalog of spec readability 2). Question: Whether `string_concat`, `string_slice`, `string_substr`, `string_trim`, `int_to_string`, `bool_to_string`, `float_to_string`, `string_push_char`, `string_append`, `string_append_int` and `string_append_bool` require the `Alloc` capability. Bears on MEM-7, TRUST-4 and OPEN-133. The current compiler: Check gives none of these builtins a capability, and a function with no capabilities calls `string_concat` and `string_append_int` and exits 42 on both consumers (the other names were not probed). MEM-7@1 lists `string_reserve` and `append` among the builtins that require `Alloc`; `append` is accepted without `Alloc` (bug 349), and it expands into `string_append`, `string_append_int`, `string_append_bool` and `string_push_char`. MEM-7's rationale says allocation is an effect a signature shows. Options: (a) each builtin named above requires `Alloc`, and MEM-7 lists it; (b) a stated subset of them requires `Alloc`, and MEM-7 lists that subset; (c) only the builtins MEM-7 already lists require `Alloc`, so `string_reserve` and `append` do and the names above do not, and MEM-7 says so; (d) no string builtin requires `Alloc`, `string_reserve` and `append` included, and MEM-7 drops those two. Austral: not checked. Pick: none given (raised while reviewing the builtins catalog of spec readability 2, 2026-10-31). | see OPEN-154 | see OPEN-154 | decided 2026-11-01 by the owner (final set): Allocating string builtins need `Alloc` (MEM-7; closes bug 349) |
| OD155 | <a id="od155"></a>`unwrap` beside TYPE-24's conversions (added 2026-10-31, raised while reviewing the builtins catalog of spec readability 2). Question: Whether `unwrap` stays an intrinsic beside the conversions TYPE-24 lists (`n.0` and `n as T`), becomes one of those conversions, or is removed. Bears on TYPE-24, TYPE-11, TYPE-10 and OPEN-54. The current compiler: Check gives `unwrap(m)` the newtype's inner type (E0270 when the argument is not a newtype); `return unwrap(m);` exits 42 on both consumers, and `let x: Int = unwrap(m);` followed by `if x == 42` fails the native build at SSA verification (E0715, bug 345). TYPE-24 lists `n.0` and `n as T` and does not list `unwrap`. OPEN-54 decides this only if its answer removes newtypes; while newtypes stay, this question stays. Options: (a) keep `unwrap` as an intrinsic and leave it off TYPE-24's list, as the current compiler and TYPE-24 do; (b) `unwrap(n)` is a conversion, TYPE-24 lists it, and TYPE-11 restricts it as it restricts `n.0`; (c) remove `unwrap`, leaving `n.0` and `n as T`. Austral: not checked. Pick: none given (raised while reviewing the builtins catalog of spec readability 2, 2026-10-31). | see OPEN-155 | see OPEN-155 | decided 2026-11-01 by the owner (final set): No builtin `unwrap`; use `match` |
| OD156 | <a id="od156"></a>The capability of `get_args` (added 2026-10-31, raised while reviewing the builtins catalog of spec readability 2). Question: Which capability the builtin `get_args` requires, or whether the builtin is removed. Bears on TRUST-4, STMT-7, TRUST-9 and OPEN-136. The current compiler: Check gives `get_args()` the result `HeapArray<String>` and requires `Process` (E0520 with `Env` only); the builtin has no implementation on either consumer (bug 347). STMT-7's rationale says command-line arguments come from `std.args` with `Env`, and OD8 gives `main` the root resource value (TRUST-9). Options: (a) `Env`, as `std.args` requires; (b) `Process`, as the current compiler's signature says; (c) another capability, or none; (d) remove the builtin, and command-line arguments come from `std.args`. Austral: not checked. Pick: none given (raised while reviewing the builtins catalog of spec readability 2, 2026-10-31). | see OPEN-156 | see OPEN-156 | decided 2026-11-01 by the owner (final set): Superseded by the authority decision of 2026-11-01: `get_args` requires `with(Env)`, and `with(Alloc)` when it allocates. Revised 2026-11-02 by the owner's rule: it also takes the `Environment` grant, and an allocator when it allocates ([decisions](decisions.md#decided-2026-11-02-filesystem)) |
| OD157 | <a id="od157"></a>How the type `Unit` is written (added 2026-10-31, raised while reviewing the builtins catalog of spec readability 2). Question: Whether the type `Unit`, which STMT-7 names as a result type of `main` and which other rules and the builtins catalog also name, has a spelling in type positions, and which spelling. Bears on STMT-7, TYPE-4, SYN-1 and OPEN-66. The current compiler: a function with no result type returns no value, and `fn main() { return; }` exits 0; `fn main() -> Unit` and `let x: Unit = f();` are refused at resolve (E0108, unknown type 'Unit'); `fn main() -> ()` is a parse error (E0001, `expected type`). STMT-7@3 says `main`'s result type is `u8` or `Unit`. OPEN-66 concerns the unit value's literal; this entry concerns the type in type positions, and the two cross-reference each other. Options: (a) no spelling: the type is written only by omitting the result type, and STMT-7 says so; (b) `Unit` is a builtin type name, accepted wherever a type is; (c) `()` is the type's spelling; (d) both `Unit` and `()` are accepted. Austral: not checked. Pick: none given (raised while reviewing the builtins catalog of spec readability 2, 2026-10-31). | see OPEN-157 | see OPEN-157 | decided 2026-11-01 by the owner (final set): The type is written `Unit`, its value `()` |


## Decided

These entries were retired when the owner answered them; their IDs are never reused.

- **The authority design** (decided 2026-11-01, after a Codex and Grok review that concluded "adopt
  with changes"; its rules confirmed and completed on 2026-11-02, see
  [the authority rules](#decided-2026-11-02-authority)). `with(...)` is the only permission
  mechanism; it is compile-time information, not a resource. Linear values are the only resource
  mechanism: `File`, `Socket`, `Heap<T, A>`, and the grants the target hands to `main`. The concept
  "token" is dropped. An operation needs both the resource value (which thing) and the permission
  (what is allowed); in the owner's words, "one is the parameter to modify, the other the permission",
  and this is not duplication. `Std` is removed as a capability: every signature, `main` included,
  lists its real capabilities; std, examples and tests are to migrate under exit 2q, with the compiler
  suggesting the exact set needed. It supersedes OD38's and OD156's readings through a `Root` value
  and OD83's allocator token. OD8 stands except where this supersedes it: its root value and
  its split (item 2) give way to the grants the target hands to `main`, and its "every effect shows as a
  token parameter, with no separate effect system" (item 3) gives way to `with(...)` plus resource
  values. Its "no life before `main`" (item 5) stands: the target's startup and shutdown only create
  the grants, run no user code and do nothing else a program could observe beyond what the target's
  table states.

<a id="decided-2026-11-02"></a>
**Decided 2026-11-02 by the owner's rule** (the owner: "anything where you and codex agree that is the
best decision, record the solution"; each answer below is the one Claude and Codex both judged the best
long-term answer, Codex having read the repository; the owner answered the first four directly on
2026-11-01):

- <a id="decided-2026-11-02-aliases"></a>**Type-name aliases** (after OD102): the aliases `Int`,
  `Uint`, `Float64` and `Bool` are removed. A builtin type has one spelling (`i64`, `u64`, `f64`,
  `bool`, ...). Owner's answer, 2026-11-01.
- <a id="decided-2026-11-02-main"></a>**`main`'s result** (revises OD24): `main` returns `u8`, and
  only `u8`. Owner's answer, 2026-11-01. A test function's result follows it (revises OD146): `u8`
  only.
- <a id="decided-2026-11-02-namespace"></a>**One namespace per module** (completes OD43): a type and a
  value (a function or constant) in one module may not share a name. A struct literal `S { ... }` and
  a variant path `E::V` name the type itself and are not collisions. Owner's answer, 2026-11-01.
- <a id="decided-2026-11-02-child"></a>**A child module's declarations** (completes OD43) are not
  visible in its parent by bare name: the parent writes `child::T` or imports it. Owner's answer,
  2026-11-01.

<a id="decided-2026-11-02-authority"></a>**The authority rules** (they replace the twelve rules approved
in summary on 2026-11-01):

1. **A value is not a permission, and a permission is not a value.** Holding a value never satisfies
   a `with` requirement, and holding a permission never supplies a required value.
2. **Every operation needs both a resource value and a permission.** There are no permission-only
   operations: the target's services are values too (an `Allocator<A>`, a `Directory`, an
   `Environment`, a `Clock`, network endpoint grants, devices), each selecting what the operation may
   reach.
3. **Capability variables range over sets** of capabilities, the empty set included. A generic body is
   checked parametrically; at each instantiation the exact sets are substituted into its types and
   requirements and the instantiation is rechecked. Inconsistent bindings are refused, never merged
   into a union. No set-bound syntax is added.
4. **Function-pointer types keep their exact capability set** (canonical current rule; OD93 refers here). No conversion changes it. A function
   that calls a callback declares the callback's set plus its own effects, and a context value adds no
   authority. Foreign function values stay refused (OD4); the permissions of foreign callbacks are
   decided when they are admitted.
5. **`trusted` and `with(Unsafe)` never discharge an operational capability** (`Fs`, `Network`, `Env`,
   `Time`, `Alloc`, `Device`, `Console`, `Process`; `Console` added by the [owner revision, 2026-11-05](#decided-2026-11-05-revisions), row Q7.11). Effect checking applies inside trusted bodies and at foreign
   calls; no capability can be hidden. What native code actually does is a named assumption of the
   theorem, never an exemption.
6. **There are no umbrella capabilities** (`Std`, `Io`, `Block`). Behavioural classes such as "may
   block" are a conservative table over the capabilities, which also covers allocation, destruction
   and foreign calls; unknown foreign behaviour counts as "may block". The table never claims that a
   particular call does not block.
7. **Primitive effects come from one exhaustive table** (externs, intrinsics, compiler-generated
   operations, runtime entry, startup and shutdown); compound effects follow checked composition. A
   declaration may never understate the effects of what it calls. A body uses only its declared
   permissions, and a call requires the callee's set to be included in the caller's (TRUST-4), across
   trait dispatch, generic methods and generated cleanup alike; one Lean judgment states this. The table includes the `Console` operations on the standard-stream
   grants (row Q7.11, [owner revision, 2026-11-05](#decided-2026-11-05-revisions)).
8. **Returned values never supply permissions.** A returned `File` or function value still carries its
   ownership and its effect requirements, but no permission.
9. **Cleanup returns what survives it.** Cleanup with effects is explicit (`close(f) with(Fs)`), and
   `Destroy` requires at most `Alloc`. On every returning path, a consuming operation releases its
   input or returns every ownership obligation that remains: a cleanup that can leave a resource live
   returns it in its error. `close` on a `File` consumes the handle in every outcome only through a
   platform adapter that guarantees the descriptor is released (POSIX alone does not); a handle whose
   number may have been reused is never handed back. `defer close(f)` is written with a named function
   that returns `Unit` and handles the error (OD62, OD140, referring to the canonical Unit-only audit rule below); there is no new syntax for errors of
   deferred calls.
10. **Ownership on failure and exit.** Error branches and early returns keep every linear obligation.
    Abort runs no cleanup and a trapping deferred call stops the sequence (OD68, OD69); these are the
    only exceptions.
11. **Resources are introduced only by checked acquisition or unforgeable constructors**, and each
    grant the target creates is minted once. Every extern, intrinsic and minting wrapper is listed in
    the trusted base, with its identity preserved through interfaces, specialization and linking.
    Who may introduce them is decided [below](#decided-2026-11-02-audit).
12. **`main` receives the target's grants and consumes them.** There is no `Root` type. The target
    declares the grants it offers (its allocator, directories, environment, clock, devices); `main`'s
    parameters and `with(...)` must be within them, checked at compile time. `main` consumes every
    grant explicitly before it returns; abort is the exception. Effects outside ordinary calls (the
    trap message, flushing output, startup, shutdown) come from the target's table and appear in the
    semantics and its traces; no source code gains a hidden `Console` or `Alloc`.
13. **Capability names are reserved and differ from resource type names**: `with(Fs)` against a
    `File` value. The reserved set is `Fs`, `Network`, `Env`, `Time`, `Alloc`, `Device`, `Console`, `Process` and
    `Unsafe` (meanings per OD95; `Console` is the permission for operations on the `StdIn`, `StdOut` and
    `StdErr` grants, added by the [owner revision, 2026-11-05](#decided-2026-11-05-revisions), row Q7.11; there is no `Net` spelling and no alias). They are reserved everywhere,
    including import aliases, capability parameters and other binders.
14. **What the theorem claims.** Effect containment, resource safety and information-flow security are
    separate claims with separate assumptions; none implies another. The trusted base is an explicit
    list of assumptions, and being listed proves nothing.

<a id="decided-2026-11-02-allocation"></a>**Allocation** (revises OD83, the former authority rule 10
of 2026-11-01 "one allocator form per target", and the terminal out-of-memory failure of STMT-2):

- **One allocation form on every target**: an allocator value plus `with(Alloc)`. A hosted target hands
  `main` the system allocator; a freestanding target hands it its arenas. There is no allocation by
  permission alone.
- **The common type is `Allocator<A>`**, whose parameter `A` is a fresh, unforgeable identity of one
  allocator domain (`Sys` for the system allocator); an arena is one kind of allocator.
- **Allocations carry their allocator's identity in their type**: `Heap<T, A>`, `Vec<T, A>`, `String<A>`.
  Each records how to release its storage (never a reference to the allocator), so `*h` and
  `destroy(h)` (OD59) need no allocator argument and `Destroy` still requires at most `Alloc`.
  Moving a value to another allocator allocates there explicitly.
- **An allocator can be given up only when nothing allocated from it is alive.** This dependency is a
  language rule that holds across function boundaries, generics, containers and callbacks, and it is
  not implemented by reference counting.
- **Allocation is fallible and conserves its input**:
  `alloc(a: &mut Allocator<A>, v: T) with(Alloc) -> Result<Heap<T, A>, AllocFailure<T>>` returns the
  value on failure. The failure value itself never allocates, and the allocator stays valid after a
  failure. A container whose growth fails is unchanged and returns the rejected element; a failed
  reserve keeps the original storage; an operation that allocates several times accounts for what it
  had already built; a consuming container operation returns the container when an obligation
  survives. Running out of memory is an ordinary error, not a terminal failure. Allocating string operations
  (OD154) take an allocator and report failure; static text needs no allocation.

<a id="decided-2026-11-02-filesystem"></a>**Filesystem, environment, time and network** (revises
the former authority rule 9 of 2026-11-01 on `get_args`, and OD156):

- **Every filesystem namespace operation takes a `Directory` value plus `with(Fs)`**: opening,
  creating, listing, probing, removing, renaming, linking and metadata lookup. Renaming and linking need
  the authority of both directories involved. A file that is opened owns its own handle, which borrows
  nothing from the directory; operations on an open file take that file. `main` receives the
  directories the target grants; a directory value can be narrowed (for example to read-only) and
  handed to a library alone.
- **A path stays inside its directory**, enforced during lookup: absolute paths, `..` components and
  symbolic links anywhere in the path are refused, confinement is enforced by the lookup primitive
  itself (never by checking a path and then opening it), and the mount-crossing policy is stated. A
  target without such a primitive refuses filesystem access.
- **The environment and the clock are grants**: an `Environment` value selects which variables and
  arguments are visible, a `Clock` value which clock and what precision. `get_args` takes the
  `Environment` and `with(Env)`, and an allocator when it allocates.
- **Network**: connecting needs a grant naming the permitted destinations, and binding or listening a
  grant naming the endpoint, each plus `with(Network)`; accepting takes the listener, and communicating
  takes the connected socket, still with `with(Network)` (holding a socket supplies no permission).
  Name resolution (DNS) needs its own stated authority contract.

<a id="decided-2026-11-02-audit"></a>**Decided 2026-11-02, the questions the spec audit raised** (same rule: Claude's proposal
and Codex's review agreed, Codex's refinement adopted where it gave one):

- **Allocator reset** is allowed under the condition for giving an allocator up: it consumes the
  allocator, requires `with(Alloc)` and no live allocation or conflicting loan from it, and returns an
  allocator whose identity the operation generates fresh (never chosen by the caller). How fresh
  identities are introduced and scoped in Core, including repeated resets in a loop, is part of the
  target Core proposal.
- **Who introduces primitives.** Any library may declare externs, in trusted code, each listed in the
  trusted base with an accurate primitive contract. Only the compiler introduces intrinsics. Only the
  target runtime mints the initial grants; ordinary libraries may acquire or narrow authority only
  from grants they already hold, and an extern never bypasses this.
- **What "every operation" covers** (authority rule 2): the operations on resources. Pure computation
  and checked traps need neither a value nor a permission. `abort()` is the same terminal trap and
  needs neither (this revises STMT-13, which required `Process`). The target's diagnostics and output
  flushing stay accounted for in traces and target assumptions, and `Unsafe` keeps its own validity
  requirements.
- **`main` declares the grants it wants**, as parameters, out of those the target offers; a grant it
  does not declare is never minted, and it consumes every grant it declares.
- **Opening a heap.** `&h` gives `&Heap<T, A>`, a reference to the heap's shell. A borrow block opens
  exactly one heap layer; opening mutably needs exclusive access, and opening through a shell
  reference keeps that reference's root and lifetime and never upgrades shared access. A `HeapArray`
  exposes a bounded element view, never an element `&T` or an extra heap layer; the view's exact type
  is part of the target Core proposal.
- **Qualified trait calls** (syntax completion of the canonical [OD6](#od6) rule): an ambiguous method call is written `Trait::method(&x, ...)`,
  a path call resolved by the trait's identity, and is refused otherwise; qualification never relaxes
  coherence.
- **Traits cross modules like any other declaration** (owner, 2026-11-02): a `pub` trait is exported,
  and another module imports it explicitly (OD139) to implement it, bound by it or call
  it qualified as `Trait::method(&x, ...)`.
- **Mounts and name resolution.** A lookup that crosses a mount point is refused. Name resolution
  (DNS) takes a resolver grant naming the permitted service, query scope and transport, plus
  `with(Network)`, and an allocator when it allocates; resolving grants no connection, and connecting
  to a returned address still needs the destination grant.
- **`defer` takes a call whose result is `Unit`** (canonical current rule; revised OD140 and authority rule 9 refer here). Any other call is wrapped in a named
  function that returns `Unit` and consumes a linear result, handles a `Result` or `Option`, or
  discards an eligible Copy result; there is no discard form inside `defer`.
- **A projection base is a place**: a local, or a projection through a place. A call result is bound
  with `let` before it is projected.
- **Deferred arguments.** A by-value argument of a deferred call is reserved and read when the call runs
  (OWN-12, kept by OD2); a borrowed argument is a loan held until the call runs (OWN-16). Both
  restrictions apply together. Allocator dependencies are checked when the deferred call runs: an
  allocation may still be alive at registration only if the cleanup removes it before its allocator is
  consumed.
- **`_` names an unused binding.** It never discards a linear value or a `Result` or `Option` (OD62);
  those are consumed or handled explicitly.
- **Postconditions are partial correctness over normal returns.** A trap is not a return, so `ensures`
  says nothing about trapping or diverging executions, and a proved postcondition is never reported as
  freedom from traps.
- **What a function contract sees.** `requires` and `ensures` see the function's parameters, `result`
  (in `ensures` only) and the declarations they may name, such as specification functions; never the
  body's locals. `requires` reads the parameters at entry; `ensures` reads the parameters' surviving
  state after every deferred call (OD144), with no implicit entry snapshot, and a parameter the body
  consumed is not visible. Loop clauses and body assertions use their own lexical scope, permitted
  ghost locals included.
- **User capability aliases** (`cap IO = ...`) are removed: they are umbrella capabilities by another
  name. Capability parameters remain.

**Decided 2026-10-31 by the owner's rule** (every reviewer agreed, and the answer is as strict as
Austral or stricter):

- <a id="OPEN-33"></a>**OPEN-33** (OD33, Inline submodules under one file per module): See [OD33](#od33).
- <a id="OPEN-43"></a>**OPEN-43** (OD43, How a type position resolves a name): See [OD43](#od43).
- <a id="OPEN-44"></a>**OPEN-44** (OD44, Two packages with one module name): See [OD44](#od44).
- <a id="OPEN-46"></a>**OPEN-46** (OD46, Generic type-argument inference): See [OD46](#od46).
- <a id="OPEN-48"></a>**OPEN-48** (OD48, The index type of a counted loop over two literals): See [OD48](#od48).
- <a id="OPEN-50"></a>**OPEN-50** (OD50, Reserved or contextual `from` and `until`): See [OD50](#od50).
- <a id="OPEN-51"></a>**OPEN-51** (OD51, Reverse, stepped and collection iteration): See [OD51](#od51).
- <a id="OPEN-52"></a>**OPEN-52** (OD52, `if let`, `while let` and `let ... else`): See [OD52](#od52).
- <a id="OPEN-53"></a>**OPEN-53** (OD53, Struct update `..base`): See [OD53](#od53).
- <a id="OPEN-54"></a>**OPEN-54** (OD54, `newtype` and `.0`): See [OD54](#od54).
- <a id="OPEN-55"></a>**OPEN-55** (OD55, Match guards): See [OD55](#od55).
- <a id="OPEN-56"></a>**OPEN-56** (OD56, Range patterns): See [OD56](#od56).
- <a id="OPEN-58"></a>**OPEN-58** (OD58, Borrow blocks stay): See [OD58](#od58).
- <a id="OPEN-62"></a>**OPEN-62** (OD62, Unused values and variables): See [OD62](#od62).
- <a id="OPEN-63"></a>**OPEN-63** (OD63, Float literals take their expected type): See [OD63](#od63).
- <a id="OPEN-64"></a>**OPEN-64** (OD64, Raw pointers derived from a borrow): See [OD64](#od64).
- <a id="OPEN-65"></a>**OPEN-65** (OD65, Empty structs): See [OD65](#od65).
- <a id="OPEN-66"></a>**OPEN-66** (OD66, The unit literal `()`): See [OD66](#od66).
- <a id="OPEN-67"></a>**OPEN-67** (OD67, Locals that reuse a top-level name): See [OD67](#od67).
- <a id="OPEN-68"></a>**OPEN-68** (OD68, Failure inside a deferred call): See [OD68](#od68).
- <a id="OPEN-69"></a>**OPEN-69** (OD69, What "the remaining locals are destroyed" means): See [OD69](#od69).
- <a id="OPEN-70"></a>**OPEN-70** (OD70, Struct fields with no comma): See [OD70](#od70).
- <a id="OPEN-71"></a>**OPEN-71** (OD71, Enum variants with no comma): See [OD71](#od71).
- <a id="OPEN-73"></a>**OPEN-73** (OD73, Reserved words used as identifiers): See [OD73](#od73).
- <a id="OPEN-75"></a>**OPEN-75** (OD75, An empty type parameter list): See [OD75](#od75).
- <a id="OPEN-84"></a>**OPEN-84** (OD84, Struct destructuring `let` in the grammar): See [OD84](#od84).
- <a id="OPEN-85"></a>**OPEN-85** (OD85, Variant destructuring with `else` in the grammar): See [OD85](#od85).
- <a id="OPEN-90"></a>**OPEN-90** (OD90, `struct Copy <T>` and contextual keywords): See [OD90](#od90).
- <a id="OPEN-100"></a>**OPEN-100** (OD100, Comparisons on a type parameter): See [OD100](#od100).
- <a id="OPEN-101"></a>**OPEN-101** (OD101, What a trap writes): See [OD101](#od101).
- <a id="OPEN-103"></a>**OPEN-103** (OD103, `as` between reference types): See [OD103](#od103).
- <a id="OPEN-107"></a>**OPEN-107** (OD107, What a float-to-integer rounding gives for NaN, infinities and out-of-range values): See [OD107](#od107).
- <a id="OPEN-110"></a>**OPEN-110** (OD110, Enums at the foreign boundary): See [OD110](#od110).
- <a id="OPEN-112"></a>**OPEN-112** (OD112, Mutation through a shared reference): See [OD112](#od112).
- <a id="OPEN-113"></a>**OPEN-113** (OD113, The ownership exceptions of trusted code): See [OD113](#od113).
- <a id="OPEN-114"></a>**OPEN-114** (OD114, How integer division rounds): See [OD114](#od114).
- <a id="OPEN-118"></a>**OPEN-118** (OD118, A proven run-time violation in trusted code): See [OD118](#od118).
- <a id="OPEN-119"></a>**OPEN-119** (OD119, Buffered output when the process aborts): See [OD119](#od119).
- <a id="OPEN-121"></a>**OPEN-121** (OD121, Projections from a base that is not a traceable place): See [OD121](#od121).
- <a id="OPEN-127"></a>**OPEN-127** (OD127, UTF-8 in every `String`): See [OD127](#od127).
- <a id="OPEN-130"></a>**OPEN-130** (OD130, Unlabeled pattern binders: by position or by name): See [OD130](#od130).
- <a id="OPEN-131"></a>**OPEN-131** (OD131, `union` declarations): See [OD131](#od131).
- <a id="OPEN-136"></a>**OPEN-136** (OD136, std's `process_exit`): See [OD136](#od136).
- <a id="OPEN-137"></a>**OPEN-137** (OD137, Character literals outside ASCII): See [OD137](#od137).
- <a id="OPEN-139"></a>**OPEN-139** (OD139, A qualified call to a function that is not imported): See [OD139](#od139).
- <a id="OPEN-148"></a>**OPEN-148** (OD148, Type parameters on a trait): See [OD148](#od148).

**Decided 2026-11-01 by the owner** (the final set, reviewed by Claude, Codex and Grok, checked
against Austral and the no-duplication rule):

- <a id="OPEN-34"></a>**OPEN-34** (OD34, A struct literal inside brackets in a condition head): See [OD34](#od34).
- <a id="OPEN-35"></a>**OPEN-35** (OD35, How an array satisfies a `Destroy` bound): See [OD35](#od35).
- <a id="OPEN-36"></a>**OPEN-36** (OD36, The explicit place form that opens a heap cell): See [OD36](#od36).
- <a id="OPEN-37"></a>**OPEN-37** (OD37, The names of the pointer difference and ordering functions): See [OD37](#od37).
- <a id="OPEN-38"></a>**OPEN-38** (OD38, The root resource API): See [OD38](#od38).
- <a id="OPEN-39"></a>**OPEN-39** (OD39, The interface artifact format): See [OD39](#od39).
- <a id="OPEN-40"></a>**OPEN-40** (OD40, PAT-9 and the fallback arm of a desugared form): See [OD40](#od40).
- <a id="OPEN-41"></a>**OPEN-41** (OD41, PAT-9 and integer ranges that span their type): See [OD41](#od41).
- <a id="OPEN-42"></a>**OPEN-42** (OD42, Comparisons on `bool` and `char`): See [OD42](#od42).
- <a id="OPEN-45"></a>**OPEN-45** (OD45, Capability-variable inference): See [OD45](#od45).
- <a id="OPEN-49"></a>**OPEN-49** (OD49, The arithmetic of a counted loop's termination measure): See [OD49](#od49).
- <a id="OPEN-57"></a>**OPEN-57** (OD57, The region name of a borrow block): See [OD57](#od57).
- <a id="OPEN-59"></a>**OPEN-59** (OD59, One way to consume a `Heap`): See [OD59](#od59).
- <a id="OPEN-60"></a>**OPEN-60** (OD60, One consuming receiver form for `Destroy`): See [OD60](#od60).
- <a id="OPEN-61"></a>**OPEN-61** (OD61, One coordinated removal list): See [OD61](#od61).
- <a id="OPEN-72"></a>**OPEN-72** (OD72, An enum with no variants): See [OD72](#od72).
- <a id="OPEN-74"></a>**OPEN-74** (OD74, A raw pointer type with no qualifier): See [OD74](#od74).
- <a id="OPEN-76"></a>**OPEN-76** (OD76, Unqualified struct patterns in `match`): See [OD76](#od76).
- <a id="OPEN-77"></a>**OPEN-77** (OD77, Resync the grammar to the decided language): See [OD77](#od77).
- <a id="OPEN-78"></a>**OPEN-78** (OD78, `mod X;` in the grammar): See [OD78](#od78).
- <a id="OPEN-79"></a>**OPEN-79** (OD79, `assert` in the grammar): See [OD79](#od79).
- <a id="OPEN-80"></a>**OPEN-80** (OD80, `assume` in the grammar): See [OD80](#od80).
- <a id="OPEN-81"></a>**OPEN-81** (OD81, `ghost let` in the grammar): See [OD81](#od81).
- <a id="OPEN-82"></a>**OPEN-82** (OD82, Loop contract attributes and where attributes attach): See [OD82](#od82).
- <a id="OPEN-83"></a>**OPEN-83** (OD83, The call-site allocator binding in the grammar): See [OD83](#od83).
- <a id="OPEN-86"></a>**OPEN-86** (OD86, The body of an unbraced match arm): See [OD86](#od86).
- <a id="OPEN-87"></a>**OPEN-87** (OD87, Capability arguments in an expression turbofish): See [OD87](#od87).
- <a id="OPEN-88"></a>**OPEN-88** (OD88, The shape of capability arguments): See [OD88](#od88).
- <a id="OPEN-89"></a>**OPEN-89** (OD89, Capability parameters on a trait impl): See [OD89](#od89).
- <a id="OPEN-91"></a>**OPEN-91** (OD91, A cast followed by `<`): See [OD91](#od91).
- <a id="OPEN-92"></a>**OPEN-92** (OD92, A capability set inferred from callbacks): See [OD92](#od92).
- <a id="OPEN-93"></a>**OPEN-93** (OD93, Widening a function value's capability set): See [OD93](#od93).
- <a id="OPEN-95"></a>**OPEN-95** (OD95, What `Time`, `Env`, `Process` and `Alloc` mean): See [OD95](#od95).
- <a id="OPEN-96"></a>**OPEN-96** (OD96, Two foreign bindings of one C symbol): See [OD96](#od96).
- <a id="OPEN-97"></a>**OPEN-97** (OD97, A build profile that omits or demands an overflow check): See [OD97](#od97).
- <a id="OPEN-98"></a>**OPEN-98** (OD98, Pointer and reference conversions written with `as`): See [OD98](#od98).
- <a id="OPEN-99"></a>**OPEN-99** (OD99, The names of the named conversions): See [OD99](#od99).
- <a id="OPEN-102"></a>**OPEN-102** (OD102, `Float32` and `Char` as type spellings): See [OD102](#od102).
- <a id="OPEN-104"></a>**OPEN-104** (OD104, A `#[variant]` written on a counted loop): See [OD104](#od104).
- <a id="OPEN-105"></a>**OPEN-105** (OD105, Where a counted loop's `#[invariant]` is checked): See [OD105](#od105).
- <a id="OPEN-106"></a>**OPEN-106** (OD106, The result type of a checked conversion): See [OD106](#od106).
- <a id="OPEN-108"></a>**OPEN-108** (OD108, A capability listed twice in a set): See [OD108](#od108).
- <a id="OPEN-109"></a>**OPEN-109** (OD109, Specializations that differ only in a function type's capabilities): See [OD109](#od109).
- <a id="OPEN-111"></a>**OPEN-111** (OD111, Misaligned fields of a packed struct): See [OD111](#od111).
- <a id="OPEN-115"></a>**OPEN-115** (OD115, The body and totality of a specification function): See [OD115](#od115).
- <a id="OPEN-116"></a>**OPEN-116** (OD116, A checked total function category): See [OD116](#od116).
- <a id="OPEN-117"></a>**OPEN-117** (OD117, `old`, quantifiers and implication in contracts): See [OD117](#od117).
- <a id="OPEN-120"></a>**OPEN-120** (OD120, A vacuous contract): See [OD120](#od120).
- <a id="OPEN-122"></a>**OPEN-122** (OD122, A `repr(C)` struct returned from an extern function): See [OD122](#od122).
- <a id="OPEN-123"></a>**OPEN-123** (OD123, `as` on a newtype outside its module): See [OD123](#od123).
- <a id="OPEN-124"></a>**OPEN-124** (OD124, Profiles in the specification): See [OD124](#od124).
- <a id="OPEN-125"></a>**OPEN-125** (OD125, Contracts at run time): See [OD125](#od125).
- <a id="OPEN-126"></a>**OPEN-126** (OD126, Target assumptions): See [OD126](#od126).
- <a id="OPEN-128"></a>**OPEN-128** (OD128, `->` between a match arm's pattern and body): See [OD128](#od128).
- <a id="OPEN-129"></a>**OPEN-129** (OD129, Type arguments of an enum literal taken from its expected type): See [OD129](#od129).
- <a id="OPEN-132"></a>**OPEN-132** (OD132, Polymorphic recursion): See [OD132](#od132).
- <a id="OPEN-133"></a>**OPEN-133** (OD133, User functions named `print`, `println` or `append`): See [OD133](#od133).
- <a id="OPEN-134"></a>**OPEN-134** (OD134, The capabilities of a container's generated destruction): See [OD134](#od134).
- <a id="OPEN-135"></a>**OPEN-135** (OD135, A method's `Type_method` name in its module's namespace): See [OD135](#od135).
- <a id="OPEN-138"></a>**OPEN-138** (OD138, Which positions give a literal its expected type): See [OD138](#od138).
- <a id="OPEN-140"></a>**OPEN-140** (OD140, Implicitly dropped results of `free` and of a deferred call): See [OD140](#od140).
- <a id="OPEN-141"></a>**OPEN-141** (OD141, More than one `main` in a program): See [OD141](#od141).
- <a id="OPEN-142"></a>**OPEN-142** (OD142, `X.con` beside `X/mod.con`): See [OD142](#od142).
- <a id="OPEN-143"></a>**OPEN-143** (OD143, What a contract may read): See [OD143](#od143).
- <a id="OPEN-144"></a>**OPEN-144** (OD144, Postconditions and deferred calls): See [OD144](#od144).
- <a id="OPEN-145"></a>**OPEN-145** (OD145, How a contract names machine arithmetic): See [OD145](#od145).
- <a id="OPEN-146"></a>**OPEN-146** (OD146, The result type of a test function): See [OD146](#od146).
- <a id="OPEN-147"></a>**OPEN-147** (OD147, `repr(C, packed)` together): See [OD147](#od147).
- <a id="OPEN-149"></a>**OPEN-149** (OD149, How `[e; N]` evaluates `e`): See [OD149](#od149).
- <a id="OPEN-150"></a>**OPEN-150** (OD150, Which text governs the grammar until it is resynchronized): See [OD150](#od150).
- <a id="OPEN-151"></a>**OPEN-151** (OD151, Module paths of more than one level): See [OD151](#od151).
- <a id="OPEN-152"></a>**OPEN-152** (OD152, Whether a path's first letter decides its syntactic form): See [OD152](#od152).
- <a id="OPEN-153"></a>**OPEN-153** (OD153, Program functions named like a builtin): See [OD153](#od153).
- <a id="OPEN-154"></a>**OPEN-154** (OD154, Whether the string builtins require `Alloc`): See [OD154](#od154).
- <a id="OPEN-155"></a>**OPEN-155** (OD155, `unwrap` beside TYPE-24's conversions): See [OD155](#od155).
- <a id="OPEN-156"></a>**OPEN-156** (OD156, The capability of `get_args`): See [OD156](#od156).
- <a id="OPEN-157"></a>**OPEN-157** (OD157, How the type `Unit` is written): See [OD157](#od157).

**Decided 2026-10-29:**

- **OD47** (loops, decided 2026-10-29, never an open entry): `while` and the counted loop `for i from a
  until b`, the C-style `for` removed. Now STMT-6@3, STMT-11@2 and STMT-12 (pending, bug 331); OD47 left OPEN-48 to
  OPEN-51.
- **OD23 – OD32** (the strictness pass, decided 2026-10-29, never open entries): REF-11@3 (OD23),
  STMT-7@3 (OD24, revised 2026-11-02 to [`u8` only](#decided-2026-11-02-main)), PAT-3@3 and PAT-5@3 (OD25), TYPE-6@2 (OD26), STMT-6@2 (OD27), TRAIT-10@2 (OD28),
  OWN-7@3 (OD29), MEM-4@3 (OD30), ARITH-2@2 (OD31) and OWN-15@3 (OD32), each pending its bug (319 –
  328); OD28 and OD30 left OPEN-35 and OPEN-36.
- **OPEN-1** (OD1, references): decided 2026-10-29. Now REF-5 (formation, `&s.f`, no temporary root), REF-1 and REF-3 (second-class), TRUST-3 (the raw-pointer validity premise, pending) and REF-8 (loans keyed by the root variable, as OD15 (a) confirmed).
- **OPEN-4** (OD4, foreign function values): decided 2026-10-29. Now FFI-1.
- **OPEN-5** (OD5, generics and Copy): decided 2026-10-29. Now OWN-D1, TYPE-13 and TYPE-14.
- **OPEN-6** (OD6, trait coherence): decided 2026-10-29. Now TRAIT-1 to TRAIT-7.
- **OPEN-7** (OD7, an unsafe-module marker): decided 2026-10-29. Now TRUST-6@2 (pending, R-0509).
- **OPEN-10** (OD10, arithmetic): decided 2026-10-29. Now ARITH-3, ARITH-4 and STMT-2 (pending).
- **OPEN-11** (OD11, casts): decided 2026-10-29. Now ARITH-5 (partial) and TRUST-1 (pending).
- **OPEN-12** (OD12, contracts): decided 2026-10-29. Now CON-1 (pending) and CON-3 (partial).
- **OPEN-13** (OD13, raw-pointer ownership): decided 2026-10-29. Now TRUST-7.
- **OPEN-14** (OD14, type validity): decided 2026-10-29. Now REF-2 and REF-4 (the single judgment before specialization is R-0499's).
- **OPEN-18** (OD18, match arm order and unreachable arms): decided 2026-10-29. Now PAT-9 (pending, R-0500).
- **OPEN-19** (OD19, the provable subset): decided 2026-10-29. Now the scope of [PROVABLE_V1.md](../legacy/docs/verification/PROVABLE_V1.md), not a language rule.
- **OPEN-2** (OD2, `&mut` arguments, deferred loans and the exit order): decided 2026-10-29. Now
  REF-10@2 (lending), REF-11@3 (exclusivity at a call, keyed by the root as OD15 (a) tightened it), REF-13 (a `&mut` refers to the
  place), OWN-16 (a deferred call's borrow lives until it runs) and STMT-11 (one exit sequence).
- **OPEN-9** (OD9, modules and interfaces): decided 2026-10-29. Now MOD-7 (pending, R-0556).
- **OPEN-3** (OD3, pattern binders through a borrowed scrutinee): decided 2026-10-29, as enforced.
  Now REF-9 (the binder is always a reference), PASS-2 (its mode stored in Core) and REF-8 (the root
  is not reassigned while the binder's loan lives).
- **OPEN-15** (OD15, freezing and `&mut` exclusivity): decided 2026-10-29. Part (a), whole-owner
  freezing with loans keyed by the root binding, is REF-11@3 (it tightens OD2's part 2; partial, bug 319,
  for OD23's re-lent case).
  Part (b), the strict option, is REF-14 (pending, R-0496): no pass exploits `&mut` exclusivity until
  it is proved, and an alias derived from a loan is valid only while the loan lives.
- **OPEN-16** (OD16, a struct literal in a condition head): decided 2026-10-29, refused unless
  parenthesized, with no exceptions. Now SYN-4 (pending, bug 318); what counts as parenthesized inside
  a call's arguments is OPEN-34.
- **OPEN-17** (OD17, field writes and `mut`): decided 2026-10-29. Now OWN-10@2 (partial, bug 216).
- **OPEN-8** (OD8, global state): decided 2026-10-29, constants only and global resources as linear
  tokens. Now TRUST-8, TRUST-9 and TRUST-10 of [trusted.md](../legacy/docs/spec/trusted.md#TRUST-8) (pending, R-0557).

- **OPEN-20** (OD20, the visibility of std's `std.libc` bindings): decided 2026-10-29, private to std.
  Now MOD-6 of [modules.md](../legacy/docs/spec/modules.md#MOD-6) (enforced by bug 226's fix).
- **OPEN-21** (OD21, a parent module's rights over its child): decided 2026-10-29, only the declaring
  module. Now TYPE-11 of [types.md](../legacy/docs/spec/types.md#TYPE-11), enforced as written for a parent too (bug
  311's fix).
- **OPEN-22** (OD22, trust on an `impl` block): decided 2026-10-29, per method only. Now TRUST-5@2 of
  [trusted.md](../legacy/docs/spec/trusted.md#TRUST-5).

